(* author: Louis, translated to OCaml by Jean-Christophe *)

open Format
open Scanf

let nR,nD,nC = scanf "%d %d %d\n" (fun r d c -> r, d, c)

let nxt = Array.make_matrix nR (nC+1) []
let pre = Array.make_matrix nR (nC+1) []
let sn  = Array.init nR (fun _ -> Array.make_matrix nR (nC+1) false)

let () =
  for _ = 1 to nD do
    scanf "%d %d %d\n" (fun f t c ->
        nxt.(f).(c) <- t :: nxt.(f).(c);
        pre.(t).(c) <- f :: pre.(t).(c))
  done

(* add guards for Stack positive paths *)
let () =
  for c = 0 to nC do nxt.(nR-1).(c) <- (nR-1) :: nxt.(nR-1).(c) done

(* compute the SN relation *)
let () =
  let todo = Stack.create () in
  for c = 0 to nC do for x = 0 to nR-1 do Stack.push (x,x,c) todo done done;
  while not (Stack.is_empty todo) do
    let x,y,c = Stack.pop todo in
    if not sn.(x).(y).(c) then (
      sn.(x).(y).(c) <- true;
      pre.(x).(c) |> List.iter (fun p ->
        nxt.(y).(c) |> List.iter (fun n ->
          for cp = 0 to nC do
            if nxt.(p).(cp) = [] then Stack.push (p,n,cp) todo
          done));
      for z = 0 to nR - 1 do
        if sn.(z).(x).(c) then Stack.push (z,y,c) todo;
        if sn.(y).(z).(c) then Stack.push (x,z,c) todo
      done
    )
  done

(* compute minimal path *)
let () =
  let done_ = Hashtbl.create 16 in
  let todo = Array.make (nR*nC+1) [] in
  let pop i =
    match todo.(i) with [] -> assert false | x :: r -> todo.(i) <- r; x in
  for c = nC downto 0 do todo.(0) <- (0,c) :: todo.(0) done;
  for dist = 0 to nR*nC do
    while todo.(dist) <> [] do
      let x,c = pop dist in
      if not (Hashtbl.mem done_ (x,c)) then (
        Hashtbl.add done_ (x,c) ();
        if x = nR-1 then (
            printf "%d@." dist;
            exit 0
        );
        nxt.(x).(c) |> List.iter (fun n ->
          for cp = 0 to nC do
            todo.(dist+1) <- (n,cp) :: todo.(dist+1)
          done
        );
        for y = 0 to nR-1 do
          if sn.(x).(y).(c) then
            todo.(dist) <- (y,c) :: todo.(dist)
        done
      )
    done
  done

let () = printf "NO DECK@."
