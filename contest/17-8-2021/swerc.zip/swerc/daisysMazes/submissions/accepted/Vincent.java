import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;

public class Vincent {
	private static int R;
	private static int D;
	private static int C;
	private static int[][] OUTDOOR;
	private static Set<Integer>[][] INDOOR;
	private static boolean[][][] PATH;
	private static final Set<Integer> ALL = new HashSet<>();
	private static final Stack<Integer> PENDING = new Stack<>();
	private static Set<Integer>[][] OUTPATH; // OUTPATH[i][c] = Set of rooms you can reach from c
	// without touching the c card and just having the c card in the end
	private static Set<Integer>[][] INPATH; // INPATH[i][c] = Set of rooms that can reach i from c
	// without touching the c card and just having the c card in the end
	private static Set<Integer>[] WINNERS; // WINNERS[c] = Set of rooms that can win if their
	// top card is c
	private static int[] HEIGHT; // height[i] = Stack height
	// required to arrive to room i at height 0

	@SuppressWarnings("unchecked")
	private static void read() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line = br.readLine().split(" ");
		R = Integer.parseInt(line[0]);
		D = Integer.parseInt(line[1]);
		C = Integer.parseInt(line[2]);
		OUTDOOR = new int[R][C + 1];
		INDOOR = (Set<Integer>[][]) new Set[R][C + 1];
		OUTPATH = (Set<Integer>[][]) new Set[R][C + 1];
		INPATH = (Set<Integer>[][]) new Set[R][C + 1];
		WINNERS = (Set<Integer>[]) new Set[C + 1];
		HEIGHT = new int[R];
		for (int i = 0; i < R; i++) {
			HEIGHT[i] = R+1;
			for (int j = 0; j < C + 1; j++) {
				OUTDOOR[i][j] = -1;
				INDOOR[i][j] = new HashSet<>();
				OUTPATH[i][j] = new HashSet<>();
				INPATH[i][j] = new HashSet<>();
			}
		}
		for (int j = 0; j < C + 1; j++) {
			WINNERS[j] = new HashSet<>();
		}
		for (int i = 0; i < D; i++) {
			line = br.readLine().split(" ");
			int a = Integer.parseInt(line[0]);
			int b = Integer.parseInt(line[1]);
			int c = Integer.parseInt(line[2]);
			OUTDOOR[a][c] = b;
			INDOOR[b][c].add(a);
		}
		br.close();
	}

	private static void addToBuffers(int a, int b, int c) {
		int s = a + R * b + R * R * c;
		if (!ALL.contains(s)) {
			ALL.add(s);
			PENDING.push(s);
		}
	}

	private static void getBuffers() {
		PATH = new boolean[R][R][C + 1];
		for (int i = 0; i < R; i++) {
			for (int j = 0; j < C + 1; j++) {
				PATH[i][i][j] = true;
				addToBuffers(i, i, j);
			}
		}
		while (!PENDING.isEmpty()) {
			int c = PENDING.pop();
			int a = c % R;
			c /= R;
			int b = c % R;
			c /= R;

			if (c < C && OUTDOOR[b][c] != -1) {
				for (int d : INDOOR[a][c]) {
					for (int cc = 0; cc < C + 1; cc++) {
						if (OUTDOOR[d][cc] == -1) {
							addToBuffers(d, OUTDOOR[b][c], cc);
						}
					}
				}
			}

			for (int d : INPATH[a][c]) {
				addToBuffers(d, b, c);
			}
			for (int e : OUTPATH[b][c]) {
				addToBuffers(a, e, c);
			}
			OUTPATH[a][c].add(b);
			INPATH[b][c].add(a);
		}
	}

	@SuppressWarnings("unchecked")
	private static void getWinners() {
		Stack<Integer> stack = new Stack<>();
		for (int c = 0; c < C + 1; c++) {
			WINNERS[c].add(R - 1);
			stack.push(R - 1 + R * c);
		}
		while (!stack.isEmpty()) {
			int c = stack.pop();
			int a = c % R;
			c /= R;
			WINNERS[c].add(a);
			for (int d : INPATH[a][c]) {
				if (!WINNERS[c].contains(d)) {
					WINNERS[c].add(d);
					stack.push(d + R * c);
				}
			}
			for (int d : INDOOR[a][c]) {
				for (int cc = 0; cc < C + 1; cc++) {
					if (OUTDOOR[d][cc] == -1 && !WINNERS[cc].contains(d)) {
						WINNERS[cc].add(d);
						stack.push(d + R * cc);
					}
				}
			}
		}
	}

	private static void getHeight() {
		Stack<Integer> stack = new Stack<>();
		Stack<Integer> stack2 = new Stack<>();
		Set<Integer> treated = new HashSet<>();
		int h = 0;
		stack.push(0);
		HEIGHT[0] = h;
		while (!stack.isEmpty() || !stack2.isEmpty()) {
			while (!stack.isEmpty()) {
				int i = stack.pop();
				if (!treated.contains(i)) {
					treated.add(i);
					for (int j : OUTPATH[i][C]) {
						if (HEIGHT[j] > h) {
							HEIGHT[j] = h;
						}
					}
					for (int c = 0; c < C+1; c++) {
						for (int j : OUTPATH[i][c]) {
							if (OUTDOOR[j][c] != -1) {
								stack2.push(OUTDOOR[j][c]);
							}
						}
					}
				}
			}
			h++;
			stack = stack2;
			stack2 = new Stack<>();
		}
	}
	
	private static void getMinHeight() {
		int min = R+1;
		for (int i : WINNERS[C]) {
			if (min > HEIGHT[i]) {
				min = HEIGHT[i];
			}
		}
		System.out.println(min);
	}

	public static void main(String[] args) throws IOException {
		read();
		getBuffers();
		getWinners();
		getHeight();
		getMinHeight();
	}
}

