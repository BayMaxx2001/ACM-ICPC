#include <cstdio>
#include <vector>

using namespace std;

const int Cm = 101, Nm = 201 ;
int C, D, N;
vector <int> push[Nm][Cm], pop[Nm][Cm];
bool SN[Nm][Nm][Cm], hasTr[Nm][Cm] ;

void propagate(int x, int y, int c) {
  if(SN[x][y][c])
    return ;
  SN[x][y][c] = true;
  for(int z = 0 ; z < 2*N ; z++) {
    if(SN[z][x][c])
      propagate(z,y,c);
    if(SN[y][z][c])
      propagate(x,z,c);
  }
  for(int v : pop[y][c])
    for(int u : push[x][c])
      for(int cp = 0 ; cp <= C ; cp++)
        if(!hasTr[u][cp])
          propagate(u,v,cp);
}

int main () {
  scanf("%d %d %d\n",&N,&D,&C);
  for(int i = 0 ; i < D ; i++) {
    int f, t, c ;
    scanf("%d %d %d\n",&f,&t,&c);
    push[t][c].push_back(f);
    pop[f][c].push_back(t);
    hasTr[f][c] = true ; 
  }
  for(int c = 0 ; c < C ; c++)
    pop[N-1][c].push_back(N-1);
  for(int x = N ; x < 2*N ; x++)
    for(int c = 0 ; c < C ; c++)
      push[(x+1)%(2*N)][c].push_back(x);
  for(int x = 0 ; x < 2*N ; x++)
    for(int c = 0 ; c <= C ; c++)
      propagate(x,x,c);
  for(int d = 2*N ; d >= N ; d--)
    if(SN[d%(2*N)][N-1][C]) {
      printf("%d\n",2*N-d);
      return 0;
    }
}
