#Read input
R,D,C = map(int,input().split())
nxt = [ [[] for _ in range(C+1)] for _ in range(R) ]
pre = [ [[] for _ in range(C+1)] for _ in range(R) ]
SN = [[[ False for _ in range(C+1) ] for _ in range(R)] for _ in range(R)]
for _ in range(D):
    f,t,c = map(int,input().split())
    nxt[f][c].append(t)
    pre[t][c].append(f)

# Add guards for Stack positive paths
for c in range(C+1):
    nxt[R-1][c].append(R-1)

# Compute the SN relation
todo = [ (x,x,c) for x in range(R) for c in range(C+1)]
while todo:
    (x,y,c) = todo.pop()
    if not SN[x][y][c]:
        SN[x][y][c] = True
        for p in pre[x][c]:
            for n in nxt[y][c]:
                for cp in range(C+1):
                    if len(nxt[p][cp]) == 0:
                        todo.append((p,n,cp))
                        
        for z in range(R):
            if SN[z][x][c]:
                todo.append((z,y,c))
            if SN[y][z][c]:
                todo.append((x,z,c))

# Compute minimal path 
done = set()
todo = [[(0,c) for c in range(C+1)]] + [[] for _ in range(R*C)]
for dist in range(R*C):
    while len(todo[dist]):
        (x,c) = todo[dist].pop()
        if (x,c) not in done: 
            done.add((x,c))
            if x == R-1:
                print(dist)
                exit(0)
            for n in nxt[x][c]:
                for cp in range(C+1):
                    todo[dist+1].append((n,cp))
            for y in range(R):
                if SN[x][y][c]:
                    todo[dist].append((y,c))
# No path?
print("NO DECK")
