#! /usr/bin/python

def myint(s):
    assert s == "0" or not s.startswith("0"),\
            "leading 0 detected"
    return int(s)

try: input = raw_input  # Python 2 compatibility
except: pass

R, D, C = map(myint, input().split())

assert(1<=R<=50)
assert(1<=D<=100)
assert(1<=C<=20)

nxt = [ [] for _ in range(R)]
nxtc = [ [] for _ in range(R)]

import sys
lines = sys.stdin.readlines()
assert(len(lines)==D)
for v in lines:
    f,t,c = map(myint, v[:-1].split())
    assert(0<=f<R)
    assert(0<=t<R)
    assert(0<=c<C)
    assert(f!=t)
    nxt[f].append(t)
    nxtc[f].append(c)

todo = [0]
seen = set()
while len(todo):
    n = todo.pop()
    if n not in seen:
        seen.add(n)
        todo += nxt[n]
assert( (R-1) in seen)

for n in range(R):
    seen = set()
    for c in nxtc[n]:
        assert(not(c in seen))
        seen.add(c)
exit(42)        
