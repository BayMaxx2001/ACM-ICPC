#!/usr/bin/env python

import random
import sys

random.seed(42)

curTest = 5
def outTest(R,C,l):
    C=min(C,10)
    R=min(50,R)
    global curTest
    sys.stdout = open(("test%.2d.in"%curTest), 'w')
    curTest += 1

    out = set()
    data = []
    for (f,t,c) in l:
        if (f,c) not in out:
            out.add((f%R,c))
            if f%R == t%R:
                t+=1
            data.append((f%R,t%R,c))
    
    print("%d %d %d"%(R,len(data),C))
    for (f,t,c) in data:
        print("%d %d %d"%(f%R,t%R,c%C))




def genRandom(R,D,C):
    l=[]
    seen = set()
    c = 0
    for i in range(R-1):
        if i%3 == 0 and i > 0:
            seen.add((i,c))
            l.append((i,i-1,c))
            c = (c+1)%C
        l.append((i,i+1,c))
        seen.add((i,c))
    while len(l) < D:
        f,t,c = random.randint(0,R-1),random.randint(0,R-1),random.randint(0,C-1)
        if (f,c) not in seen:
            seen.add((f,c))
            l.append((f,t,c))
    outTest(R,C,l)

def genHard(k):
    l = []
    for i in range(k):
        l.append((i*2,i*2+2,i))
        l.append((i*2+2,i*2+1,i))
        l.append((i*2+1,0,i))
    l += [ (k*2,k*2+1,k), (k*2+1,k*2+2,k+1), (k*2+2,k*2+3,k+2),
           (k*2+1,0,k), (k*2+2,0,k+1), (k*2+3,0,k+2),
           (k*2+3,k*2+4,0)   ]
    outTest(k*2+5,k+3,l)


def genHigh(k):
    l = []
    for i in range(k):
        l.append((i,i+1,i))
        l.append((i+1,0,i))
    outTest(k+1,k,l)

def genChain():
    outTest(50,10,[(47,0,0)]+[(i,i+1,i//47) for i in range(50)])
    
for i in range(2,5):
    genHard(i*i)
for i in range(1,4):
    genRandom(15*i+5,100,10)
for i in range(2,4):
    genRandom(50,100,10)
for i in range(1,4):
    genHigh(16*i)

genChain()
