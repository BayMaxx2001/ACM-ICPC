# Tool to generate a visualization of a test case.
# The output is a picture with a grid of the test case size, and circles in 
# each person's position with radius equal to the solution, so that we see 
# the end state with circles touching other circles and/or the grid edges.

# We expect the input and output files to be in the same directory and have
# the same prefix, just differing in file extension. 
# Example: `test.in` and `test.ans`. In this case call `python plot.py test`.


import matplotlib.pyplot as plt
import sys

COLORS = ['r', 'b', 'g', 'y', 'g']


if len(sys.argv) < 2:
    raise SystemExit('Wrong list of arguments. Usage: python plot.py <test_case_name>')

input_name = sys.argv[1] + '.in'

with open(sys.argv[1] + '.ans', 'r') as output_file:
    radius = float(output_file.readline())

with open(sys.argv[1] + '.in', 'r') as input_file:
    MAX_X, MAX_Y = map(int, input_file.readline().split())
    N = int(input_file.readline())
    positions = [map(float, input_file.readline().split()) for _ in xrange(N)]

fig, ax = plt.subplots() 

ax.set_xlim((0, MAX_X))
ax.set_ylim((0, MAX_Y))

for i in xrange(len(positions)):
    x, y = positions[i]
    ax.plot((x), (y), 'o', color='black')
    circle = plt.Circle((x, y), radius, color=COLORS[i%len(COLORS)], clip_on=False, alpha=0.5)
    ax.add_artist(circle)

output_file = sys.argv[1] + '_illustration.png'
if len(sys.argv) > 2:
    output_file = sys.argv[2]

fig.savefig(output_file)
