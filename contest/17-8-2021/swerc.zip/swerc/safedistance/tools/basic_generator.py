from random import randint

def getPosition(X, Y):
    x = randint(0, X*100) / 100.0
    y = randint(0, Y*100) / 100.0
    return (x, y)

X = randint(10000, 50000)
Y = randint(10000, 50000)
N = randint(4000, 5000)

positions = [getPosition(X, Y) for _ in xrange(N)]

print X, Y
print N
for x, y in positions:
    print x, y
