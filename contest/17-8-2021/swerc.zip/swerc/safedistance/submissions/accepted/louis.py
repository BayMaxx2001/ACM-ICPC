X,Y = map(int,input().split())
N = int(input())+2
dist = [ [10**20]*N for _ in range(N) ]
pos = [(0,0),(X,Y)] + [None] * N
d = [0] + [10**20] * N
S=0
F=1

def sq(x):
    return x*x

for i in range(2,N):
    pos[i] =  tuple(map(float,input().split()))
    dist[S][i] = 4*min( sq(pos[i][0]), sq(pos[i][1]-Y) ) 
    dist[i][F] = 4*min( sq(pos[i][0]-X), sq(pos[i][1]) )
    d[i] = 1e20;

for i in range(2,N):
    for j in range(2,N):
        dist[i][j] = sq(pos[i][0]-pos[j][0]) + sq(pos[i][1]-pos[j][1])

todo = list(range(N))
while len(todo):
    bmin = min(todo,key=lambda x:d[x])
    todo.remove(bmin)
    for i in todo:
        d[i] = min(d[i],max(d[bmin],dist[bmin][i]))

print((d[F]/4)**0.5)
