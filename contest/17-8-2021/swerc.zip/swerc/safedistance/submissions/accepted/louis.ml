let x,y = Scanf.scanf "%f %f\n" (fun x y -> (x,y))
let n = Scanf.scanf "%d\n" (fun x -> x+2)

let dist = Array.make_matrix n n 1e20
let posx = Array.make n 0.
let posy = Array.make n 0.
let d = Array.make n 1e20
      
let sq x = x*.x 

let _ =
  for i = 2 to n-1 do
    Scanf.scanf "%f %f\n" (fun x y -> posx.(i) <- x ; posy.(i) <- y) ;
    dist.(0).(i) <- 4. *. min (sq posx.(i)) (sq (posy.(i)-.y)) ;
    dist.(i).(1) <- 4. *. min (sq (posx.(i)-.x)) (sq posy.(i)) 
  done ;
  for i = 2 to n-1 do
    for j = 2 to n-1 do
      dist.(i).(j) <- sq (posx.(i)-.posx.(j)) +. sq (posy.(i)-.posy.(j))
    done
  done ;
  d.(0) <- 0.;
  let processed = Array.make n false in
  for i = 0 to n-1 do    
    let rec foo best i =
      if i >= n
      then best
      else foo (if not processed.(i) then min (d.(i),i) best else best) (i+1) 
    in
    let cur = match foo (1e21,-1) 0 with (_,x) -> x in 
    processed.(cur) <- true ;
    for j = 0 to n-1 do
      d.(j) <- min d.(j) (max d.(cur) dist.(cur).(j))
    done ;
  done;
  print_float((d.(1)/.4.)**0.5) ;
  print_newline ()
    
