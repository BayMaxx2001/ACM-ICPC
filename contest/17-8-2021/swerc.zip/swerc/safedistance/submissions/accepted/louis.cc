#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

const int Nm = 5000 + 2, S = 0, F=1;
double dist[Nm][Nm], pos[Nm][2], d[Nm], X, Y;
bool done[Nm];
int N ;

double sq(double x) { return x*x; }

int main() {
  scanf("%lf %lf %d\n",&X, &Y,&N);
  N+=2;
  for(int i = 2 ; i < N ; i++) {
    scanf("%lf %lf",pos[i],pos[i]+1);
    dist[S][i] = 4*min( sq(pos[i][0]), sq(pos[i][1]-Y) ) ;
    dist[i][F] = 4*min( sq(pos[i][0]-X), sq(pos[i][1]) ) ;
    d[i] = 1e20;
  }
  dist[S][F] = d[F] = 1e20 ;
  for(int i = 2 ; i < N ; i++)
    for(int j = 2 ; j < N ; j++)
      dist[i][j] = sq(pos[i][0]-pos[j][0]) + sq(pos[i][1]-pos[j][1]);
  for(int i = 0 ; i < N ; i++) {
    int best = F ;
    for (int j = 0 ; j < N ; j++)
      if( !done[j] && d[best] > d[j])
        best = j;
    done[best] = true ;
    for(int j = 0 ; j < N ; j++ )
      d[j] = min(d[j], max(d[best],dist[best][j]));
  }
  printf("%lf\n",sqrt(d[F]/4));
}
