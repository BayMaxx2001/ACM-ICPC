// SWERC 2020-2021
// Problem: Safe Distance (Geometric version)
// Author: Miguel Oliveira

#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

const int MAX_N = 5000;
const double EPS = 1e-8;

struct Point {
    double x, y;

    double Distance(const Point& other) {
        return sqrt((x-other.x)*(x-other.x) + (y-other.y)*(y-other.y));
    }
} people[MAX_N + 5];

int X, Y, N;

struct CircleSets {
    double min_x[MAX_N], max_x[MAX_N], min_y[MAX_N], max_y[MAX_N];
    int p[MAX_N], rank[MAX_N];

    void Init(double radius) {
        for (int i = 0; i < N; ++i) {
            min_x[i] = people[i].x - radius, max_x[i] = people[i].x + radius;
            min_y[i] = people[i].y - radius, max_y[i] = people[i].y + radius;
            p[i] = i;
            rank[i] = 0;
        }
    }

    int FindSet(int i) {
        if (i != p[i]) 
            p[i] = FindSet(p[i]);
        return p[i];
    }

    void Join(int i, int j) {
        i = FindSet(i), j = FindSet(j);
        if (i == j)
            return;

        int from = i, to = j;
        if (rank[i] > rank[j]) {
            swap(from, to);
        }

        p[from] = to;
        if (rank[from] == rank[to])
            rank[to]++;

        min_x[to] = min(min_x[to], min_x[from]);
        max_x[to] = max(max_x[to], max_x[from]);
        min_y[to] = min(min_y[to], min_y[from]);
        max_y[to] = max(max_y[to], max_y[from]);
    }

    bool HasSplittingSet() {
        for (int i = 0; i < N; i++) {
            if (p[i] != i)
                continue;

            if (min_x[i] < 0 && max_x[i] > X) {
                return true; // Horizontal split.
            }
            if (min_y[i] < 0 && max_y[i] > Y) {
                return true; // Vertical split.
            }

            if (min_x[i] < 0 && min_y[i] < 0) {
                return true; // Diagonal split on y = 0 && x = 0.
            }            
            if (max_x[i] > X && max_y[i] > Y) {
                return true; // Diagonal split on y = Y && x = X.
            }
        }
        return false;
    }
} circle_sets;

bool IsSafe(double radius) {
    // Construct sets of overlapping circles.
    circle_sets.Init(radius);
    for (int i = 0; i < N; i++)
        for (int j = i+1; j < N; j++)
            if (people[i].Distance(people[j]) < 2 * radius)
                circle_sets.Join(i, j);

    return !circle_sets.HasSplittingSet();
}

double FindMaxSafeDistance() {
    // If distance D is safe, then any d < D is safe too. Binary search the answer.
    double left = 0.0, right = min(X, Y);
    while (left+EPS < right) {
        double mid = (left + right) / 2;
        if (IsSafe(mid)) {
            left = mid;
        } else {
            right = mid;
        }
    }
    return left;
}

int main() {
    scanf("%d %d %d", &X, &Y, &N);    
    for (int i = 0; i < N; ++i) {
        scanf("%lf %lf", &people[i].x, &people[i].y);
    }
    printf("%.6f\n", FindMaxSafeDistance());
    return 0;
}
