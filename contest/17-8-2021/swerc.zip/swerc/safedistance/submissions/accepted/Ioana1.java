import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
import java.lang.Math; 


public class Ioana1
{
	static class Edge {
		double val;
		int n1, n2;
		public Edge(int n1, int n2, double val){
		    this.n1 = n1; this.n2 = n2; this.val = val;
		}
    }
    
    static class EdgeComparator implements Comparator<Edge> {
        public int compare(Edge edge1, Edge edge2) {
        		if (edge1.val < edge2.val) return -1;
        		else if (edge1.val == edge2.val) return 0;
        		else return 1;
        }
    }

	static int N;
	static int[] parent;
	static int[] rank;
	static Edge[] edges;
	static double MAXX, MAXY;
	static double[] coordsX;
	static double[] coordsY;
	
	
    static int find(int i) {
        if (i != parent[i]) 
            parent[i] = find(parent[i]);
        return parent[i];
    }

    static void union(int i, int j) {
        int pi = find(i);
        int pj = find(j);
        if (pi == pj) return;
        
        if (rank[pi] > rank[pj]) {
            int aux = pi; pi = pj; pj = aux;}
        
        parent[pi] = pj;
        
        if (rank[pi] == rank[pj])
            rank[pj]++;
    }
	
	public static void main(String[] args) throws FileNotFoundException
	{	
		Scanner input = new Scanner( System.in );
		MAXX = input.nextInt();
		MAXY = input.nextInt();
		N = input.nextInt();
		
		coordsX = new double[N];
		coordsY = new double[N];
		parent = new int[N+4];
		rank = new int[N+4];
		edges = new Edge[N*(N-1)/2+4*N];
		
		for (int i =0; i<N; ++i){
		    coordsX[i] = input.nextDouble();
		    coordsY[i] = input.nextDouble();
		}
		for (int i = 0; i<N+4; ++i) {
			parent[i] = i;
			rank[i] = 1;
		}
				
		int ctr = 0;
		for (int i = 0; i< N; ++i)
		    for (int j = i+1; j<N;++j) 
		        edges[ctr++] = new Edge(i,j,Math.sqrt((coordsY[i]-coordsY[j])*(coordsY[i]-coordsY[j])+(coordsX[i]-coordsX[j])*(coordsX[i]-coordsX[j]))/2);
	    
	    for (int i = 0; i< N; ++i) {
	        edges[ctr++] = new Edge(i,N,coordsX[i]); //left
	        edges[ctr++] = new Edge(i,N+1,MAXX-coordsX[i]); //right
	    	edges[ctr++] = new Edge(i,N+2,coordsY[i]); //down
	        edges[ctr++] = new Edge(i,N+3,MAXY-coordsY[i]);  //up
	    }
	    
	    Arrays.sort(edges, new Ioana1.EdgeComparator());
	    
	    int[] finds = new int[4];
	    for (int i = 0; i < edges.length; ++i) {
	        union(edges[i].n1, edges[i].n2);
	        for (int j = 0; j<4; j++)
	            finds[j] = find(N+j);
	        if (finds[0] == finds[1] || finds[2] == finds[3] 
	          || finds[0] == finds[2] || finds[1] == finds[3])
	          {
	            System.out.println(edges[i].val);
	            //System.out.printf("%.6f\n", edges[i].val);
	            return;
	          } 
	    }                         
	}
}
