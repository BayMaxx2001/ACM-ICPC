#! /usr/bin/env python3

try: input = raw_input
except: pass

XY_MAX = 10**6
N_MAX = 1000

import sys

line = [int(x) for x in sys.stdin.readline().split()]
assert(len(line)==2)

X = line[0]
Y = line[1]
assert(1 <= X <= XY_MAX)
assert(1 <= Y <= XY_MAX)

line = [int(x) for x in sys.stdin.readline().split()]
assert(len(line) == 1)
N = line[0]
assert(1 <= N <= N_MAX)

for _ in range(N):
    line = [float(x) for x in sys.stdin.readline().split()]
    assert(len(line)==2)

    x = line[0]
    y = line[1]
    assert(0 <= x <= X)
    assert(0 <= y <= Y)

exit(42)
