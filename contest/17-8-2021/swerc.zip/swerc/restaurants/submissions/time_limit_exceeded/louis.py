def ints():
    return list(map(int,input().split()))
def minusOne(l):
    return list(map(lambda x:x-1,l))

[N,M] = ints()
cap = [int(input()) for _ in range(M)]
c_pref = [minusOne(reversed(ints())) for _ in range(N)]
r_pref = [minusOne(filter(lambda x:x>0,ints())) for _ in range(M)]
r_rank = [{} for _ in range(M)]
for r in range(M):
    for cid in range(len(r_pref[r])):
        r_rank[r][r_pref[r][cid]] = cid
        
assigned_to = [None for _ in range(N)]
assigned_with = [[] for _ in range(M)]

modif=True
while modif:
    modif=False
    for client in range(N):
        if assigned_to[client] == None and c_pref[client] != []:
            rest = c_pref[client].pop()
            assigned_to[client] = rest
            assigned_with[rest].append(client)
            modif = True
    for rest in range(M):
        if len(assigned_with[rest])>cap[rest]:
            assigned_with[rest].sort(key=lambda c:r_rank[rest][c])
            while len(assigned_with[rest]) > cap[rest]:
                assigned_to[assigned_with[rest].pop()] = None
                modif = True
for c in range(N):
    if assigned_to[c] != None:
        print(c+1)
