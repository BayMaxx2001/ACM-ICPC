#!/usr/bin/env python3

import sys
import heapq

def linein():
    return sys.stdin.readline().strip().split()

if __name__=='__main__':
    #reading the data
    [N,M] = [int(x) for x in linein()]
    cap = []
    for _ in range(M): cap.append(int(linein()[0]))
    c_pref = []
    for _ in range(N): 
        c_pref.append([int(x) for x in linein()])
    #print (c_pref)
    r_pref = []
    r_ranked = []
    for i in range(M):
        r_pref.append(dict())
        r_ranked.append([])
        prfs = [int(x) for x in linein()]
        if not (len(prfs)==1 and prfs[0]==0):
            r_ranked[i] = prfs
            for j in range(len(prfs)):
                r_pref[i][prfs[j]] = j+1
    end = False
    r_allocs = [[] for _ in range(M)]
    pos = [0 for x in range(N)]
    found = [False] * N
    end = False
    #print (cap)
    #print (c_pref)
    #print (r_pref)
    #print (r_ranked)
    while not end:
        end = True
        for i in range(N):
            #print ('c %d'%i)
            if (not found[i]) and pos[i]<len(c_pref[i]):
                end = False
                #allocate to their best restaurant if possible
                r = c_pref[i][pos[i]]
                #print ('c %d r %d'%(i,r))
                if len(r_allocs[r-1])<cap[r-1]:
                    found[i] = True
                    heapq.heappush(r_allocs[r-1],N-r_pref[r-1][i+1])
                elif N-r_pref[r-1][i+1]>r_allocs[r-1][0]: 
                #r_pref[r][i] < r_pref[r][r_allocs[r-1]]: 
                    found[i] = True
                    heapq.heappush(r_allocs[r-1],N-r_pref[r-1][i+1])
                    #take out the lowest rank
                    lr = N - heapq.heappop(r_allocs[r-1])
                    #print(lr)
                    cl = r_ranked[r-1][lr-1]
                    #print(cl)
                    found[cl-1] = False
                #print(r_allocs)
                #print(found)
                pos[i] += 1
        #print(pos)
    for i in range(N):
        if found[i]:
            print(i+1)
