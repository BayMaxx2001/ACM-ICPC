#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <errno.h>

#define MAXN 50000 
#define MAXM 10000

struct PrefArray {
    int* choices;
    int choiceCount;
    int crtpointer;
};

typedef struct PrefArray PrefArray;

PrefArray restPrefs[MAXM];
PrefArray cliPrefs[MAXN];

int cap[MAXM];
int match[MAXN];

int restStack[MAXM];
int restStackSize;

int** rank;

int M,N;

char buffer[MAXN*6];
int tmp[MAXN];
int tmpptr;

void readPrefs(PrefArray* prefArray) 
{
    int inputInteger;
    char *endptr = NULL;
    char *input = fgets(buffer, MAXN*6, stdin);
    tmpptr = 0;
    errno = 0;
    
    while  (!errno) {
        errno = 0;
		inputInteger = strtol(input, &endptr, 10);
		if (endptr == input) break;
		input = endptr;
		
		if (errno == 0) {
		    if (inputInteger == 0)
		        return; //nothing to do here
		    tmp[tmpptr++] = inputInteger-1;
		}    
    } 		
    	
    prefArray->choiceCount = tmpptr;
    prefArray->choices = (int*)malloc(tmpptr*sizeof(int));
    memcpy(prefArray->choices, tmp, tmpptr*sizeof(int));
}

int main()
{
    int i;
    size_t ret;
      
    ret = scanf("%d %d", &N, &M); 
    for (i = 0; i<M; ++i) 
       ret = scanf("%d", &cap[i]);
    fgets(buffer, MAXN*6, stdin);
    (void)ret;
    
    rank = (int**) malloc(M*sizeof(int*));
    
    for (i = 0; i<N; ++i)
        readPrefs(&cliPrefs[i]);
    for (i = 0; i<M; ++i) {
        readPrefs(&restPrefs[i]); 
        rank[i] = (int*) malloc(N*sizeof(int));
    }
   
    memset(match, -1, N*sizeof(int));   
    restStackSize = 0;
    
    for (int i = 0; i< M; ++i) 
        if (restPrefs[i].choiceCount)
            restStack[restStackSize++] = i;    
    
    for (int i = 0; i< N; ++i) {
        PrefArray crt = cliPrefs[i];
        for (int j = 0; j<crt.choiceCount;++j)
            rank[crt.choices[j]][i] = j;
    }   
  
    while (restStackSize > 0) {
        int crt = restStack[--restStackSize]; //pop
        PrefArray* prefcrt = &restPrefs[crt];
       
        while (cap[crt] > 0) {
            if (prefcrt->crtpointer == prefcrt->choiceCount)
                break; //all clients have been considered;
                
            int crtcli = prefcrt->choices[prefcrt->crtpointer++];  
            int former = match[crtcli];           
            
            if (former != -1 && rank[crt][crtcli] > rank[former][crtcli]) 
                continue;
            
            if (former != -1){ //kick out the client from the former restaurant
                cap[former]++; //more space now
                if (cap[former] == 1) //was out of stack, push back
                    restStack[restStackSize++] = former; 
            }
            match[crtcli] = crt;
           
            cap[crt]--; //less space :p            
        }   
    }
    
    for (i = 0; i<N; ++i) if (match[i]!=-1) printf("%d\n",i+1);
    
    for (i = 0; i<M; ++i) {
        if (restPrefs[i].choices)
            free(restPrefs[i].choices); 
        if (rank[i])
            free(rank[i]);
    }
    for (i = 0; i<N; ++i) 
        if (cliPrefs[i].choices)
            free(cliPrefs[i].choices); 
   
}
