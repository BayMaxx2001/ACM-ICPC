let k = 50
let bitset = Array.make 10000000 0
let isSet x = 0 = (bitset.(x/k) land (1 lsr (x mod k)))
let set x = bitset.(x/k) <- bitset.(x/k) lor (1 lsr (x mod k))

let rec scan_list () =
  Scanf.scanf "%[^\n]\n" (fun x->x) |>
    String.split_on_char ' ' |>
    List.map (fun x -> try int_of_string x with _ -> 0) |>
    List.filter (fun x -> x>0) |>
    List.map (fun x -> x-1)
let n,m = Scanf.scanf "%d %d\n" (fun x y -> (x,y))
let capa_rest = Array.init m (fun x -> Scanf.scanf "%d\n" (fun x -> x)) 
let pref_client = Array.init n (fun x -> scan_list ())
let pref_rest = Array.init m (fun x -> scan_list () |> List.rev)
let assignement = Array.make n None 
let _ =
  let unassigned = ref [] in
  for client = 0 to n-1 do
    unassigned := client::!unassigned 
  done ;
  while !unassigned <> [] do
    let client::q = !unassigned in
    unassigned := q ;
    match pref_client.(client) with
    | [] -> ()
    | rest::remain ->
       pref_client.(client) <-remain ;
       if not ( isSet (rest*n+client))
       then
         begin
           assignement.(client) <- Some rest ;
           capa_rest.(rest) <- capa_rest.(rest)-1;
         end
       else
         unassigned := client::q ;
       while capa_rest.(rest) < 0 do
         match pref_rest.(rest) with
         | client::q ->
            pref_rest.(rest) <- q ;
            set (rest*n+client) ;
            if assignement.(client) = Some(rest)
            then
              begin
                assignement.(client) <- None ;
                unassigned := client::!unassigned ;
                capa_rest.(rest) <- 0 
              end
       done
  done ;
  Array.iteri (fun client r -> if r <> None then (print_int (1+client) ; print_newline ())) assignement
