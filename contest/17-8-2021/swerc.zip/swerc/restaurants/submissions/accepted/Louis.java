import java.io.*;
import java.util.*;

public class Louis {
    static int line[] = new int[50000];
    static BufferedReader br ;
    public static int read() throws IOException {
        if(br == null)
            br = new BufferedReader(new InputStreamReader(System.in));
        int i = 0;
        StringTokenizer stringtokenizer = new StringTokenizer(br.readLine());
        while(stringtokenizer.hasMoreElements())
            try {
                line[i] = Integer.parseInt(stringtokenizer.nextToken());
                i++;
            }
            catch(Exception exception) { }
        return i;
    }
    
    public static Deque<Integer> readDeque() throws IOException {
        int i = read();
        ArrayDeque<Integer> res = new ArrayDeque<Integer>();
        for(int j = 0; j < i ; j++)
            if(line[j] > 0)
                res.push(line[j] - 1);
        return res;
    }

    public static void main(String args[]) throws IOException {
        read();
        int N = line[0];
        int M = line[1];
        BitSet bitset = new BitSet(N * M);
        int capa_rest[] = new int[M];
        int assigned_to[] = new int[N];    
        for(int i = 0; i < M; i++) {
            read();
            capa_rest[i] = line[0];
        }
        ArrayList<Deque<Integer>> pref_client = new ArrayList<Deque<Integer>>();
        ArrayList<Deque<Integer>> pref_rest = new ArrayList<Deque<Integer>>();
        for(int i = 0; i < N; i++)
            pref_client.add(readDeque());
        for(int i = 0; i < M; i++)
            pref_rest.add(readDeque());
        ArrayDeque<Integer> to_assign = new ArrayDeque<Integer>();
        for(int i = 0; i < N; i++) {
                to_assign.push(i);
                assigned_to[i] = -1;
        }
        while( ! to_assign.isEmpty() ) {            
            int c = to_assign.pop();
            if(! pref_client.get(c).isEmpty()) {
                int r = pref_client.get(c).pollLast();
                if(!bitset.get(r * N + c)) {
                    capa_rest[r]--;
                    assigned_to[c] = r;
                } else
                    to_assign.push(c);

                while(capa_rest[r] < 0) {
                    int cr = pref_rest.get(r).pollFirst();
                    if(assigned_to[cr] == r) {
                        capa_rest[r]++;
                        assigned_to[cr] = -1;
                        to_assign.push(cr);
                    }
                    bitset.set(r * N + cr);
                }
            }
        }
        for(int i = 0; i < N; i++)
            if(assigned_to[i] >= 0)
                System.out.println(i + 1);
    }
}
