#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <errno.h>

#define MAXN 50000 
#define MAXM 10000

struct PrefArray {
    int* choices;
    int choiceCount;
    int crtpointer;
};

typedef struct PrefArray PrefArray;

PrefArray restPrefs[MAXM];
PrefArray cliPrefs[MAXN];

int cap[MAXM];
int match[MAXN];
int wsf[MAXM];

int cliStack[MAXN];
int cliStackSize;

int** rank;

int M,N;

char buffer[MAXN*6];
int tmp[MAXN];
int tmpptr;

void readPrefs(PrefArray* prefArray) 
{
    int inputInteger;
    char *endptr = NULL;
    char *input = fgets(buffer, MAXN*6, stdin);
    tmpptr = 0;
    errno = 0;
    
    while  (!errno) {
        errno = 0;
		inputInteger = strtol(input, &endptr, 10);
		if (endptr == input) break;
		input = endptr;
		
		if (errno == 0) {
		    if (inputInteger == 0)
		        return; //nothing to do here
		    tmp[tmpptr++] = inputInteger-1;
		}    
    } 		
    	
    prefArray->choiceCount = tmpptr;
    prefArray->choices = (int*)malloc(tmpptr*sizeof(int));
    memcpy(prefArray->choices, tmp, tmpptr*sizeof(int));
}

int main()
{
    int i;
    size_t ret;
      
    ret = scanf("%d %d", &N, &M); 
    for (i = 0; i<M; ++i) 
       ret = scanf("%d", &cap[i]);
    fgets(buffer, MAXN*6, stdin);
    (void)ret;
    
    rank = (int**) malloc(N*sizeof(int*));
    
    for (i = 0; i<N; ++i) {
        readPrefs(&cliPrefs[i]);
        rank[i] = (int*) malloc(M*sizeof(int));
    }    
    
    for (i = 0; i<M; ++i) 
        readPrefs(&restPrefs[i]); 
   
    memset(match, -1, N*sizeof(int));   
    memset(wsf, -1, M*sizeof(int));   
    
    cliStackSize = 0;
    
    for (int i = 0; i< N; ++i) 
        cliStack[cliStackSize++] = i;    
    
    for (int i = 0; i< M; ++i) {
        PrefArray crt = restPrefs[i];
        for (int j = 0; j<crt.choiceCount;++j)
            rank[crt.choices[j]][i] = j;
    }   
  
    while (cliStackSize > 0) {
        int crtcli = cliStack[--cliStackSize]; //pop
        PrefArray* prefcrt = &cliPrefs[crtcli];
        //printf("trying to match client %d\n",crtcli+1);
       
        if (prefcrt->crtpointer == prefcrt->choiceCount)
            continue; //have tried all
                
        int crtrest = prefcrt->choices[prefcrt->crtpointer++];
        //printf("next restaurant in his list is %d\n",crtrest+1);
        
        if (cap[crtrest] > 0) {
            match[crtcli] = crtrest;
            cap[crtrest]--;
            if (wsf[crtrest] < rank[crtcli][crtrest])
                wsf[crtrest] = rank[crtcli][crtrest];
        } else { //restaurant is full
           if (wsf[crtrest] < rank[crtcli][crtrest]) {
                cliStack[cliStackSize++] = crtcli;
                continue;
           }
            
           int* choices = restPrefs[crtrest].choices;
           match[crtcli] = crtrest;
           
           //kick out the worst client and push him back in the stack
           match[choices[wsf[crtrest]]] = -1;
           cliStack[cliStackSize++] = choices[wsf[crtrest]];
           
           //adjust wsf
           while (match[choices[--wsf[crtrest]]] != crtrest);
        }               
    }
    
    for (i = 0; i<N; ++i) if (match[i]!=-1) printf("%d\n",i+1);
    
    for (i = 0; i<M; ++i) {
        if (restPrefs[i].choices)
            free(restPrefs[i].choices);        
    }
    for (i = 0; i<N; ++i) {
        if (cliPrefs[i].choices)
            free(cliPrefs[i].choices);
        if (rank[i])
            free(rank[i]); 
    }
}
