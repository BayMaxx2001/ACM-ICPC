#!/usr/bin/env python3

import sys
import heapq

def linein():
    return sys.stdin.readline().strip().split()

if __name__=='__main__':
    #reading the data
    [N,M] = [int(x) for x in linein()]
    cap = []
    for _ in range(M): cap.append(int(linein()[0]))
    c_pref = []
    for _ in range(N): 
        c_pref.append([int(x) for x in linein()])
    #print (c_pref)
    r_pref = []
    r_ranked = []
    for i in range(M):
        r_pref.append(dict())
        r_ranked.append([])
        prfs = [int(x) for x in linein()]
        if not (len(prfs)==1 and prfs[0]==0):
            r_ranked[i] = prfs
            for j in range(len(prfs)):
                r_pref[i][prfs[j]] = j+1
    end = False
    r_allocs = [0 for _ in range(M)]
    c_alloc =[-1 for _ in range(N)]
    pos = [0 for x in range(N)]
    found = [False] * N
    ref_rank = [len(r_ranked[i]) for i in range(M)]
    end = False
    #print (cap)
    #print (c_pref)
    #print (r_pref)
    #print (r_ranked)
    cis = [True] * N 
    cq = list(range(N))
    while(len(cq)>0):
        i = cq.pop(0)
        #print(i)
        cis[i] = False
        if (not found[i]) and pos[i]<len(c_pref[i]):
            #allocate to their best restaurant if possible
            r = c_pref[i][pos[i]]
            #print ('c %d r %d - %d'%(i,r,r_pref[r-1][i+1]))
            if r_allocs[r-1]<cap[r-1]:
                found[i] = True
                c_alloc[i] = r-1
                r_allocs[r-1] += 1
                if ref_rank[r-1]<r_pref[r-1][i+1]:
                    ref_rank[r-1]=r_pref[r-1][i+1]
            elif r_pref[r-1][i+1]<ref_rank[r-1]: 
                found[i] = True
                c_alloc[i] = r-1
                #heapq.heappush(r_allocs[r-1],N-r_pref[r-1][i+1])
                #take out the lowest rank
                elim = False
                cl = -1
                while not elim:
                    #print(ref_rank[r-1])
                    #print(r_ranked[r-1][ref_rank[r-1]-1])
                    if c_alloc[r_ranked[r-1][ref_rank[r-1]-1]-1]==r-1:
                        #found a client at that rank
                        cl = r_ranked[r-1][ref_rank[r-1]-1]
                        elim = True
                    ref_rank[r-1] = ref_rank[r-1]-1
                #cl = r_ranked[r-1][lr-1]
                #print(cl)
                found[cl-1] = False
                if not cis[cl-1]:
                    cis[cl-1] = True
                    cq.append(cl-1)
                c_alloc[cl-1] = -1
            else:
                #put it back
                cis[i] = True
                cq.append(i)
            #print(r_allocs)
            #print(c_alloc)
            #print(ref_rank)
            #print(found)
            pos[i] += 1
        #print(cq)
        #print(pos)
    for i in range(N):
        if found[i]:
            print(i+1)
