import random

M = 10000
N = 100
c = 50

print ('%d %d'%(M,N))
for _ in range(N):
    print (c)

prefs = dict()
for cl in range(M):
    out = ''
    if random.random() > 0.3:
        v = random.randrange(1,N+1)
        out += '%d'%v
        if v not in prefs:
            prefs[v] = set()
        prefs[v].add(cl+1)
    else:
        lst = list(range(1,N+1))
        random.shuffle(lst)
        for i in lst:
            out += '%d '%i
            if i not in prefs:
                prefs[i] = set()
            prefs[i].add(cl+1)
    print(out)
    
for r in range(N):
    out = ''
    lst = list(prefs[r+1])
    random.shuffle(lst)
    for i in lst: out += '%d '%i
    print (out)
