#include <cstdio>
#include <vector>

using namespace std;

const int N = 50000, M = 10000, K=95;

vector<int> pref_rest [ M ] ;
vector<int> pref_client [ N ] ;

void add(int i, int j) {
  if(i>=N || j >= M)
    fprintf(stderr,"ERROR\n");
  pref_client[i].push_back(j);
  pref_rest[j].push_back(i);
}

int main () {
  printf("%d %d\n",N,M);
  for(int i = 0 ; i < M ; i++)
    printf("1\n");
  add(M,0);
  for(int i = M-K ; i < M ; i++)
    add(i,i);
  for(int i = 0 ; i+K < M ; i++) {
     add(i,i);
    for(int j = 0 ; j < K ; j++)
      add(i,M-K+j);
    add(i,i+1);
  }
  for(int i = M ; i < N ; i++)
    add(i,M-K+(i%K));

  for(int i = 0 ; i < N ; i++) {
    if(! pref_client[i].size())
      fprintf(stderr,"Empty for %d\n",i);
    for(size_t j = 0 ; j < pref_client[i].size() ; j++)
      printf("%d%c",1+pref_client[i][j],j+1==pref_client[i].size()?'\n':' ');
  }
  for(int i = 0 ; i < M ; i++)
    for(size_t j = 0 ; j < pref_rest[i].size() ; j++)
      printf("%d%c",1+pref_rest[i][j],j+1==pref_rest[i].size()?'\n':' ');
  return 0;
}
