#include <cstdio>
#include <vector>

using namespace std;

const int N = 50000, M = 10000 ;

vector<int> pref_rest [ M ] ;

int main () {
  printf("%d %d\n",N,M);
  for(int i = 0 ; i < M ; i++)
    printf("5\n");
  for(int i = 0 ; i < N ; i++) {
    for (int j = 0 ; j < 20 ; j ++) {
      const int rest = (i+j*499)%M ;
      pref_rest[rest].push_back(i);
      printf("%d%c",1+rest,j==19?'\n':' ');
    }
  }
  for(int i = 0 ; i < M ; i++)
    for (int j = 0 ; j < 100 ; j ++)
      printf("%d%c",1+pref_rest[i][j],j==99?'\n':' ');
  return 0;
}
