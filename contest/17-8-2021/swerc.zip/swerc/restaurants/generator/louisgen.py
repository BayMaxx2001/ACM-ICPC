import random

M = 10000
N = 50000
c = 10

print ('%d %d'%(N,M))
for _ in range(N):
    print (c)

pref_client = [ [] for _ in range(N+1) ]
sel = list(range(1,N+1))

for r in range(M):
    random.shuffle(sel)
    print(" ".join(map(str,sel[:c])))
    for cl in sel:
        pref_client[cl].append(r)
        
for l in pref_client:
    random.shuffle(l)
    print(" ".join(map(str,l)))
    
