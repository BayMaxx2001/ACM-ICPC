import random

M = 50000
N = 4

print ('%d %d'%(M,N))
for _ in range(N):
    print (5000)

for _ in range(M):
    out = ''
    lst = range(1,N+1)
    random.shuffle(lst)
    for i in lst:
        out += '%d '%i
    print(out)
    
for _ in range(N):
    out = ''
    for i in range(M,0,-1): out += '%d '%i
    print (out)
