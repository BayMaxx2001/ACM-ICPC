import random

M = 2000
N = 500
c = 1000

print ('%d %d'%(M,N))
for _ in range(N):
    print (c)

for _ in range(M):
    out = ''
    lst = range(1,N+1)
    random.shuffle(lst)
    for i in lst:
        out += '%d '%i
    print(out)
    
for _ in range(N):
    out = ''
    lst = range(1,M+1)
    random.shuffle(lst)
    for i in lst: out += '%d '%i
    print (out)
