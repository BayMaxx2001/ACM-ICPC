#include <cstdio>
#include <vector>

using namespace std;

const int N = 50000, M = 10000, K=100;

vector<int> pref_rest [ M ] ;

int main () {
  printf("%d %d\n",N,M);
  for(int i = 0 ; i < M ; i++)
    printf("5\n");
  for(int i = 0 ; i < K ; i++)
    for(int m = 0 ; m < M ; m++)
      printf("%d%c",1+(i+m+K)%M,m==M-1?'\n':' ');
  for(int i = K ; i < N ; i++) {
    printf("%d\n",1+i/5);
  }
  for(int i = 0 ; i < M ; i++) {
    printf("%d %d %d %d %d",i*5+1,i*5+2,i*5+3,i*5+4,i*5+5);
    for(int j = 0 ; j < K ; j++)
      if( j/5 != i)
        printf(" %d",j+1);
    printf("\n");
  }
  return 0;
}
