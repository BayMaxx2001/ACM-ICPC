#! /usr/bin/env python3

try: input = raw_input
except: pass

N_max = 50000
M_max = 10000
c_max = 10000
p_max = 1000000

import sys

line = [int(x) for x in sys.stdin.readline().split()]
assert(len(line)==2)

N = line[0]
M = line[1]
assert(1 <= M <= M_max)
assert(1 <= N <= N_max)

for _ in range(M):
    line = [int(x) for x in sys.stdin.readline().split()]
    assert(len(line) == 1)
    assert(1 <= line[0] <= c_max)

p_tot = 0
prefs = dict()
for i in range(N):
    line = [int(x) for x in sys.stdin.readline().split()]
    assert(len(line) >= 1)
    for x in line:
        assert (1 <= x <= M_max)
        if x not in prefs:
            prefs[x] = set()
        prefs[x].add(i+1)
        p_tot =+ 1

assert(1 <= p_tot <= p_max)

for i in range(M):
    line = [int(x) for x in sys.stdin.readline().split()]
    assert(len(line) >= 1)
    if not (line[0]==0 and len(line)==1):
        for x in line:
            assert (1 <= x <= N_max)
        assert(set(line) == prefs[i+1])

exit(42)
