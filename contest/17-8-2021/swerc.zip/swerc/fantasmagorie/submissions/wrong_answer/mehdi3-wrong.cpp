#include <cstdio>
#include <algorithm>
#include <cassert>

#define DEBUG 1

#if DEBUG
#define debug printf
#else
#define debug(...)
#endif

using namespace std;

const int MAX_H = 250;
const int MAX_W = 250;

typedef unsigned char depth_t;

const int MAX_DEPTH = (min(MAX_H, MAX_W) + 1) / 2;

inline int sign(int x) { return x >= 0 ? 1 : -1; }

struct pt {
    int y, x;
    pt(int y, int x): y(y), x(x) {}
    pt(): y(0), x(0) {}
    pt operator+ (const pt &o) const {
        return pt(y + o.y, x + o.x);
    }
    pt operator- (const pt &o) const {
        return pt(y - o.y, x - o.x);
    }
    void move_towards_delta(pt &delta) {
        if (abs(delta.y) >= abs(delta.x))
            y += sign(delta.y);
        else
            x += sign(delta.x);
    }
};

const pt dirs4[4] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
const pt dirs8[8] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {-1, 1}, {1, -1}, {1, 1}};

bool accepted_flips[256] = {
  0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0,
};

struct tr_t {
    bool b;
    depth_t d;
    tr_t(bool b, depth_t d): b(b), d(d) {}
    tr_t(): b(false), d(0) {}
};

bool pic[2][MAX_H][MAX_W];
tr_t tr[2][MAX_H][MAX_W];
depth_t bin[2];
pt repr[2][MAX_DEPTH + 1][2];
bool nb_branches[2];
depth_t max_depth[2][2];
bool inv_branches;
bool growing[MAX_H][MAX_W];
bool done_growing[MAX_H][MAX_W];
depth_t done_shrinking[MAX_H][MAX_W];

int H, W;

void go_medium() {
    puts("NOT IMPLEMENTED YET");
}

void flip(pt p) {
    printf("%d %d\n", p.x, p.y);
    #if DEBUG
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++)
            putchar('a' + tr[0][y][x].d - (y == p.y && x == p.x ? 32 : 0));
            //putchar(((tr[0][y][x].d & 1) ^ int(pic[0][y][x])) ? '.' : '#');
        putchar('\n');
    }
    #endif
}

bool can_flip(pt p) {
    int pat = 0;
    depth_t d = tr[0][p.y][p.x].d;
    for (int dy = -1; dy <= 1; dy++)
        for (int dx = -1; dx <= 1; dx++)
            if (dx != 0 || dy != 0)
                pat = (pat << 1) + (tr[0][p.y+dy][p.x+dx].d == d);
    #if DEBUG
    if (!accepted_flips[pat])
        debug("    cannot flip %d %d (pat = %d)\n", p.y, p.x, pat);
    #endif
    return accepted_flips[pat];
}

bool grow_zone(depth_t d, pt p) {
    if (d <= 1)
        return true;
    debug(" grow zone %d to %d %d (was %d)%s\n", d, p.y, p.x, tr[0][p.y][p.x].d,
        (tr[0][p.y][p.x].d >= d ? " nothing to do" : (growing[p.y][p.x] ? "can't grow" : "")));
    if (tr[0][p.y][p.x].d >= d)
        return true;
    if (growing[p.y][p.x])
        return false;
    growing[p.y][p.x] = true;
    bool worked = true;
    for (int z = 0; z < 8; z++)
        worked = worked && grow_zone(d - 1, p + dirs8[z]);
    worked = worked && can_flip(p);
    if (worked) {
        tr[0][p.y][p.x].d = d;
        flip(p);
    }
    growing[p.y][p.x] = false;
    return worked;
}

void grow_to_repr(depth_t d, pt cur) {
    debug("grow %d to repr from %d %d\n", d, cur.y, cur.x);
    pt delta = repr[1][d][0] - cur;
    debug("  delta %d %d\n", delta.y, delta.x);
    if (delta.x == 0 && delta.y == 0)
        return;
    cur.move_towards_delta(delta);
    if (!grow_zone(d, cur)) {
        printf("FAILED grow_to_repr!\n");
        exit(2);
    }
    grow_to_repr(d, cur);
}

void grow_to_new(depth_t d, pt p) {
    if (done_growing[p.y][p.x] || tr[1][p.y][p.x].d != d)
        return;
    done_growing[p.y][p.x] = true;
    if (!grow_zone(d, p)) {
        printf("FAILED grow_to_new!\n");
        exit(2);
    }
    for (int z = 0; z < 4; z++)
        grow_to_new(d, p + dirs4[z]);
}

bool shrink_if_needed(depth_t d, int y, int x) {
    if (tr[0][y][x].d != d || tr[1][y][x].d == d)
        return true;
    pt p(y, x);
    bool can = can_flip(p);
    if (can) {
        tr[0][y][x].d--;
        flip(p);
    }
    return can;
}

void shrink_to_new(depth_t d) {
    bool worked = false;
    // TODO: optimize with a queue
    while (!worked) {
        worked = true;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                worked = shrink_if_needed(d, y, x) && worked;
    }
}

pt find_repr(depth_t d) {
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            if (tr[0][y][x].d == d)
                return pt(y, x);
    assert (false);
}

void move_zone(depth_t d) {
    debug("Move zone %d\n", d);
    pt orig = find_repr(d);
    debug("Move zone %d from %d %d\n", d, orig.y, orig.x);
    grow_to_repr(d, orig);
    grow_to_new(d, repr[1][d][0]);
    shrink_to_new(d);
}

void go_easy() {
    for (depth_t d = max_depth[0][0]; d >= 2; d--)
        move_zone(d);
}

void floodfill(int p, int h, int w, bool c, tr_t f) {
    if (h < 0 || h >= H || w < 0 || w >= W || tr[p][h][w].d || pic[p][h][w] != c)
        return;
    tr[p][h][w] = f;
    for (int z = 0; z < 4; z++)
        floodfill(p, h + dirs4[z].y, w + dirs4[z].x, c, f);
}

void buildtree(int p) {
    for (int h = 0; h < H; h++)
        for (int w = 0; w < W; w++) {
            if (tr[p][h][w].d)
                continue;
            tr_t f = w > 0 ? tr_t(tr[p][h][w-1].b, tr[p][h][w-1].d + 1) : tr_t(0, 1);
            if (repr[p][f.d][f.b].x > 0) {
                bin[p] = f.d;
                f.b = true;
                nb_branches[p] = true;
            }
            max_depth[p][f.b] = max(max_depth[p][f.b], f.d);
            repr[p][f.d][f.b] = pt(h, w);
            floodfill(p, h, w, pic[p][h][w], f);
        }
}

bool readpix() {
   for (int c; (c = getchar()); )
        if (c == '.')
            return 0;
        else if (c == '#')
            return 1;
    exit(1);
}

void readpic(int p) {
    for (int h = 0; h < H; h++)
        for (int w = 0; w < W; w++)
            pic[p][h][w] = readpix();
}

int main() {
    scanf("%d%d", &W, &H);
    for (int p = 0; p < 2; p++) {
        readpic(p);
        buildtree(p);
        if (max_depth[p][0] < max_depth[p][1])
            inv_branches ^= 1;
    }
    debug("First pixel: 0 -> %d, 1 -> %d\n", int(pic[0][0][0]), int(pic[1][0][0]));
    debug("Nb branches: 0 -> %d, 1 -> %d\n", nb_branches[0], nb_branches[1]);
    debug("Binary node depth: 0 -> %d, 1 -> %d\n", bin[0], bin[1]);
    debug("Branches depths: 0 -> %d %d, 1 -> %d %d\n",
        max_depth[0][0], max_depth[0][1], max_depth[1][0], max_depth[1][1]);
    debug("Branches are inverted: %d\n", inv_branches);
    if (pic[0][0][0] != pic[1][0][0]
            || nb_branches[0] != nb_branches[1]
            || bin[0] != bin[1]
            || max_depth[0][0] != max_depth[1][inv_branches]
            || max_depth[0][1] != max_depth[1][!inv_branches]) {
        puts("IMPOSSIBLE");
        return 0;
    }
    if (nb_branches[0]) {
        go_medium();
    } else {
        go_easy();
    }
    return 0;
}
