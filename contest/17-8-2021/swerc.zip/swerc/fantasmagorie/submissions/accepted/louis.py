from itertools import product

dirs = [ (1,0),(0,1),(-1,0),(0,-1)]
def get(pos,d):
    return (pos[0]+dirs[d][0],pos[1]+dirs[d][1])

def findfirst(grid,color,xmin,ymin,xmax,ymax):
    for y in range(ymin,ymax):
        for x in range(xmin,xmax):
            if grid[y][x] == color:
                return (x,y-1)

def switchgrid(grid,xmin,ymin,xmax,ymax,res):
    color = {'#':'.', '.':'#'}.get(grid[ymax][xmax])
    posInit = findfirst(grid,color,xmin,ymin,xmax,ymax)
    if posInit == None:
        return res
    (x,y) = get(posInit,0)
    curDir = 0
    prevPos = [(x,y,curDir)]
    while (x,y) != posInit:
        (xf,yf) = get((x,y),curDir)
        (xl,yl) = get((x,y),(curDir+1)%4)
        (xr,yr) = get((x,y),(curDir+3)%4)
        (xbr,ybr) = get((xr,yr),(curDir+2)%4)
        if grid[yl][xl] == color:
            if grid[yf][xf] == color: # we have something in front and in left we fill a block
                if grid[ybr][xbr] == color and grid[yr][xr] != color:
                    prevPos.append((x,y,curDir))
                    curDir = (curDir+3)%4 # special turn
                else:    
                    res.append((x,y))
                    grid[y][x] = color
                    prevPos.pop()
                    (x,y,curDir) = prevPos.pop()                    
            else: # we have something left but not in front we advance
                prevPos.append((x,y,curDir))
                (x,y) = get((x,y),curDir)
        else: # we can turn left
            prevPos.append((x,y,curDir))
            curDir = (curDir+1)%4
            (x,y) = get((x,y),curDir)
    xs,ys = zip(*[ (x,y) for y in range(ymin,ymax) for x in range(xmin,xmax) if grid[y][x] == color])
    x1,x2,y1,y2 = min(xs),max(xs),min(ys),max(ys)
    flips  = list(product(range(x1-1,xmin-1,-1),range(y1,y2+1))) + \
             list(product(range(x2+1,xmax),range(y1,y2+1))) + \
             list(product(range(xmin,xmax),range(y1-1,ymin-1,-1))) + \
             list(product(range(xmin,xmax),range(y2+1,ymax)))
    for (x,y) in flips:            
        grid[y][x] = color
    return switchgrid(grid,xmin+1,ymin+1,xmax-1,ymax-1,res+flips)
W,H = map(int,input().split())
r,g = [],[]
for _ in range(2):
    g.append([list(input()) for _ in range(H)])
    r.append(switchgrid(g[-1],1,1,W-1,H-1,[]))
if g[0] == g[1]:
    for (x,y) in r[0]+list(reversed(r[1])):
        print(str(x)+" "+str(y))
else:
    print("IMPOSSIBLE")    
