#include <cstdio>
#include <algorithm>

/*
    Like mehdi-simple
    Cleaned up (no debug, work only for easy)
*/

using namespace std;

const int MAX_H = 250;
const int MAX_W = 250;

const struct {int y, x;} dirs4[4] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

bool accepted_flips[256] = {
  0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0,
};

bool pic[2][MAX_H][MAX_W];
int tr[3][MAX_H][MAX_W];
int max_depth[2];
int H, W;

bool try_flip(int y, int x, int md) {
    int pat = 0;
    int d = tr[0][y][x];
    for (int dy = -1; dy <= 1; dy++)
        for (int dx = -1; dx <= 1; dx++)
            if (dx != 0 || dy != 0)
                pat = (pat << 1) + (tr[0][y+dy][x+dx] == d);
    bool can = accepted_flips[pat];
    if (can) {
        tr[0][y][x] = md;
        printf("%d %d\n", x, y);
    }
    return can;
}

void morph(int md, int df, int o) {
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            tr[2][y][x] = max(tr[o][y][x], min(md,min(1+min(y, x), min(H-y,W-x))));
    bool finished = false;
    // TODO: optimize with a queue
    while (!finished) {
        finished = true;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                if (tr[0][y][x] == df && tr[2][y][x] == md && !try_flip(y, x, md))
                    finished = false;
    }
}

void go_easy() {
    int md = max_depth[0];
    for (int d = 2; d <= md; d++)
        morph(d, d - 1, 0);
    for (int d = md - 1; d >= 1; d--)
        morph(d, d + 1, 1);
}

void floodfill(int p, int h, int w, bool c, int f) {
    if (h < 0 || h >= H || w < 0 || w >= W || tr[p][h][w] || pic[p][h][w] != c)
        return;
    tr[p][h][w] = f;
    for (int z = 0; z < 4; z++)
        floodfill(p, h + dirs4[z].y, w + dirs4[z].x, c, f);
}

void compute_depth(int p) {
    for (int h = 0; h < H; h++)
        for (int w = 0; w < W; w++) {
            if (tr[p][h][w])
                continue;
            int f = w > 0 ? tr[p][h][w-1] + 1 : 1;
            max_depth[p] = max(max_depth[p], f);
            floodfill(p, h, w, pic[p][h][w], f);
        }
}

bool readpix() {
   for (int c; (c = getchar()); )
        if (c == '.')
            return 0;
        else if (c == '#')
            return 1;
    exit(1);
}

int main() {
    scanf("%d%d", &W, &H);
    for (int p = 0; p < 2; p++) {
        for (int h = 0; h < H; h++)
            for (int w = 0; w < W; w++)
                pic[p][h][w] = readpix();
        compute_depth(p);
    }
    if (pic[0][0][0] != pic[1][0][0] || max_depth[0] != max_depth[1])
        puts("IMPOSSIBLE");
    else
        go_easy();
    return 0;
}
