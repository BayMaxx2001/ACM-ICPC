#include <cstdio>
#include <algorithm>
#include <cassert>

#define DEBUG 0

#if DEBUG
#define debug printf
#else
#define debug(...)
#endif

using namespace std;

const int MAX_H = 250;
const int MAX_W = 250;

typedef unsigned char depth_t;

const int MAX_DEPTH = (min(MAX_H, MAX_W) + 1) / 2;

inline int sign(int x) { return x >= 0 ? 1 : -1; }

struct pt {
    int y, x;
    pt(int y, int x): y(y), x(x) {}
    pt(): y(0), x(0) {}
    pt operator+ (const pt &o) const {
        return pt(y + o.y, x + o.x);
    }
    pt operator- (const pt &o) const {
        return pt(y - o.y, x - o.x);
    }
    void move_towards_delta(pt &delta) {
        if (abs(delta.y) >= abs(delta.x))
            y += sign(delta.y);
        else
            x += sign(delta.x);
    }
};

const pt dirs4[4] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
const pt dirs8[8] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {-1, 1}, {1, -1}, {1, 1}};

bool accepted_flips[256] = {
  0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0,
};

struct tr_t {
    bool b;
    depth_t d;
    tr_t(bool b, depth_t d): b(b), d(d) {}
    tr_t(): b(false), d(0) {}
};

bool pic[2][MAX_H][MAX_W];
tr_t tr[3][MAX_H][MAX_W];
depth_t bin[2];
pt repr[2][MAX_DEPTH + 1][2];
bool nb_branches[2];
depth_t max_depth[2][2];
bool inv_branches;

int H, W;

void go_medium() {
    puts("NOT IMPLEMENTED YET");
}

#if DEBUG
void debug_print_pic(int o, pt high) {
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++)
            putchar('a' + tr[o][y][x].d - (y == high.y && x == high.x ? 32 : 0));
        putchar('\n');
    }
}
#else
#define debug_print_pic(...)
#endif

void flip(pt p) {
    printf("%d %d\n", p.x, p.y);
    debug_print_pic(0, p);
}

bool can_flip(pt p) {
    int pat = 0;
    depth_t d = tr[0][p.y][p.x].d;
    for (int dy = -1; dy <= 1; dy++)
        for (int dx = -1; dx <= 1; dx++)
            if (dx != 0 || dy != 0)
                pat = (pat << 1) + (tr[0][p.y+dy][p.x+dx].d == d);
    #if DEBUG
    if (!accepted_flips[pat])
        debug("    cannot flip %d %d (pat = %d)\n", p.y, p.x, pat);
    #endif
    return accepted_flips[pat];
}

bool flip_if_needed(depth_t d, depth_t df, int o, int y, int x) {
    if (tr[0][y][x].d != df || tr[o][y][x].d != d)
        return true;
    pt p(y, x);
    bool can = can_flip(p);
    if (can) {
        tr[0][y][x].d = d;
        flip(p);
    }
    return can;
}

void easy_morph(depth_t d, depth_t df, int o) {
    debug("  easy morph d= %d, df= %d, o= %d\n", d, df, o);
    bool worked = false;
    // TODO: optimize with a queue
    while (!worked) {
        worked = true;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                worked = flip_if_needed(d, df, o, y, x) && worked;
    }
}

void morph_up(int md) {
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            tr[2][y][x].d = max(int(tr[0][y][x].d), min(md,min(1+min(y, x), min(H-y,W-x))));
    debug_print_pic(2, pt(-1,-1));
    easy_morph(md, md - 1, 2);
}

void morph_down(int md) {
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            tr[2][y][x].d = max(int(tr[1][y][x].d), min(md,min(1+min(y, x), min(H-y,W-x))));
    debug_print_pic(2, pt(-1, -1));
    easy_morph(md, md + 1, 2);
}

void go_easy() {
    int md = max_depth[0][0];
    debug("morph up\n");
    for (depth_t d = 2; d <= md; d++)
        morph_up(d);
    debug("morph down\n");
    for (depth_t d = md - 1; d >= 1; d--)
        morph_down(d);
}

void floodfill(int p, int h, int w, bool c, tr_t f) {
    if (h < 0 || h >= H || w < 0 || w >= W || tr[p][h][w].d || pic[p][h][w] != c)
        return;
    tr[p][h][w] = f;
    for (int z = 0; z < 4; z++)
        floodfill(p, h + dirs4[z].y, w + dirs4[z].x, c, f);
}

void buildtree(int p) {
    for (int h = 0; h < H; h++)
        for (int w = 0; w < W; w++) {
            if (tr[p][h][w].d)
                continue;
            tr_t f = w > 0 ? tr_t(tr[p][h][w-1].b, tr[p][h][w-1].d + 1) : tr_t(0, 1);
            if (repr[p][f.d][f.b].x > 0) {
                bin[p] = f.d;
                f.b = true;
                nb_branches[p] = true;
            }
            max_depth[p][f.b] = max(max_depth[p][f.b], f.d);
            repr[p][f.d][f.b] = pt(h, w);
            floodfill(p, h, w, pic[p][h][w], f);
        }
}

bool readpix() {
   for (int c; (c = getchar()); )
        if (c == '.')
            return 0;
        else if (c == '#')
            return 1;
    exit(1);
}

void readpic(int p) {
    for (int h = 0; h < H; h++)
        for (int w = 0; w < W; w++)
            pic[p][h][w] = readpix();
}

int main() {
    scanf("%d%d", &W, &H);
    for (int p = 0; p < 2; p++) {
        readpic(p);
        buildtree(p);
        if (max_depth[p][0] < max_depth[p][1])
            inv_branches ^= 1;
    }
    debug("First pixel: 0 -> %d, 1 -> %d\n", int(pic[0][0][0]), int(pic[1][0][0]));
    debug("Nb branches: 0 -> %d, 1 -> %d\n", nb_branches[0], nb_branches[1]);
    debug("Binary node depth: 0 -> %d, 1 -> %d\n", bin[0], bin[1]);
    debug("Branches depths: 0 -> %d %d, 1 -> %d %d\n",
        max_depth[0][0], max_depth[0][1], max_depth[1][0], max_depth[1][1]);
    debug("Branches are inverted: %d\n", inv_branches);
    if (pic[0][0][0] != pic[1][0][0]
            || nb_branches[0] != nb_branches[1]
            || bin[0] != bin[1]
            || max_depth[0][0] != max_depth[1][inv_branches]
            || max_depth[0][1] != max_depth[1][!inv_branches]) {
        puts("IMPOSSIBLE");
        return 0;
    }
    if (nb_branches[0]) {
        go_medium();
    } else {
        go_easy();
    }
    return 0;
}
