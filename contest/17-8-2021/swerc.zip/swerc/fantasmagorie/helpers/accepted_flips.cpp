#include <cstdio>

/* Base accepted flips
  .#.   ##.   ###   ##.   ###
  .X.   .X.   .X.   #X.   #X.
  ...   ...   ...   ...   ...
  ...
*/
int base[] = {2, 3, 7, 11, 15};

/* Index based on bits
   012
   3 4
   567 */
bool accepted_flips[1 << 8];

/* Rotate Rotate Mirror Mirror
    530    765   567    210
    6 1    4 3   3 4    4 3
    742    210   012    765 */
int symmetries[4][8] = {
    {5, 3, 0, 6, 1, 7, 4, 2},
    {7, 6, 5, 4, 3, 2, 1, 0},
    {5, 6, 7, 3, 4, 0, 1, 2},
    {2, 1, 0, 4, 3, 7, 6, 5}
};

int conv(int i, int s) {
    int r = 0;
    for (int b = 0; b < 8; b++)
        r = (r << 1) + ((i >> symmetries[s][b]) & 1);
    return r;
}

int main() {
    for (int b = 0; b < 5; b++)
        accepted_flips[base[b]] = true;
    for (int s = 0; s < 4; s++)
        for (int i = 0; i < 256; i++)
            if (accepted_flips[i])
                accepted_flips[conv(i, s)] = true;
    for (int i = 0; i < 256; i++)
        if (accepted_flips[i])
            accepted_flips[(~i) & 255] = true;
    printf("bool accepted_flips[256] = {\n  ");
    for (int i = 0; i < 256; i++)
        printf("%d,%s ", int(accepted_flips[i]), (i & 15) == 15 ? "\n " : "");
    printf("};\n");
    return 0;
}
