#include <cstdio>
#include <cstdlib>
#include <unistd.h>

const int MAX_H = 250;
const int MAX_W = 250;

char pic[2][MAX_H * (MAX_W + 1) + 1];

int H, W;
int sleep_us = 100 * 1000;

char readpix() {
   for (int c; (c = getchar()); )
        if (c == '.' || c == '#')
            return c;
    exit(1);
}

void readpic(int p) {
    for (int h = 0; h < H; h++) {
        for (int w = 0; w < W; w++)
            pic[p][h * (W+1) + w] = readpix();
        pic[p][h * (W+1) + W] = '\n';
    }
}

void printpic(int p) {
    puts(pic[p]);
    usleep(sleep_us);
}

void flip(int y, int x) {
    char& c = pic[0][y * (W + 1) + x];
    c = c == '.' ? '#' : '.';
}

int usage(char** argc) {
    printf("Usage: %s <input file> <answer>\n\n"
        "WARNING: this is not a checker\n", argc[0]);

    return 1;
}

int main(int argv, char** argc) {
    if (argv < 3 || argv > 4)
        return usage(argc);
    if (argv == 4)
        sleep_us = atoi(argc[3]) * 1000;
    if (!freopen(argc[1], "r", stdin))
        return usage(argc);
    scanf("%d%d", &W, &H);
    for (int p = 0; p < 2; p++)
        readpic(p);
    if (!freopen(argc[2], "r", stdin))
        return usage(argc);
    for (int i = 0; i < 100; i++)
        puts("");
    printpic(0);
    int x, y;
    while (scanf("%d%d", &x, &y) == 2) {
        flip(y, x);
        printpic(0);
    }
    return 0;
}
