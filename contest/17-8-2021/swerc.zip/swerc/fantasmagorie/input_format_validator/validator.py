#! /usr/bin/python3

MAX_H = 64
MAX_W = 103

import sys

def myint(s):
    assert s == "0" or not s.startswith("0"),\
            "leading 0 detected"
    return int(s)

lines = [ l[:-1] for l in sys.stdin.readlines()]

W, H = map(myint, lines[0].split())
assert(1 <= W <= MAX_W)
assert(1 <= H <= MAX_H)

assert(len(lines) == 1 + 2 * H)

pics = [lines[1:H+1], lines[H+1:2*H+1]]

for p in pics:
    border = p[0][0]
    for lin in p:
        assert(len(lin) == W)
        for pix in lin:
            assert(pix in '.#')
        assert(lin[0] == border)
        assert(lin[-1] == border)
    assert(p[0] == border * W)
    assert(p[-1] == p[0])
    for l in range(H - 1):
        for c in range(W - 1):
            assert(p[l][c] == p[l][c+1] or p[l][c] == p[l+1][c] or p[l][c] != p[l+1][c+1])

# TODO: check only one zone is nested within another one

assert(pics[0] != pics[1])

exit(42)
