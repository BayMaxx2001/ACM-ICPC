// usage: ./a.out input_file correct_output output_dir < contestants_output
// See specification there:
// http://www.problemarchive.org/wiki/index.php/Output_validator

#include <iostream>
#include "validate.h"

const int MAX_H = 64;
const int MAX_W = 103;
const int MAX_FLIPS = 250 * 1000;

char pic[2][MAX_H][MAX_W];

std::string impossible("IMPOSSIBLE");

bool accepted_flips[256] = {
  0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
  1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1,
  1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0,
};

void flip(int i, int l, int c) {
    int pat = 0;
    for (int dl = -1; dl <= 1; dl++)
        for (int dc = -1; dc <= 1; dc++)
            if (dc != 0 || dl != 0)
                pat = (pat << 1) + int(pic[0][l+dl][c+dc]);
    if (accepted_flips[pat]) {
      pic[0][l][c] = 1 - pic[0][l][c];
    } else {
      judge_message("Line %d (%d, %d): forbidden flip (pat = %03o)\n", i, c, l, pat);
      for (int dl = -1; dl <= 1; dl++)
        judge_message("  %c%c%c\n",
          pic[0][l+dl][c-1] ? '#' : '.',
          pic[0][l+dl][c] ? '#' : '.',
          pic[0][l+dl][c+1] ? '#' : '.'
        );
      wrong_answer("Wrong answer\n");
    }
}

char readpix(std::istream& input) {
  for (char c; input >> c; )
    if (c == '.')
      return 0;
    else if (c == '#')
      return 1;
  judge_error("Invalid input file\n");
  exit(1);
}

int main(int argc, char **argv) {
  init_io(argc, argv);

  std::string first_ans_word;
  judge_ans >> first_ans_word;
  if (first_ans_word == impossible) {
    std::string first_out_word;
    author_out >> first_out_word;
    if (first_out_word != impossible) {
      judge_message("IMPOSSIBLE expected. Got '%s'\n", first_out_word);
      wrong_answer("Wrong answer\n");
    } else {
      char c;
      while (author_out >> c)
        if (c != ' ' && c != '\n') {
          judge_message("Non-blank char '%c' after IMPOSSIBLE\n", c);
          wrong_answer("Invalid input\n");
        }
      judge_message("Correct IMPOSSIBLE\n");
      accept();
    }
  } else {
    int W, H;
    judge_in >> W >> H;
    for (int p = 0; p < 2; p++)
      for (int l = 0; l < H; l++)
        for (int c = 0; c < W; c++)
          pic[p][l][c] = readpix(judge_in);
    int ol, oc;
    int n_flips = 0;
    for (; author_out >> oc >> ol; n_flips++) {
      if (n_flips >= MAX_FLIPS) {
        judge_message("Too many flips\n");
        wrong_answer("Wrong answer\n");
      }
      if (ol <= 0 || ol >= H-1 || oc <= 0 || oc >= W-1) {
        judge_message("Line %d, invalid coordinates (%d, %d)\n", n_flips, oc, ol);
        wrong_answer("Wrong answer\n");
      }
      flip(n_flips, ol, oc);
    }
    judge_message("Did %d flips\n", n_flips);
    char c;
    while (author_out >> c)
      if (c != ' ' && c != '\n') {
        judge_message("Non-blank char '%c' after non-impossible\n", c);
        wrong_answer("Invalid input\n");
      }
    for (int l = 0; l < H; l++)
      for (int c = 0; c < W; c++)
        if (pic[0][l][c] != pic[1][l][c]) {
          judge_message("Images not matching at (%d, %d)\n", c, l);
          wrong_answer("Wrong answer\n");
        }
    judge_message("Correct non-impossible\n");
    accept();
  }

  judge_error("Unexpected ending\n");
}
