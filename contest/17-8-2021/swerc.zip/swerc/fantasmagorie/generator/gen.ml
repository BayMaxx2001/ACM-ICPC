let first_test_id = 6

let w = 103

let h = 64

let dirs = [ (-1, 0); (1, 0); (0, -1); (0, 1) ]

type color = W | B

let invert = function W -> B | B -> W

let parity lv co = if lv mod 2 = 0 then co else invert co

let uni color = Array.make_matrix h w color

let flip image l c = image.(l).(c) <- invert image.(l).(c)

let fill_h image l c0 c1 co =
  for c = c0 to c1 do
    image.(l).(c) <- co
  done

let fill_v image l0 l1 c co =
  for l = l0 to l1 do
    image.(l).(c) <- co
  done

let fill_rec image l0 l1 c0 c1 co =
  for l = l0 to l1 do
    for c = c0 to c1 do
      image.(l).(c) <- co
    done
  done

let randd n = (Random.int n, Random.int n)

let randpix ?sin:((sinla, sinlz), (sinca, sincz) = ((1, h - 2), (1, w - 2))) ()
    =
  ( sinla + Random.int (sinlz - sinla + 1),
    sinca + Random.int (sincz - sinca + 1) )

let check_col r l c co = l >= 0 && l < h && c >= 0 && c < w && r.(l).(c) = co

let all_white () = uni W

let one_pixel () =
  let r = uni W in
  let l, c = randpix () in
  flip r l c;
  r

let nested ?inl:(inla, inlz = (0, h - 1)) ?inc:(inca, incz = (0, w - 1)) lvl co0
    =
  let r = uni co0 in
  for lv = 1 to lvl - 1 do
    let co = parity lv co0 in
    if inla + lv <= inlz - lv && inca + lv <= incz - lv then (
      fill_h r (inla + lv) (inca + lv) (incz - lv) co;
      fill_h r (inlz - lv) (inca + lv) (incz - lv) co;
      fill_v r (inla + lv) (inlz - lv) (inca + lv) co;
      fill_v r (inla + lv) (inlz - lv) (incz - lv) co )
  done;
  fill_rec r (inla + lvl) (inlz - lvl) (inca + lvl) (incz - lvl)
    (parity lvl co0);
  r

let full_nested () = nested ((min w h / 2) - 1) W

let full_nested_inverted () = nested ((min w h / 2) - 1) B

let almost_full_nested () = nested ((min w h / 2) - 2) W

let nested_top_left () =
  nested ~inl:(0, h * 2 / 3) ~inc:(0, w * 2 / 3) (min w h) W

let nested_bottom_right () =
  nested
    ~inl:(h - 1 - (h * 2 / 3), h - 1)
    ~inc:(w - 1 - (w * 2 / 3), w - 1)
    (min w h) W

let one_big_rectangle () = nested 1 W

let almost_one_big_rectangle () =
  let r = nested 1 W in
  let c = ref (1 + Random.int (h - 3)) in
  let l = ref (1 + Random.int (w - 3)) in
  let i = ref 0 in
  while !c >= 1 && !l >= 1 do
    r.(!l).(!c) <- W;
    if !i mod 2 = 0 then decr c else decr l;
    incr i
  done;
  r

let find_free ~th ~bg r l c (dl, dc) ~max =
  let rec loop dm =
    if dm > max then max
    else
      let l' = l + (dl * dm) and c' = c + (dc * dm) in
      if not (check_col r l' c' bg) then dm - 1
      else
        let rec thloop t =
          if t > th then loop (dm + 1)
          else if
            check_col r (l' + (dc * t)) (c' + (dl * t)) bg
            && check_col r (l' - (dc * t)) (c' - (dl * t)) bg
          then thloop (t + 1)
          else dm - 1
        in
        thloop 1
  in
  loop th

let maze_with_start ?(th = 1) r sl sc =
  let rec loop ~bg l c =
    let adirs =
      List.filter_map
        (fun (dl, dc) ->
          let dm = find_free r ~bg ~th l c (dl, dc) ~max:(5 + (th * th)) in
          if dm <= th then None else Some (dl, dc, dm - 1))
        dirs
    in
    match adirs with
    | [] -> ()
    | _ :: _ ->
        let dl, dc, dm = List.nth adirs (Random.int (List.length adirs)) in
        let m = 1 + Random.int dm in
        for i = 1 to m do
          for t = -(th - 1) to th - 1 do
            r.(l + (dl * i) + (dc * t)).(c + (dc * i) + (dl * t)) <- invert bg
          done
        done;
        for i = m downto th do
          loop ~bg (l + (dl * (i - (th - 1)))) (c + (dc * (i - (th - 1))))
        done;
        loop ~bg l c
  in
  let bg = invert r.(sl).(sc) in
  loop ~bg sl sc

let maze_on ?sin r =
  let l, c = randpix ?sin () in
  flip r l c;
  maze_with_start r l c

let maze () =
  let r = uni W in
  maze_on r;
  r

let thick_maze () =
  let r = uni W in
  let th = 2 in
  let l, c = randpix ~sin:((th, h - 1 - th), (th, w - 1 - th)) () in
  fill_rec r
    (l - (th - 1))
    (l + (th - 1))
    (c - (th - 1))
    (c + (th - 1))
    (invert r.(l).(c));
  maze_with_start r ~th l c;
  r

let nested_maze k =
  let r = uni W in
  let max_th = min h w / k in
  let l, c =
    randpix ~sin:((max_th, h - 1 - max_th), (max_th, w - 1 - max_th)) ()
  in
  let rec loop th =
    if th < 1 then r
    else (
      fill_rec r
        (l - (th - 1))
        (l + (th - 1))
        (c - (th - 1))
        (c + (th - 1))
        (invert r.(l).(c));
      maze_with_start r ~th l c;
      let th = if th > 10 then th - 2 else th - 1 in
      loop th )
  in
  loop max_th

let nested_maze3 () = nested_maze 3

let nested_maze5 () = nested_maze 5

let nested_maze10 () = nested_maze 10

let maze_in_nested () =
  let lvl = min h w / 5 in
  let dla, dca = randd 3 in
  let dlz, dcz = randd 3 in
  let r = nested ~inl:(dla, h - 1 - dlz) ~inc:(dca, w - 1 - dcz) lvl B in
  let sin =
    ( (dla + lvl + 1, h - 1 - dlz - (dla + lvl + 1)),
      (dca + lvl + 1, w - 1 - dcz - (dca + lvl + 1)) )
  in
  maze_on ~sin r;
  r

let nested_plus_maze () =
  let dl, dc = randd (min (h - 1 - (h * 2 / 3)) (w - 1 - (w * 2 / 3))) in
  let r =
    nested ~inl:(dl, dl + (h * 2 / 3)) ~inc:(dc, dc + (w * 2 / 3)) (min w h) W
  in
  let sl =
    if dl < (h - 1 - (h * 2 / 3)) / 2 then dl + (h * 2 / 3) - 1 else dl + 1
  in
  let sc =
    if dc < (w - 1 - (w * 2 / 3)) / 2 then dc + (w * 2 / 3) - 1 else dc + 1
  in
  maze_with_start r sl sc;
  r

let tests =
  [|
    (* IMPOSSIBLE cases *)
    (all_white, one_pixel);
    (full_nested, almost_full_nested);
    (full_nested, full_nested_inverted);
    (* POSSIBLE cases *)
    (one_pixel, one_pixel);
    (one_pixel, one_big_rectangle);
    (one_pixel, almost_one_big_rectangle);
    (maze, maze);
    (maze, thick_maze);
    (nested_top_left, nested_bottom_right);
    (maze_in_nested, maze_in_nested);
    (nested_plus_maze, nested_plus_maze);
    (nested_maze3, nested_maze3);
    (nested_maze5, nested_maze5);
    (nested_maze10, nested_maze10);
  |]

let print_image oc image =
  for l = 0 to Array.length image - 1 do
    for c = 0 to Array.length image.(l) - 1 do
      output_char oc (match image.(l).(c) with W -> '.' | B -> '#')
    done;
    output_char oc '\n'
  done

let print_test id (first_image, second_image) =
  Random.init id;
  let filename = Printf.sprintf "test-%02d.in" id in
  let oc = open_out filename in
  output_string oc (Format.sprintf "%d %d\n" w h);
  print_image oc (first_image ());
  print_image oc (second_image ());
  close_out oc

let () =
  for i = 0 to Array.length tests - 1 do
    print_test (first_test_id + i) tests.(i)
  done
