for i in range(13):
    name = "test" + str(i).zfill(2)
    print(name)
    with open("data/secret/" + name + ".in", "rt") as f:
        s = f.readline().strip()
    with open("data/secret/" + name + ".ans", "rt") as f:
        ss = f.readline().strip()
    beg = s.find(ss)
    assert beg >= 0
    assert s.find(ss, beg+1) == -1
    