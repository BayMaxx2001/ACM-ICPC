#include <cstdio>
#include <algorithm>
#include <string.h>
#include <vector>

typedef unsigned long long llu ;
char input[300001] ;
std::pair<llu,int> hash[300001] ;
int N ;
const llu mult = 77 ;

int trylen(const int len) {
  int res = N ;
  llu h = 0, exp = 1 ;
  for(int beg = 0 ; beg < len ; beg++) {
    h = h*mult + input[beg] ;
    exp *= mult ;
  }
  for(int cur = 0 ; cur+len <= N ; cur++) {
    hash[cur] = {h, cur} ;
    h = h*mult+input[cur+len]-exp*input[cur] ;
  }
  std::sort(hash,hash+N-len+1) ;
  llu prev = hash[0].first, nb = 0 ;
  for(int cur = 0 ; cur + len <= N+1 ; cur++) {
    if(prev != hash[cur].first) {
      if(nb == 1)
        res = std::min(res,hash[cur-1].second) ;
      nb = 0 ;
      prev = hash[cur].first ;
    }
    nb++;
  }
  return res;
}

int main() {
  scanf("%s",input);
  N = strlen(input);
  llu min = 0, max = N ;
  while(min + 1 < max ) {
    const llu mid = (min+max+1)/2;
    if(trylen(mid) < N)
      max = mid ;
    else
      min = mid ;
  }
  const int start = trylen(max);
  input[start+max] = '\0';
  printf("%s\n",input+start);
}
