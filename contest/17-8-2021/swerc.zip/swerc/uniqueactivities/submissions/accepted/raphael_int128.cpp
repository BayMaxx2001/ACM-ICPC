// O(N log N) solution (rolling hash + dichotomy). Uses __int128 which is kind of a hack.
// See raphael_int64.cpp for a solution that does not use int128s.

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

uint64_t expo(uint64_t base, uint64_t exp, uint64_t mod) {
  if (exp == 0) {
    return 1;
  }
  if (exp == 1) {
    return base % mod;
  }
  // Available on GCC on some processors.
  // https://gcc.gnu.org/onlinedocs/gcc/_005f_005fint128.html
  // Would be great to find a less hacky way.
  __uint128_t res = expo(base, exp / 2, mod);
  res *= res;
  res %= mod;
  if (exp % 2) {
    res *= base;
    res %= mod;
  }
  return res;
}

// Large primes.
const uint64_t N = (UINT64_C(1) << 63) - 25;
const uint64_t a = (1 << 20) - 3;

std::string FindUniqueOfSize(const std::string &s, int len) {
  __uint128_t rolling_hash = 0;
  __uint128_t top_power = expo(a, len - 1, N);
  // Maps the hash of a length 'len' substring to start index of that
  // substring, or -1 if that substring has been seen more than once.
  std::unordered_map<uint64_t, int> hash_to_pos;
  for (int end = 0; end < s.size(); ++end) {
    int begin = end - len + 1;
    // We cover a substring [begin, end].
    if (begin - 1 >= 0) {
      rolling_hash += static_cast<__uint128_t>(256) * N;
      rolling_hash -= s[begin - 1] * top_power;
      rolling_hash %= N;
    }
    rolling_hash *= a;
    rolling_hash %= N;
    rolling_hash += s[end];
    rolling_hash %= N;
    if (begin >= 0) {
      //      std::cout << "substr: " << begin << " " << s.substr(begin, len)
      //		<< " hash: " << static_cast<uint64_t>(rolling_hash)
      //		<< std::endl;
      // We have a substring of length len.
      auto iterator_inserted =
          hash_to_pos.insert(std::make_pair(rolling_hash, begin));
      if (!iterator_inserted.second) {
        // Already present.
        iterator_inserted.first->second = -1;
      }
    }
  }

  int min_start_index = s.size();
  for (const auto& p : hash_to_pos) {
    if (p.second >= 0) {
      min_start_index = std::min(min_start_index, p.second);
    }
  }
  if (min_start_index == s.size()) {
    return "";
  }
  return s.substr(min_start_index, len);
}

// We know the solution is in the closed interval [min_len, max_len].
std::string FindShortestUnique(int min_len, int max_len, const std::string &s) {
  if (min_len == max_len) {
    return FindUniqueOfSize(s, min_len);
  }
  int mid = (min_len + max_len) / 2;
  //  std::cout << min_len << " " << max_len << " " << mid << std::endl;
  std::string sub = FindUniqueOfSize(s, mid);
  if (sub.empty()) {
    return FindShortestUnique(mid + 1, max_len, s);
  } else {
    return FindShortestUnique(min_len, mid, s);
  }
}

int main() {
  std::string s;
  std::cin >> s;
  std::cout << FindShortestUnique(1, s.size(), s) << std::endl;
}
