#!/usr/bin/python3

# Rolling hash submission - O(N log N)

import math

m = 2**60 - 93 # large prime
#m = 2**29 - 3
p = 29 # next prime after 26
n = 0 # length of the large string
s = input().strip()
A = ord('A')

# print("m = {}".format(m))

def update_rolling_hash(prev_hash, evicted_char, next_char, highest_factor):
    return ((prev_hash - evicted_char * highest_factor) * p + next_char) % m

def initial_hash(s):
    rolling_hash = 0
    for c in s:
        rolling_hash = ((rolling_hash * p) + (ord(c) - A)) % m
    return rolling_hash

# @profile
def check_length(l):
    # print("checking {}".format(l))
    # Python has modular exponentiation built-in, but you could choose a different rolling hash so I'd say it's not an unfair advantage
    global m, p, n, s
    highest_factor = pow(p, l-1, m)
    
    hashes = {}
    
    rolling_hash = initial_hash(s[0:l])
    hashes[rolling_hash] = 0

    for j in range(1, n - l + 1):
        # For each character, compute the next rolling hash
        rolling_hash = update_rolling_hash(rolling_hash, ord(s[j-1]) - A, ord(s[j + l - 1]) - A, highest_factor)
        if rolling_hash in hashes:
            # check it's not a collision
            old = hashes[rolling_hash]
            if old is not None:
                # assert s[old : old + l] == s[j : j + l]
                # print("Warning: hash collision: h({}) == h({}) == {}".format( s[old : old + l], s[j : j + l], rolling_hash))
                # Mark that hash as seen twice ; I also tried maintaining a separate set but it's just as slow
                hashes[rolling_hash] = None
        else:
            # First time we see this hash
            hashes[rolling_hash] = j
    mymin = None
    # Find the unique hash that appears first
    for v in hashes.values():
        if v is not None and (mymin is None or v < mymin):
            mymin = v
    return mymin
    
minLength = 1
maxLength = n = len(s)
shortestUnique = n
shortestUniqueBeginIndex = 0

while (minLength <= maxLength) and (maxLength > 0):
    cur = math.floor((minLength + maxLength) / 2)
    # print("({} < {} < {})".format(minLength, cur, maxLength))
    beginIndex = check_length(cur)
    if beginIndex is not None:
        shortestUnique = cur
        shortestUniqueBeginIndex = beginIndex
        maxLength = cur - 1
    else:
        # print("No unique string")
        minLength = cur + 1

print(s[shortestUniqueBeginIndex:shortestUniqueBeginIndex+shortestUnique])
        
# h = initial_hash("JC")
# print(h)
# h = update_rolling_hash(h, ord("J") - A, ord("I") - A, p)
# print(h)
# print(initial_hash("CI"))
# print("O")
# print(initial_hash("YVWZ"))
# print(initial_hash("YVXC"))