// O(N*logN) solution using only 64-bit integers (not 128 bits).

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

uint32_t expo(uint32_t base, uint32_t exp, uint32_t mod) {
  if (exp == 0) {
    return 1;
  }
  if (exp == 1) {
    return base % mod;
  }
  uint64_t res = expo(base, exp / 2, mod);
  res *= res;
  res %= mod;
  if (exp % 2) {
    res *= base;
    res %= mod;
  }
  return res;
}

// Large primes.
const uint32_t MOD1 = (1 << 30) - 35;
const uint32_t MOD2 = (1 << 30) - 101;
const uint32_t A1 = (1 << 20) - 3;
const uint32_t A2 = (1 << 20) - 17;

uint32_t UpdateRollingHash(int len, char char_to_remove, char char_to_add,
                           uint32_t mod, uint32_t a, uint32_t prev_hash,
                           uint32_t top_power) {
  uint64_t prev_hash_64 = prev_hash;
  if (char_to_remove != 0) {
    prev_hash_64 += UINT64_C(256) * mod;
    prev_hash_64 -= char_to_remove * static_cast<uint64_t>(top_power);
    prev_hash_64 %= mod;
  }
  prev_hash_64 *= a;
  // We don't need that one:
  // prev_hash_64 %= mod;
  prev_hash_64 += char_to_add;
  return prev_hash_64 % mod;
}

std::string FindUniqueOfSize(const std::string &s, int len) {
  uint32_t rolling_hash1 = 0;
  uint32_t rolling_hash2 = 0;
  uint32_t top_power1 = expo(A1, len - 1, MOD1);
  uint32_t top_power2 = expo(A2, len - 1, MOD2);
  // Contains pairs (hash of a length 'len' substring, start index of that
  // substring).
  // Sorting this vector to find unique hashes is faster than using an
  // std::unordered_map (which is notoriously slow).
  std::vector<std::pair<uint64_t, int>> hash_and_begin;
  hash_and_begin.reserve(s.size());
  for (int end = 0; end < s.size(); ++end) {
    int begin = end - len + 1;
    // We cover a substring [begin, end].
    char char_to_remove = 0;
    if (begin - 1 >= 0) {
      char_to_remove = s[begin - 1];
    }
    rolling_hash1 = UpdateRollingHash(len, char_to_remove, s[end], MOD1, A1,
                                      rolling_hash1, top_power1);
    rolling_hash2 = UpdateRollingHash(len, char_to_remove, s[end], MOD2, A2,
                                      rolling_hash2, top_power2);
    uint64_t rolling_hash =
        (static_cast<uint64_t>(rolling_hash1) << 32) + rolling_hash2;
    if (begin >= 0) {
      hash_and_begin.emplace_back(rolling_hash, begin);
    }
  }
  std::sort(hash_and_begin.begin(), hash_and_begin.end());
  int min_start_index = s.size();
  for (int i = 0; i < hash_and_begin.size(); ++i) {
    if ((i == 0 || hash_and_begin[i - 1].first != hash_and_begin[i].first) &&
        (i == hash_and_begin.size() - 1 ||
         hash_and_begin[i + 1].first != hash_and_begin[i].first)) {
      min_start_index = std::min(min_start_index, hash_and_begin[i].second);
    }
  }
  if (min_start_index == s.size()) {
    return "";
  }
  return s.substr(min_start_index, len);
}

// We know the solution is in the closed interval [min_len, max_len].
std::string FindShortestUnique(int min_len, int max_len, const std::string &s) {
  if (min_len == max_len) {
    return FindUniqueOfSize(s, min_len);
  }
  int mid = (min_len + max_len) / 2;
  //  std::cout << min_len << " " << max_len << " " << mid << std::endl;
  std::string sub = FindUniqueOfSize(s, mid);
  if (sub.empty()) {
    return FindShortestUnique(mid + 1, max_len, s);
  } else {
    return FindShortestUnique(min_len, mid, s);
  }
}

int main() {
  std::string s;
  std::cin >> s;
  std::cout << FindShortestUnique(1, s.size(), s) << std::endl;
}
