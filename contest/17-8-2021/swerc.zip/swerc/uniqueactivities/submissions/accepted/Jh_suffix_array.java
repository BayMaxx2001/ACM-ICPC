import java.util.Scanner;
import java.util.Stack;
import java.util.Arrays;
import java.util.ArrayList;

public class Jh_suffix_array
{
    static class Entry implements Comparable<Entry> {
        int data1, data2, idx;
        public int compareTo(Entry e) {
            if (this.data1 != e.data1) return this.data1 - e.data1;
            if (this.data2 != e.data2) return this.data2 - e.data2;
            return this.idx - e.idx;
        }
    }

    public static void main(String[] args)
    {
        Scanner input = new Scanner( System.in );
        String s = input.nextLine();

        int n = s.length();
        ArrayList<int[]> p = new ArrayList<int[]>();
        p.add(new int[n]);
        Entry[] l = new Entry[n];
        for (int i = 0; i < n; i++) {
            p.get(0)[i] = s.charAt(i);
            l[i] = new Entry();
        }

        for (int stp = 0; true; stp++) {
            int cnt = 1 << stp;
            if (cnt >= n) break;
            for (int i = 0; i < n; i++) {
                l[i].data1 = p.get(stp)[i];
                l[i].data2 = i+cnt < n ? p.get(stp)[i+cnt] : -1;
                l[i].idx = i;
            }
            Arrays.sort(l);
            p.add(new int[n]);
            p.get(stp+1)[l[0].idx] = 0;
            for (int i = 1; i < n; i++)
                p.get(stp+1)[l[i].idx] =
                    l[i].data1 == l[i-1].data1 && l[i].data2 == l[i-1].data2 ?
                    p.get(stp+1)[l[i-1].idx] : i;
        }

        int reslen = n, respos = 0, lenprec = 0;
        for (int i = 0; i < n; i++) {
            int lensuc = 0;
            if (i + 1 < n)
                for (int k = p.size()-1;
                     k >= 0 && l[i].idx + lensuc < n && l[i+1].idx + lensuc < n;
                     k--)
                    if (p.get(k)[l[i].idx + lensuc] == p.get(k)[l[i+1].idx + lensuc])
                        lensuc += 1 << k;

            int len = Math.max(lenprec, lensuc);
            lenprec = lensuc;
            if (len + l[i].idx >= n) continue;
            if (len + 1 < reslen || (len + 1 == reslen && l[i].idx < respos)) {
                reslen = len + 1;
                respos = l[i].idx;
            }
        }

        System.out.println(s.substring(respos, respos+reslen));
    }
}
