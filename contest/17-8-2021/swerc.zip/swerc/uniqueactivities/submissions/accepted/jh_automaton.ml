let s = Scanf.scanf "%s\n" (fun s -> s)

module CMap = Map.Make(struct type t = char let compare = compare end)

let max_states = 2 * String.length s

let trans = Array.make max_states CMap.empty
let link = Array.make max_states 0
let length = Array.make max_states 0
let last = ref 0
let n_states = ref 1
let new_state () = incr n_states; !n_states-1
exception Exit_with_pq of int * int
let () =
  link.(0) <- -1;
  String.iteri (fun i c ->
    let r = new_state () in
    length.(r) <- i+1;

    let rec loop p =
      if p >= 0 then begin
        trans.(p) <-
          CMap.update c
            (function None -> Some r | Some q -> raise (Exit_with_pq (p, q)))
            trans.(p);
        loop link.(p)
      end
    in
    begin try loop !last
    with Exit_with_pq (p, q) ->
      if length.(p) + 1 = length.(q) then
        link.(r) <- q
      else begin
        let qq = new_state () in
        trans.(qq) <- trans.(q);
        length.(qq) <- length.(p) + 1;
        link.(qq) <- link.(q);
        link.(q) <- qq;
        link.(r) <- qq;
        let rec loop p =
          if p >= 0 then begin
            trans.(p) <-
              CMap.update c
                (function Some q' when q' = q -> Some qq | _ -> raise Exit)
                trans.(p);
            loop link.(p)
          end
        in
        try loop p with Exit -> ();
      end;
    end;
    last := r
  ) s
let n_states = !n_states

let final = Array.make n_states false
let () =
  let rec loop p =
    if p >= 0 then begin final.(p) <- true; loop link.(p) end
  in
  loop !last

let () =
  let inf = 1000000000 in
  let dyn = Array.make n_states (-inf-1) in
  let rec uniq_suffix_len q =
    if dyn.(q) = -inf-1 then
      dyn.(q) <-
        if final.(q) then
          if CMap.is_empty trans.(q) then 0 else -inf
        else
          if CMap.cardinal trans.(q) > 1 then -inf
          else uniq_suffix_len (snd (CMap.choose trans.(q))) + 1;
    dyn.(q)
  in
  let rec loop q acc =
    if q = n_states then acc
    else begin
      let l = uniq_suffix_len q in
      if l >= 0 then loop (q+1) (min acc (length.(link.(q)) + 1, -l))
      else loop (q+1) acc
    end
  in
  let (minlen, minus_suffix_len) = loop 1 (inf, inf) in
  for i = String.length s + minus_suffix_len - minlen to
          String.length s + minus_suffix_len - 1 do
    Printf.printf "%c" s.[i]
  done;
  Printf.printf "\n"
