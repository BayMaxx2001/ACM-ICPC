import java.util.Arrays

fun main() {
  val input = readLine()!! ;
  val n = input.length ;
  val mult = 77 ;
  fun tryLen(len: Int) : Int {
    var res : Int = n ;
    var h : Long = 0;
    var exp : Long = 1 ;
    var hashes = Array(n-len+1,{_->Pair(0.toLong(),-1)});
    for(beg in 0..len-1) {
      h = h*mult+input[beg].toLong();
      exp *= mult;
    }
    for(cur in 0 .. n-len-1) {
      hashes[cur] = Pair(h,cur);
      h = h*mult+input[cur+len].toLong()-exp*input[cur].toLong() ;
    }
    hashes[n-len]=Pair(h,n-len);
    hashes.sortBy({it->it.first});
    var prev = hashes[0].first ;
    var nb = 0 ;
    for(cur in 0 .. n-len) {
      if( prev != hashes[cur].first ) {
        if(nb == 1 && res > hashes[cur-1].second) {
          res = hashes[cur-1].second ;
        }
        nb=0;
        prev=hashes[cur].first;
      }
      nb++;
    }
    if(nb == 1 && res > hashes[n-len].second) {
      return hashes[n-len].second;
    }
    return res;
  }  
  var min = 0 ;
  var max = n ;
  while(min + 1 < max ) {
    val mid = (min+1+max) / 2 ;
    if(tryLen(mid) < n) {
      max = mid ;
    } else {
      min = mid ;
    }    
  }
  val start=tryLen(max);
  println(input.substring(start,start+max));
}
