#include <utility>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <vector>
#include <map>

using namespace std;

char s[400000];

const int INF = 1000000000;

int main() {
  scanf("%s", s);
  int n = strlen(s);
  vector<map<char, int>> trans = { map<char, int>() };
  vector<int> link = { -1 }, length = { 0 };
  int last = 0;
  for(int i = 0; i < n; i++) {
    char c = s[i];

    int r = trans.size();
    trans.push_back(map<char, int>());
    length.push_back(i+1);
    link.push_back(0);

    int p = last;  last = r;
    while (p >= 0) {
      auto bit = trans[p].emplace(c, r);
      if (!bit.second) {
        int q = bit.first->second;
        if(length[p] + 1 == length[q]) link[r] = q;
        else {
          int qq = trans.size();
          trans.push_back(trans[q]);
          length.push_back(length[p] + 1);
          link.push_back(link[q]);

          link[q] = qq;
          link[r] = qq;
          while(p >= 0) {
            int &q2 = trans[p][s[i]];
            if(q2 != q) break;
            q2 = qq;
            p = link[p];
          }
        }
        break;
      }
      p = link[p];
    }
  }

  vector<bool> final(trans.size(), false);
  for(int p = last; p >= 0; p = link[p]) final[p] = true;

  vector<int> dyn(trans.size(), -INF-1);
  pair<int, int> minlenpos(INF, INF);
  for(int q = 1; q < trans.size(); q++) {
    int qq = q;
    vector<int> stk;
    while(dyn[qq] == -INF-1) {
      if(final[qq]) dyn[qq] = trans[qq].empty() ? 0 : -INF;
      else if(trans[qq].size() > 1) dyn[qq] = -INF;
      else {
        stk.push_back(qq);
        qq = trans[qq].begin()->second;
      }
    }
    while(stk.size() > 0) {
      dyn[stk.back()] = dyn[qq] + 1;
      qq = stk.back();
      stk.pop_back();
    }
    if (dyn[q] >= 0)
      minlenpos = min(minlenpos, make_pair(length[link[q]] + 1, n-dyn[q]));
  }

  s[minlenpos.second] = 0;
  printf("%s\n", &s[minlenpos.second - minlenpos.first]);
}
