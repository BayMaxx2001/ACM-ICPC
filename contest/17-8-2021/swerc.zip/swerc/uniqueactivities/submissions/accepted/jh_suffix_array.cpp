#include <utility>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace std;

char s[400000];

int main() {
  scanf("%s", s);
  int n = strlen(s);

  vector<vector<int>> p = { vector<int>(s, s+n) };
  vector<pair<pair<int,int>,int>> l(n);
  for(;;) {
    int cnt = 1 << (p.size() - 1);
    if (cnt >= n) break;
    l.clear();
    for (int i = 0; i < n; i ++)
      l.push_back(make_pair(
        make_pair(p.back()[i], i + cnt < n ? p.back()[i + cnt] : -1),
        i));
    sort(l.begin(), l.end());
    p.push_back(vector<int>(n));
    vector<int> &pb = p.back();
    for (int i = 0; i < n; i++)
      pb[l[i].second] = i > 0 && l[i].first == l[i-1].first ? pb[l[i-1].second] : i;
  }

  int reslen = n, respos = 0, lenprec = 0;
  for (int i = 0; i < n; i++) {
    int lensuc = 0;
    if (i+1 < n)
      for (int k = p.size()-1; k >= 0 &&
             l[i].second+lensuc < n && l[i+1].second+lensuc < n; k--)
        if (p[k][l[i].second+lensuc] == p[k][l[i+1].second+lensuc])
          lensuc += 1 << k;
    int len = max(lenprec, lensuc);
    lenprec = lensuc;
    if (len + l[i].second >= n) continue;
    if (len + 1 < reslen || (len + 1 == reslen && l[i].second < respos)) {
      reslen = len + 1;
      respos = l[i].second;
    }
  }
  s[respos+reslen] = 0;
  printf("%s", &s[respos]);
}
