// This version is Time Limit Exceeded because there's no indexing of the leaves to find quickly the leaf corresponding to each suffix
// So we have to go through the whole tree for each suffix, which is too slow.
// This is shown to be slow especially on test_pattern. Not sure why, maybe the suffix tree compresses badly in that case.

#define MAXN 1000000

#include <string>
#include <map>
#include <iostream>


using namespace std;
string s;
int n;

struct node {
    int l, r, par, link;
    map<char,int> next;

    node (int l=0, int r=0, int par=-1)
        : l(l), r(r), par(par), link(-1) {}
    int len()  {  return r - l;  }
    int &get (char c) {
        if (!next.count(c))  next[c] = -1;
        return next[c];
    }
};
node t[2 * MAXN];
int sz;

struct state {
    int v, pos;
    state (int v, int pos) : v(v), pos(pos)  {}
};
state ptr (0, 0);

state go (state st, int l, int r) {
    while (l < r)
        if (st.pos == t[st.v].len()) {
            st = state (t[st.v].get( s[l] ), 0);
            if (st.v == -1)  return st;
        }
        else {
            if (s[ t[st.v].l + st.pos ] != s[l])
                return state (-1, -1);
            if (r-l < t[st.v].len() - st.pos)
                return state (st.v, st.pos + r-l);
            l += t[st.v].len() - st.pos;
            st.pos = t[st.v].len();
        }
    return st;
}

int split (state st) {
    if (st.pos == t[st.v].len())
        return st.v;
    if (st.pos == 0)
        return t[st.v].par;
    node v = t[st.v];
    int id = sz++;
    t[id] = node (v.l, v.l+st.pos, v.par);
    t[v.par].get( s[v.l] ) = id;
    t[id].get( s[v.l+st.pos] ) = st.v;
    t[st.v].par = id;
    t[st.v].l += st.pos;
    return id;
}

int get_link (int v) {
    if (t[v].link != -1)  return t[v].link;
    if (t[v].par == -1)  return 0;
    int to = get_link (t[v].par);
    return t[v].link = split (go (state(to,t[to].len()), t[v].l + (t[v].par==0), t[v].r));
}

void tree_extend (int pos) {
	//printf("tree_extend %d\n", pos);
    for(;;) {
        state nptr = go (ptr, pos, pos+1);
        if (nptr.v != -1) {
            ptr = nptr;
			//printf("updating ptr to: %d %d\n", ptr.v, ptr.pos);
            return;
        }

        int mid = split (ptr);
        int leaf = sz++;
        t[leaf] = node (pos, n, mid);
        t[mid].get( s[pos] ) = leaf;

        ptr.v = get_link (mid);
        ptr.pos = t[ptr.v].len();
		//printf("creating leaf idx %d, node left = %d r = %d parent = %d ; ptr is now %d %d\n", leaf, pos, n, mid, ptr.v, ptr.pos);
        if (!mid)  break;
    }
}

void dump() {
  for (int i = 0 ; i < 2*n ; i++) {
	  printf("%d: l = %d, r=%d, ", i, t[i].l, t[i].r);
	  for (const auto & [k,v] : t[i].next) {
		  printf("%c -> %d, ", k, v);
	  }
	  printf("\n");
  }
}

void build_tree() {
    sz = 1;
    for (int i=0; i<n; ++i) {
        tree_extend (i);
		//printf("After inserting substring starting at %d, tree is\n", i);
		//dump();
	}
}

int main(void) {
	  std::cin >> s;
	  
	  
	  
	  // The implementation of suffix trees above seems to require that we have an unique character at the end of the string for 
	  // proper termination.
	  s += "\n";
	  n = s.length();
	  
	  // printf("ptr is now %d %d\n", ptr.pos, ptr.v);
	  build_tree();
	  int min_length = n;
	  int min_start = 0;
	  for (int i = 0; i < n - 1 ; i++) {
		  // Find the maximal unique substring anchored at i
		  state root(0, 0);
		  // Find the leaf node of S[i,n]
		  state leaf = go(root, i, n);
		  // printf("i == %d: found leaf %d\n", i, leaf.v);
		  if (leaf.v >= 0) {
			  const node & leafn = t[leaf.v];
			  int leaf_length = leafn.r-leafn.l;
			  if ((leafn.r == n) && (leaf_length == 1)) {
				  // If the label of the last edge is only made of the last character at the end, discard
				  continue;
			  }
			  int mus_length = n - leaf_length + 1  - i;
			  // printf("found node %d %d, length %d, min_length %d, min_start %d\n", leafn.l, leafn.r, mus_length, min_length, min_start);
			  // std::cout << s.substr(i, mus_length) << std::endl;
			  if((leafn.r > leafn.l) && (min_length > mus_length)) {
				  min_length = mus_length;
				  min_start = i;
			  }
		  }
	  }
	  
	  // printf("%d %d\n", min_start, min_length);
	  std::cout << s.substr(min_start, min_length) << std::endl;
	  
	  return 0;
}

