// Slightly optimized O(N*K^2) solution where N is the length of the
// input string and K the length of the shortest unique substring.
// We want to refuse such solutions, this should exceed the time limit.

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>
#include <bitset>

constexpr bool DEBUG = false;

class Bitset {
public:
  Bitset(int size) : bits((size * 5 + 63) / 64, 0) {
    int extra_bits = bits.size() * 64 - size * 5;
    assert(extra_bits >= 0);
    top_mask = (1ULL << (64 - extra_bits)) - 1;
    if (DEBUG) {
      std::cout << "size: " << size << " array size: " << bits.size()
		<< " extra bits: " << extra_bits << " top mask: " << std::bitset<64>(top_mask)
		<< std::endl;
    }
  }
  void Print(const std::string& msg) const {
    std::cout << msg << " ";
    for (auto b : bits) {
      std::cout << std::bitset<64>(b) << " ";
    }
    std::cout << std::endl;
  }
  
  // Stores a char from 'A' to 'Z' into the 5 LSBs of bits[0]. Moves
  // the bits accordingly and clears the 5 bits corresponding to the
  // char added 'size' times ago.
  void Add(char c) {
    assert(c >= 'A');
    assert(c <= 'Z');
    c -= 'A';
    if (DEBUG) {
      std::cout << "Adding " << std::bitset<8>(c) << std::endl;
      Print("before");
    }
    uint64_t propagate = c;
    for (int i = 0; i < bits.size(); ++i) {
      uint64_t new_propagate = bits[i] >> (64 - 5);
      bits[i] <<= 5;
      bits[i] |= propagate;
      propagate = new_propagate;
    }
    bits[bits.size() - 1] &= top_mask;
    if (DEBUG) {
      Print("after");
    }
  }
  // Poor-quality hash, but seems to work well enough..
  uint64_t Hash() const {
    uint64_t x = 0;
    for (auto b : bits) {
      x ^= b * 7;
    }
    return x;
  }

  std::vector<uint64_t> bits;
  // Mask to apply to the last element of bits to make sure bits
  // represent a sequence of exactly 'size' characters.
  uint64_t top_mask;
};

int main() {
  std::string s;
  std::cin >> s;
  for (int len = 1; len <= s.size(); ++len) {
    std::unordered_map<uint64_t, int> sub_to_pos;
    Bitset bitset(len);
    for (int end = 0; end < s.size(); ++end) {
      int begin = end - len + 1;
      bitset.Add(s[end]);
      if (begin < 0) continue;
      auto it_and_inserted = sub_to_pos.insert(std::make_pair(bitset.Hash(), begin));
      if (!it_and_inserted.second) {
        // Already exists.
        it_and_inserted.first->second = -1;
      }
    }
    int min_start_index = s.size();
    for (const auto& p : sub_to_pos) {
      if (p.second >= 0) {
	min_start_index = std::min(min_start_index, p.second);
      }
    }
    if (min_start_index != s.size()) {
      std::cout << s.substr(min_start_index, len);
      return 0;
    }
  }
  assert(false);
}
