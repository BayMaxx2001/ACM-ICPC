// Naive O(N*K^2) where N is the length of the input string and K the
// length of the shortest unique substring.
// We want to refuse such solutions, this should exceed the time limit.

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

int main() {
  std::string s;
  std::cin >> s;
  for (int len = 1; len <= s.size(); ++len) {
    std::unordered_map<std::string, int> sub_to_pos;
    for (int i = 0; i < s.size() - len + 1; ++i) {
      auto sub = s.substr(i, len);
      auto it_and_inserted = sub_to_pos.insert(std::make_pair(sub, i));
      // std::cout << sub << " " << it_and_inserted.second << std::endl;
      if (!it_and_inserted.second) {
        // Already exists.
        it_and_inserted.first->second = -1;
      }
    }
    int min_start_index = s.size();
    for (const auto& p : sub_to_pos) {
      if (p.second >= 0) {
	min_start_index = std::min(min_start_index, p.second);
      }
    }
    if (min_start_index != s.size()) {
      std::cout << s.substr(min_start_index, len);
      return 0;
    }
  }
  assert(false);
}
