#! /usr/bin/python
import fileinput
import sys

myinput = fileinput.input()
s = myinput.readline()
assert s[-1] == "\n"
assert len(s) > 1
for x in s[:-1]:
    assert x >= 'A'
    assert x <= 'Z'
s = myinput.readline()
assert s==""
sys.exit(42)
