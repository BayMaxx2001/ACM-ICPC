#!/usr/bin/env python
# args:
# nchars, length, pattern_length [, seed]
import random
import string
import sys

random.seed(0)
if len(sys.argv) >= 5:
    random.seed(int(sys.argv[4]))
    
def get_string(nchars, length, pattern_length):
    letters = string.ascii_uppercase[:nchars]
    pattern = ''.join([random.choice(letters) for i in range(pattern_length)])
    ret = pattern * ((length + pattern_length - 1) // pattern_length)
    return ret[:length]

print(get_string(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])))
