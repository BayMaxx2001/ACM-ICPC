#!/usr/bin/env python

import random
import string
import sys

random.seed(0)

def get_random_string(nchars, length):
    letters = string.ascii_uppercase[:nchars]
    return ''.join([random.choice(letters) for i in range(length)])

print(get_random_string(int(sys.argv[1]), int(sys.argv[2])))