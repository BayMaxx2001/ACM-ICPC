#include<ctime>
#include<cstdio>
#include<vector>
#include<unordered_map>
#include<unordered_set>

using namespace std;

struct Frag {
  const Frag *l, *r;
  Frag(const Frag *l, const Frag *r) : l(l), r(r) {}
  bool operator==(const Frag& other) const {
    return l == other.l && r == other.r;
  }
} zero(NULL, NULL), one(NULL, NULL);

namespace std {
  template <class T1, class T2> struct hash<pair<T1,T2>> {
    size_t operator()(const pair<T1,T2> &p) const {
      return (hash<T1>{}(p.first) << 1) ^ hash<T2>{}(p.second);
    }
  };
  template<> struct hash<Frag> {
    size_t operator()(const Frag &x) const {
      return hash<pair<const Frag*, const Frag*>>{}(make_pair(x.l, x.r));
    }
  };

}

unordered_set<Frag> built;
const Frag *build(const Frag *l, const Frag *r) {
  return &*built.emplace(l, r).first;
}

unordered_map<const Frag*, long long> dyn_popcount;
long long popcount(const Frag *f) {
  if(f == &zero) return 0;
  if(f == &one) return 1;
  auto x = dyn_popcount.emplace(f, 0);
  if(!x.second) return x.first->second;
  long long *res = &x.first->second;
  return *res = popcount(f->l) + popcount(f->r);
}

bool rule_110(bool l, bool x, bool r) {
  return (110 & (1 << (int(l)*4+int(x)*2+int(r)))) != 0;
}

unordered_map<pair<const Frag*, long long>, const Frag*> dyn_jump;
// n <= (1<<(lvl-2))
const Frag *jump(const Frag *f, long long n, int lvl) {
  auto x = dyn_jump.emplace(make_pair(f, n), (const Frag*)NULL);
  if(!x.second) return x.first->second;
  const Frag *&res = x.first->second;

  if(n == 0) return res = build(f->l->r, f->r->l);

  if(lvl == 2) {
    // n == 1
    bool l = rule_110(f->l->l == &one, f->l->r == &one, f->r->l == &one),
         r = rule_110(f->l->r == &one, f->r->l == &one, f->r->r == &one);
    return res = build(l ? &one : &zero, r ? &one : &zero);
  }

  long long pow2 = 1LL<<(lvl-3), n0 = n >= pow2 ? n-pow2 : n;
  const Frag *l0 = jump(f->l,                    n0, lvl-1),
             *m0 = jump(build(f->l->r, f->r->l), n0, lvl-1),
             *r0 = jump(f->r,                    n0, lvl-1);
  return res = build(jump(build(l0, m0), n-n0, lvl-1),
                     jump(build(m0, r0), n-n0, lvl-1));
}

const Frag *from_bits(unsigned mid_bits, int lvl) {
  if(lvl == 1) return build((mid_bits & 2) ? &one : &zero, (mid_bits & 1) ? &one : &zero);
  if(lvl <= 5) {
    const Frag *r = from_bits(mid_bits & ((1<<(1<<(lvl - 1))) - 1), lvl-1),
               *l = from_bits(mid_bits >> (1<<(lvl - 1)), lvl-1);
    return build(l, r);
  }
  const Frag *m = from_bits(mid_bits, lvl-1),
             *z = mid_bits == 0 ? m->l : from_bits(0, lvl-2);
  return build(build(z, m->l), build(m->r, z));
}

int main() {
  long long steps = 1000000000000;
  double t = 0.;
  unsigned bitst = 0;
  long long pct = 0;
  for(unsigned bits = 0; bits < (1 << 16); bits++) {
    double a = (double)clock() / CLOCKS_PER_SEC;
    int lvl = max(5, 64-__builtin_clzll(2*(steps*2+16) - 1));
    const Frag *start = from_bits(bits<<8, lvl), *end = jump(start, steps, lvl);
    long long pc = popcount(end);
    built.clear();
    dyn_popcount.clear();
    dyn_jump.clear();
    double b = (double)clock() / CLOCKS_PER_SEC;
    if(b-a > t) {
      t = b-a;
      bitst = bits;
      pct = pc;
      printf("%lf %x %lld\n", t, bitst, pct);
    }
  }
}
