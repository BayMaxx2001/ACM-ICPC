
open Format

let () = Random.self_init ()
let () =
  for _ = 1 to 16 do printf "%c" (if Random.bool () then '0' else '1') done
let () = printf "@.%s@." Sys.argv.(1)
