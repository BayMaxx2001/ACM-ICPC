#! /usr/bin/python3

import sys

def myint(s):
    assert s == "0" or not s.startswith("0"),\
            "leading 0 detected"
    return int(s)

try: input = raw_input  # Python 2 compatibility
except: pass

config = input()
assert(len(config) == 16)
for c in config:
    assert(c in ['0', '1'])

s = myint(input())
assert(0 <= s < pow(2, 60))

assert(len(sys.stdin.readlines()) == 0)

exit(42)
