seen = { (1,1,1): 0, (1,1,0): 1, (1,0,1): 1, (1,0,0): 0,
         (0,1,1): 1, (0,1,0): 1, (0,0,1): 1, (0,0,0): 0  }
combo = dict()
partsOf = [[0],[1]]
nbOnes = [0,1]

def combine(els):
    if tuple(els) not in combo:
        combo[tuple(els)]=len(partsOf)
        partsOf.append(els)
        nbOnes.append(nbOnes[els[0]]+nbOnes[els[1]])
    return combo[tuple(els)]

def futurList(l):
    return [futur(l[i-1],l[i],l[i+1]) for i in range(1,len(l)-1)]

def futur(p,m,n):
    if (p,m,n) not in seen:
        seen[(p,m,n)] = combine(futurList(futurList(partsOf[p]+partsOf[m]+partsOf[n])))
    return seen[(p,m,n)]
            
cur=[int(e) for e in input()]
n=int(input())
zero = 0
for c in reversed(bin(n)[2:]):
    if c == '1':
        cur = futurList([zero,zero]+cur+[zero,zero])
    cur=cur+[zero]
    cur = [combine(cur[i*2:i*2+2]) for i in range(len(cur)//2)]
    zero = combine([zero,zero])
print(sum([nbOnes[e] for e in cur]))
