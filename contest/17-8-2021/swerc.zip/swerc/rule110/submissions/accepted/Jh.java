import java.util.Scanner;
import java.util.HashMap;

public class Jh
{
    static class Frag {
        Frag l, r;
        Frag(Frag l, Frag r) { this.l = l; this.r = r; }
    }

    static class HashFrag {
        Frag f;
        HashFrag(Frag f) { this.f = f; }
        @Override public boolean equals(Object o) {
            HashFrag hf = (HashFrag)o;
            return this.f.l == hf.f.l && this.f.r == hf.f.r;
        }
        @Override public int hashCode() {
            return f.l.hashCode() ^ (f.r.hashCode() << 1);
        }
    }

    static Frag zero = new Frag(null, null), one = new Frag(null, null);

    static HashMap<HashFrag, Frag> built = new HashMap<HashFrag, Frag>();
    static Frag build(Frag l, Frag r) {
        HashFrag hf = new HashFrag(new Frag(l, r));
        Frag res = built.get(hf);
        if(res != null) return res;
        built.put(hf, hf.f);
        return hf.f;
    }

    static HashMap<Frag, Long> dyn_popcount = new HashMap<Frag, Long>();
    static long popcount(Frag f) {
        if(f == zero) return 0;
        if(f == one) return 1;
        Long res = dyn_popcount.get(f);
        if(res != null) return res;
        res = popcount(f.l) + popcount(f.r);
        dyn_popcount.put(f, res);
        return res;
    }

    static boolean rule_110(boolean l, boolean x, boolean r) {
        int li = l ? 1 : 0, xi = x ? 1 : 0, ri = r ? 1 : 0;
        return (110 & (1 << ((int)li*4+(int)xi*2+(int)ri))) != 0;
    }

    static HashMap<Long, HashMap<Frag, Frag>> dyn_jump =
        new HashMap<Long, HashMap<Frag, Frag>>();
    static Frag jump(Frag f, long n, int lvl) {
        HashMap<Frag, Frag> h = dyn_jump.get(n);
        if(h == null) {
            h = new HashMap<Frag, Frag>();
            dyn_jump.put(n, h);
        }
        Frag res = h.get(f);
        if(res != null) return res;
        if(n == 0) res = build(f.l.r, f.r.l);
        else if(lvl == 2) {
            // n == 1
            boolean l = rule_110(f.l.l == one, f.l.r == one, f.r.l == one),
                    r = rule_110(f.l.r == one, f.r.l == one, f.r.r == one);
            res = build(l ? one : zero, r ? one : zero);
        } else {
            long pow2 = 1L<<(lvl-3), n0 = n >= pow2 ? n-pow2 : n;
            Frag l0 = jump(f.l,                 n0, lvl-1),
                 m0 = jump(build(f.l.r, f.r.l), n0, lvl-1),
                 r0 = jump(f.r,                 n0, lvl-1);
            res = build(jump(build(l0, m0), n-n0, lvl-1),
                        jump(build(m0, r0), n-n0, lvl-1));
        }
        h.put(f, res);
        return res;
    }

    static Frag from_bits(int mid_bits, int lvl) {
        if(lvl == 1) return build((mid_bits & 2) != 0 ? one : zero,
                                  (mid_bits & 1) != 0 ? one : zero);
        if(lvl <= 5) {
            Frag r = from_bits(mid_bits & ((1<<(1<<(lvl-1)))-1), lvl-1),
                 l = from_bits(mid_bits >> (1<<(lvl-1)), lvl-1);
            return build(l, r);
        }
        Frag m = from_bits(mid_bits, lvl-1),
             z = mid_bits == 0 ? m.l : from_bits(0, lvl-2);
        return build(build(z, m.l), build(m.r, z));
    }

    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        String s = input.nextLine();
        int bits = 0;
        for(int i = 0; i < 16; i++)
            if(s.charAt(i) == '0') bits *= 2; else bits = bits*2 + 1;
        long steps = input.nextLong();

        int lvl = Math.max(5, 64-Long.numberOfLeadingZeros(2*(steps*2+16)-1));
        Frag start = from_bits(bits<<8, lvl);
        Frag end = jump(start, steps, lvl);
        System.out.println(popcount(end));
    }
}
