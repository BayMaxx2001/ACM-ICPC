
(* author: Jean-Christophe *)

module S = struct

  type t = E | N of { size: int; card: int; left: t; present: bool; right: t }

  let create n =
    let a = Array.make (n+1) E in
    for i = 1 to n do
      let l = i / 2 in
      a.(i) <-
        N { size = i; card = 0;
            left = a.(l); present = false; right = a.(i-1-l) }
    done;
    a.(n)

  let size = function E -> 0 | N { size } -> size
  let card = function E -> 0 | N { card } -> card
  let iverson b = if b then 1 else 0

  let build left present right =
    N { size = size left + 1 + size right;
        card = card left + iverson present + card right;
        left; present; right }

  let rec set i v = function
    | E -> assert false
    | N { size; left; present; right } ->
        assert (0 <= i && i < size);
        let r = size / 2 in
        if i = r then
          build left v right
        else if i < r then
          build (set i v left) present right
        else
          build left present (set (i-r-1) v right)

  let add i s = set i true s
  let remove i s = set i false s

  (* #{y in s st y >= x] *)
  let rec above x = function
    | E -> 0
    | N { size; left; present; right } ->
        assert (0 <= x && x < size);
        let r = size / 2 in
        if x < r then above x left + iverson present + card right
        else if x = r then iverson present + card right
        else above (x - r - 1) right

  (* let print fmt s =
   *   let rec print i = function
   *   | E -> ()
   *   | N { size; left; present; right } ->
   *       print i left;
   *       if present then Format.fprintf fmt "%d, " (i + size/2);
   *       print (i + size/2 + 1) right in
   *   print 0 s *)

end

let n = read_int ()
let set = Array.make (n + 1) (S.create n)

let () =
  for i = 1 to n do
    set.(i) <- set.(i-1);
    let s = read_line () in
    if s <> "" then
    String.split_on_char ' ' s |>
    List.iter (fun x ->
        set.(i) <- (if x.[0] = '+' then S.add else S.remove)
               (abs (int_of_string x)) set.(i))
  done

(* let () =
 *   for i = 1 to n do
 *     Format.eprintf "|S(%d)| = %d@." i (S.card set.(i));
 *     Format.eprintf "S(%d) = { %a } @." i S.print set.(i)
 *   done *)

let () =
  let x = ref 0 in
  for _ = 1 to n do
    let i = read_int () in
    (* Format.eprintf "x += #{ y in S(%d) y >= %d} (= %d)@." i !x
     *   (S.above !x set.(i)); *)
    x := (!x + S.above !x set.(i)) mod n;
    (* Format.eprintf "x <- %d@." !x; *)
  done;
  Format.printf "%d@." !x
