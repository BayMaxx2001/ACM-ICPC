import java.io.*;
import java.util.*;

// author: Jean-Christophe

public class Sets {

  public static void main(String[] args) throws IOException {
    BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
    int N = Integer.parseInt(r.readLine());
    BT[] set = new BT[N + 1];
    set[0] = BT.create(N + 1);
    for (int i = 1; i <= N; i++) {
      set[i] = set[i - 1];
      String line = r.readLine();
      if (line.equals("")) continue;
      for (String s: line.split(" ")) {
        int x = Math.abs(Integer.parseInt(s));
        set[i] = s.charAt(0) == '+' ? BT.add(x, set[i]) : BT.remove(x, set[i]);
      }
    }
    int x = 0;
    for (int k = 1; k <= N; k++) {
      int i = Integer.parseInt(r.readLine());
      x = (x + BT.above(x, set[i])) % N;
    }
    System.out.println(x);
  }

}

// Braun trees
class BT {
  final int size, card;
  final boolean  present;
  final BT left, right;

  // note: builds way too many Braun trees
  // could be O(log N) instead
  // yet, that's O(N) so that's fine
  static BT create(int n) {
    BT[] all = new BT[n+1];
    for (int i = 1; i <= n; i++)
      all[i] = new BT(all[i/2], false, all[i-1-i/2]);
    return all[n];
  }

  static int iverson(boolean b) { return b ? 1 : 0; }
  static int card(BT t) { return t == null ? 0 : t.card; }
  static int size(BT t) { return t == null ? 0 : t.size; }

  BT(BT left, boolean present, BT right) {
    this.size = size(left) + 1 + size(right);
    this.card = card(left) + iverson(present) + card(right);
    this.left = left; this.present = present; this.right = right;
  }
  BT() {
    this(null, false, null);
  }

  static BT set(int i, boolean b, BT t) {
    assert t != null;
    int r = t.size / 2;
    if (i == r)
      return new BT(t.left, b, t.right);
    else if (i < r)
      return new BT(set(i, b, t.left), t.present, t.right);
    else
      return new BT(t.left, t.present, set(i - r - 1, b, t.right));
  }

  static BT add(int i, BT t) { return set(i, true, t); }
  static BT remove(int i, BT t) { return set(i, false, t); }

  static int above(int x, BT t) {
    if (t == null) return 0;
    assert 0 <= x && x < t.size;
    int r = t.size / 2;
    if (x < r)
      return above(x, t.left) + iverson(t.present) + card(t.right);
    else if (x == r)
      return iverson(t.present) + card(t.right);
    else
      return above(x - r - 1, t.right);
  }

}
