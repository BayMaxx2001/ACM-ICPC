def add(tr, nk, nv):
    (k,v,l,r) = tr
    if k==nk:
        return (k,v+nv,l,r)
    else:
        if nk<k:
            return (k,v,add(l,nk,nv),r)
        else:
            return (k,v+nv,l,add(r,nk,nv))
        
def init(f,t):
    if f+1 == t:
        return (f,0,None,None)
    else:
        mid = (f+t)//2
        return (mid,0,init(f,mid),init(mid,t))

def query(tr,qk):
    (k,v,l,r) = tr
    if qk==k:
        return v
    if qk<k:
        return v+query(l,qk)
    return query(r,qk)

N = int(input())
S = [init(0,N+1)]
for _ in range(N):
    S.append(S[-1])
    for el in input().split():
        S[-1] = add(S[-1],int(el[1:]),int(el[0]+'1'))
x=0
for _ in range(N):
    x = (x+query(S[int(input())],x))%N
print(x)
