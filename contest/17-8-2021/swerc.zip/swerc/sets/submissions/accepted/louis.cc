#include <cstdio>
#include <map>

using namespace std;

const int Tm = 1<< 17 ;
map<int,int> trees[2*Tm] ;
int N;

void add(int x,int y,int i) {
  x+= Tm;
  while(x) {
    if(x%2==0)
      trees[x][y] += i;
    x = (x-1) / 2;    
  }
}

int query(int x, int y) {
  x+= Tm ;
  int r = 0 ;
  while(x) {
    auto it = trees[x].upper_bound(y) ;
    --it;
    r += it->second ;
    x = x / 2;
  }
  return r;
}

int main () {
  scanf("%d\n",&N);
  for(int i = 1 ; i <= N ; i++) {
    char c ;
    while( (c = getchar()) != '\n')
      if(c != ' ') {
        int item ;
        scanf("%d",&item);
        add(item,i,c=='-'?1:-1);
      }
  }

  for(int v = 0 ; v < Tm*2 ; v++) {
    int sum = 0 ;
    for(auto & it : trees[v]) {
      sum -= it.second ;
      it.second = sum;
    }
    trees[v][N] = 0 ;
    trees[v][0] = 0 ;
  }
  int x = 0, i;
  for(int h = 0 ; h < N ; h++) {
    scanf("%d",&i);
    x = (x+query(x,i))%N;
  }
  printf("%d\n",x);
  return 0;
}
