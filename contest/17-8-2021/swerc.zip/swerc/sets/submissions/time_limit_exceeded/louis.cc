#include <cstdio>
#include <bitset>
#include <vector>

using namespace std;

const int Tm = 100001 ;
int N;

int main() {
  scanf("%d\n",&N);
  vector<bitset<Tm>> S ;
  S.push_back(bitset<Tm>()) ;
  for(int i = 1 ; i <= N ; i++) {
    char c ;
    S.push_back(S.back());
    while( (c = getchar()) != '\n')
      if(c != ' ') {
        int item ;
        scanf("%d",&item);
        S.back().flip(item);
      }
  }
  vector<bitset<Tm>> masks ;
  masks.push_back(bitset<Tm>());
  masks.back().set();
  for(int i = 0 ; i <= N ; i++) {
    masks.push_back(masks.back());
    masks.back().flip(i);
  }
  int x = 0, i;
  for(int h = 0 ; h < N ; h++) {
    scanf("%d",&i);
    x = (x+(masks[x]&S[i]).count())%N;
  }
  printf("%d\n",x);
  return 0;
}

