
(* author: Jean-Christophe *)

module S = struct

  type t = bool array

  let create n = Array.make n false
  let copy = Array.copy
  let add x s = s.(x) <- true
  let remove x s = s.(x) <- false

  (* #{y in s st y >= x] *)
  let above x s =
    let c = ref 0 in
    Array.iteri (fun y b -> if b && y >= x then incr c) s;
    !c

end

let n = read_int ()
let set = Array.make (n + 1) (S.create n)

let () =
  for i = 1 to n do
    set.(i) <- S.copy set.(i-1);
    let s = read_line () in
    if s <> "" then
    String.split_on_char ' ' s |>
    List.iter (fun x ->
        (if x.[0] = '+' then S.add else S.remove)
          (abs (int_of_string x)) set.(i))
  done

let () =
  let x = ref 0 in
  for _ = 1 to n do
    let i = read_int () in
    x := (!x + S.above !x set.(i)) mod n;
  done;
  Format.printf "%d@." !x
