#! /usr/bin/python

try: input = raw_input  # Python 2 compatibility
except: pass

n = int(input())
assert(1 <= n <= 100000)

import sys
lines = sys.stdin.readlines()
assert(len(lines) == 2*n)

present = [False] * n

for l in lines[:n]:
    for s in l.split():
        op = s[0]
        assert(op in ['+', '-'])
        j = int(s[1:])
        assert(0 <= j < n)
        if op == '+':
            assert(not present[j])
            present[j] = True
        else:
            assert(present[j])
            present[j] = False

for b in present:
    assert(not b)

for l in lines[n:]:
    i = int(l)
    assert(0 <= i <= n)

exit(42)
