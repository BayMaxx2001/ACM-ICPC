
open Format

let n = int_of_string Sys.argv.(1)
let () = printf "%d@." n
let () = Random.self_init ()

let shuffle a =
  for i = 1 to Array.length a - 1 do
    let j = Random.int (i + 1) in
    let t = a.(i) in
    a.(i) <- a.(j);
    a.(j) <- t
  done

let newline, print =
  let first = ref true in
  let newline () = Format.printf "@."; first := true in
  let print s x =
    if !first then first := false else Format.printf " ";
    Format.printf "%s%d" s x in
  newline, print

let () = match Sys.argv.(2) with
  | "tr" ->
      let a = Array.init n (fun i -> i) in
      shuffle a;
      printf "+%d " a.(0); for i = 1 to n-1 do print "+" a.(i); newline () done;
      for i = 0 to n-1 do print "-" i done;
      newline ();
      for _ = 1 to n do printf "%d@." (Random.int (n+1)) done
  | "random" ->
      let added = Array.make n false in
      let removed = Array.make n false in
      for i = 1 to n-1 do
        for k = 1 to 3 do
          let j = Random.int n in
          if not added.(j) && not removed.(j) then (
            print "+" j; added.(j) <- true
          );
        done;
        for k = 1 to 3 do
          let j = Random.int n in
          if added.(j) && not removed.(j) then (
            print "-" j; removed.(j) <- true
          );
        done;
        newline ()
      done;
      for j = 0 to n-1 do
        if not added.(j) && not removed.(j) then (
          print "+" j; print "-" j
        ) else if added.(j) && not removed.(j) then
          print "-" j
      done;
      newline ();
      for _ = 1 to n do printf "%d@." (Random.int (n+1)) done
  | _ -> ()
