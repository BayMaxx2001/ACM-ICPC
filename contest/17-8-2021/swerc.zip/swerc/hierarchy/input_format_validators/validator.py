try: input = raw_input
except: pass

A,N,K = map(int,input().split())

assert(1<=A<=N)
assert(1<=N<=2021)
assert(1<=K<=1000000000)

import sys
line = sys.stdin.readline()
print(line)
assert not line
exit(42)
