#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#define MAXN 2021

long long bicoef[MAXN+1][MAXN+1];
long long treeCount[MAXN+1];
long long treeWLeafCount[MAXN+1][MAXN+1];
int visitedWLeaf[MAXN+1][MAXN+1];
int N,A;
long long K;

void computebiCoefs()
{
    int i,j;
    for (i = 0; i<=N; ++i) 
        for (j = 0; j <= i; ++j)     
            if (j == 0 || j == i) 
                bicoef[i][j] = 1;
            else
                bicoef[i][j] = (bicoef[i-1][j] + bicoef[i-1][j-1]) % K;
}

void countTrees() 
{
    int i,j;
    long long crt;
    
    treeCount[0] = treeCount[1] = 1;
    for (i = 2; i<=N; ++i) {
        for (j = 0; j <= i-2; ++j) {     
            crt = treeCount[j+1];
            crt = (crt * treeCount [i-2-j]) % K;
            crt = (crt*bicoef[i-2][j]) % K;
            treeCount [i] = (treeCount[i] + crt) % K;
        }
   }
}

void initTreesWLeaves() {
    for (int i = 0; i<=N; ++i)
        for (int j = 0; j<=i; ++j)  
            visitedWLeaf[i][j] = 0;
}

long long countTreesWLeaves(int i, int j) {
   if (visitedWLeaf[i][j] == 0) {
     visitedWLeaf[i][j] = 1;
     long long crt;       
     treeWLeafCount[i][j] = treeCount[i];
     for (int k = 1; k <=j-1; k++) {
        crt = (treeCount[k+1] * countTreesWLeaves(i-k,j-k)) % K ;
        crt = (crt * bicoef[j-1][k]) % K;
        treeWLeafCount[i][j] = (treeWLeafCount[i][j] - crt + K) % K;
     }
   }
   return treeWLeafCount[i][j];
}

int main() 
{
  size_t ret;
  ret = scanf("%d %d %lld", &A, &N, &K);
  computebiCoefs();
  countTrees();
  initTreesWLeaves();
  countTreesWLeaves(N,A);
  
  printf("%lld\n", treeWLeafCount[N][A]);
  (void) ret;
  return 0;
}
