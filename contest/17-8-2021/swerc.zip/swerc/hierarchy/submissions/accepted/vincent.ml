let a,n,k = Scanf.scanf "%d %d %d\n" (fun x y z -> (y+1-x,y,z));;

let trees = Array.make (n+1) 0;;
let leaf = Array.make (n+1) 0;;
let binom = Array.make_matrix (n+1) (n+1) 0;;

for z = 0 to n do
  binom.(z).(0) <- 1;
  binom.(z).(z) <- 1;
  for y = 1 to z-1 do
    binom.(z).(y) <- (binom.(z-1).(y) + binom.(z-1).(y-1)) mod k;
  done
done
;;

trees.(0) <- 1;
trees.(1) <- 1;
for z = 2 to n do
  trees.(z) <- 0;
  for y = 0 to z-2 do
    let u = (trees.(y+1) * trees.(z-2-y)) mod k in
    trees.(z) <- (trees.(z) + u * binom.(z-2).(y)) mod k
  done
done
;;

for z = a to n do
  leaf.(z) <- trees.(z);
  for y = a to z-1 do
    let u = (leaf.(y) * trees.(z+1-y)) mod k in
    let v = (u * binom.(z-a).(z-y)) mod k in
    leaf.(z) <- (k - v + leaf.(z)) mod k
  done
done
;;

print_int(leaf.(n));
print_newline()
