try: input=raw_input
except: pass

import sys

A,N,mod = map(int,input().split())
A = N+1-A

trees = [0] * (N+1)
leaf  = [0] * (N+1)
binom = [[0] * (y+1) for y in range(N+1)]

for n in range(0,N+1):
  binom[n][0] = 1
  binom[n][n] = 1
  for k in range(1,n):
    binom[n][k] = (binom[n-1][k] + binom[n-1][k-1]) % mod

trees[0] = 1
trees[1] = 1
for i in range(2,N+1):
  trees[i] = 0
  for k in range(0,i-1):
    a = trees[k+1] * trees[i-2-k]
    b = (a % mod) * binom[i-2][k]
    trees[i] = (trees[i] + b) % mod

for i in range(A,N+1):
  leaf[i] = trees[i]
  for k in range(A,i):
    a = leaf[k] * trees[i-k+1]
    b = (a % mod) * binom[i-A][i-k]
    c = mod - (b % mod)
    leaf[i] = (leaf[i] + c) % mod

print(leaf[N])
