import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.StringJoiner;

public class Fast {
	private static long[] trees;
	// trees[u] = # trees with a given set of u nodes
	private static long[][] leaf;
	// leaf[u][v] = # trees with a given set of u nodes, the v-th of which is a leaf
	// (1 <= v <= u)
	private static long[][] binom;
	// binom[u][v] = {choose v among u}
	private static long mod;

	static long getResult(int A, int N, long K) {
		trees = new long[N + 1];
		leaf = new long[N + 1][N + 1];
		binom = new long[N + 1][N + 1];
		mod = K;
		for (int i = 0; i < N + 1; i++) {
			for (int j = 0; j < N + 1; j++) {
				leaf[i][j] = -1;
				binom[i][j] = -1;
			}
			trees[i] = -1;
		}
		return leaf(N, A);
	}

	private static long binom(int n, int k) {
		if (binom[n][k] == -1) {
			binom[n][k] = (k == 0 || k == n) ? 1 : (binom(n - 1, k) + binom(n - 1, k - 1)) % mod;
		}
		return binom[n][k];
	}

	private static long trees(int i) {
		if (trees[i] == -1) {
			if (i < 2) {
				trees[i] = 1;
			} else {
				trees[i] = 0;
				for (int k = 0; k <= i - 2; k++) {
					long a = trees(k + 1);
					long b = trees(i - 2 - k);
					b = (a * b) % mod;
					long c = binom(i - 2, k);
					c = (b * c) % mod;
					trees[i] = (trees[i] + c) % mod;
				}
			}
		}
		return trees[i];
	}

	// Here you split every size-i tree by cutting out the sub-tree rooted
	// at node j.
	// There are k nodes that are not strict descendants of node j,
	// with j <= k <= i, and you have {choose i-k among i-j} ways to
	// choose the labels of these i-k strict descendants among the i-j labels
	// larger than j. This gives you:
	// trees[i] = \sum_{k=j}^{i} leaf[k][j] trees[i-k+1] binom[i-j][i-k], i.e. :
	// leaf[i][j] = leaf[k][j] trees[i-k+1] binom[i-j][i-k] for k = i
	// .......... = trees[i] -
	// ............ \sum_{k=j}^{i-1} leaf[k][j] trees[i-k+1] binom[i-j][i-k]

	private static long leaf(int i, int j) {
		if (leaf[i][j] == -1) {
			leaf[i][j] = trees(i);
			for (int k = j; k < i; k++) {
				long a = leaf(k, j);
				long b = trees(i - k + 1);
				b = (a * b) % mod;
				long c = binom(i - j, i - k);
				c = (b * c) % mod;
				leaf[i][j] = (leaf[i][j] + mod - c) % mod;
			}
		}
		return leaf[i][j];
	}

	private static void read() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line = br.readLine().split(" ");
		int A = Integer.parseInt(line[0]);
		int N = Integer.parseInt(line[1]);
		int K = Integer.parseInt(line[2]);
		br.close();
		System.out.println(getResult(N + 1 - A, N, K));
	}

	public static void main(String[] args) throws IOException {
		read();
	}
}

