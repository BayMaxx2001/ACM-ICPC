import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Slow {
	private static long[] trees;
	private static long[][] leaf;
	private static long[][] binom;
	private static long mod;

	static long getResult(int A, int N, int K) {
		trees = new long[N + 1];
		leaf = new long[N + 1][N + 1];
		binom = new long[N + 1][N + 1];
		mod = K;
		for (int i = 0; i < N + 1; i++) {
			for (int j = 0; j < N + 1; j++) {
				leaf[i][j] = -1;
				binom[i][j] = -1;
			}
			trees[i] = -1;
		}
		return leaf(N, A);
	}

	private static long binom(int n, int k) {
		if (binom[n][k] == -1) {
			binom[n][k] = (k == 0 || k == n) ? 1 : (binom(n - 1, k) + binom(n - 1, k - 1)) % mod;
		}
		return binom[n][k];
	}

	private static long trees(int i) {
		if (trees[i] == -1) {
			if (i < 2) {
				trees[i] = 1;
			} else {
				trees[i] = 0;
				for (int k = 0; k <= i - 2; k++) {
					long a = trees(k + 1);
					long b = trees(i - 2 - k);
					b = (a * b) % mod;
					long c = binom(i - 2, k);
					c = (b * c) % mod;
					trees[i] = (trees[i] + c) % mod;
				}
			}
		}
		return trees[i];
	}

	private static long leaf(int i, int j) {
		if (leaf[i][j] == -1) {
			if (j == i && i < 3) {
				leaf[i][j] = 1;
			} else if (j == 1) {
				leaf[i][j] = 0;
			} else if (j == 2) {
				leaf[i][j] = trees(i - 2);
			} else {
				leaf[i][j] = 0;
				for (int k = 0; k < j - 2; k++) {
					for (int l = 0; l <= i - j; l++) {
						long a = (leaf(k + l + 2, k + 2) * trees(i - k - l - 3)) % mod;
						long b = (leaf(k + l + 1, k + 1) * trees(i - k - l - 2)) % mod;
						long c = binom(j - 3, k);
						long d = binom(i - j, l);
						d = (c * d) % mod;
						d = ((a + b) * d) % mod;
						leaf[i][j] = (leaf[i][j] + d) % mod;
					}
				}
			}
		}
		return leaf[i][j];
	}

	private static void read() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line = br.readLine().split(" ");
		int A = Integer.parseInt(line[0]);
		int N = Integer.parseInt(line[1]);
		int K = Integer.parseInt(line[2]);
		br.close();
		System.out.println(getResult(N + 1 - A, N, K));
	}

	public static void main(String[] args) throws IOException {
		read();
	}

}

