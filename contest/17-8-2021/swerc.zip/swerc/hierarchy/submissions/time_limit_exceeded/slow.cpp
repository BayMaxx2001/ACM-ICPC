#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

long long getBinomial(int n, int k, long long mod, long long** binom) {
  if (binom[n][k] == -1) {
    binom[n][k] = (k == 0 || k == n) ? 1 : (getBinomial(n-1,k,mod,binom) + getBinomial(n-1,k-1,mod,binom)) % mod;
  }
  return binom[n][k];
}

long long countTrees(int i, long long mod, long long* trees, long long** binom) {
  if (trees[i] == -1) {
    if (i < 2) {
      trees[i] = 1;
    } else {
      trees[i] = 0;
      for (int k = 0; k < i-1; k++) {
        long long a = countTrees(k+1,mod,trees,binom);
        long long b = countTrees(i-2-k,mod,trees,binom);
        long long c = getBinomial(i-2,k,mod,binom);
        b = (a * b) % mod;
        c = (b * c) % mod;
        trees[i] = (trees[i] + c) % mod;
      }
    }
  }
  return trees[i];
}

long long countLeaves(int i, int j, long long mod, long long** leaf, long long* trees, long long** binom) {
  if (leaf[i][j] == -1) {
    if (j == i && i < 3) {
      leaf[i][j] = 1;
    } else if (j == 1) {
      leaf[i][j] = 0;
    } else if (j == 2) {
      leaf[i][j] = countTrees(i - 2,mod,trees,binom);
    } else {
      leaf[i][j] = 0;
      for (int k = 0; k < j - 2; k++) {
	for (int l = 0; l <= i - j; l++) {
	  long long a = (countLeaves(k + l + 2, k + 2,mod,leaf,trees,binom) * countTrees(i - k - l - 3,mod,trees,binom)) % mod;
	  long long b = (countLeaves(k + l + 1, k + 1,mod,leaf,trees,binom) * countTrees(i - k - l - 2,mod,trees,binom)) % mod;
	  long long c = getBinomial(j - 3, k,mod,binom);
	  long long d = getBinomial(i - j, l,mod,binom);
	  d = (c * d) % mod;
	  d = ((a + b) * d) % mod;
	  leaf[i][j] = (leaf[i][j] + d) % mod;
	}
      }
    }
  }
  return leaf[i][j];
}
  
long long getResult(int A, int N, long long K) {
  long long* trees = (long long*) malloc((N+1) * sizeof(long long));
  long long** leaf = (long long**) malloc((N+1) * sizeof(long long*));
  long long** binom = (long long**) malloc((N+1) * sizeof(long long*));
  for (int i = 0; i < N+1; i++) {
    leaf[i] = (long long*) malloc((N+1) * sizeof(long long));
    binom[i] = (long long*) malloc((N+1) * sizeof(long long));
    trees[i] = -1;
    for (int j = 0; j < N+1; j++) {
    leaf[i][j] = -1;
    binom[i][j] = -1;
    }
  }
  return countLeaves(N,A,K,leaf,trees,binom);
}

int main() {
  int A, N;
  long long K;
  scanf("%d %d %lld", &A, &N, &K);
  long long result = getResult(N + 1 - A,N,K);
  printf("%lld\n", result);
  return 0;
}
