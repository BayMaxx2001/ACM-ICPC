#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

void countBinomials(int n, long long mod, long long** binom) {
  for (int i = 0; i <= n; i++) {
    for (int j = 0; j <= i; j++) {
      binom[i][j] = (j == 0 || j == i) ? 1 : (binom[i-1][j] + binom[i-1][j-1]) % mod;
    }
  }
}

void countTrees(int n, long long mod, long long* trees, long long** binom) {
  trees[0] = 1;
  trees[1] = 1;
  for (int i = 2; i <= n; i++) {
    trees[i] = 0;
    for (int k = 0; k < i-1; k++) {
      long long a = trees[k+1];
      long long b = trees[i-2-k];
      long long c = binom[i-2][k];
      b = (a * b) % mod;
      c = (b * c) % mod;
      trees[i] = (trees[i] + c) % mod;
    }
  }
}

void countLeaves(int n, long long mod, long long** leaf, long long* trees, long long** binom) {
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= i; j++) {
      leaf[i][j] = trees[i];
      for (int k = j; k < i; k++) {
        long long a = leaf[k][j];
        long long b = trees[i-k+1];
        long long c = binom[i-j][i-k];
        b = (a * b) % mod;
        c = (b * c) % mod;
        leaf[i][j] = (leaf[i][j] + mod - c) % mod;
      }
    }
  }
}
  
long long getResult(int A, int N, long long K) {
  long long* trees = (long long*) malloc((N+1) * sizeof(long long));
  long long** leaf = (long long**) malloc((N+1) * sizeof(long long*));
  long long** binom = (long long**) malloc((N+1) * sizeof(long long*));
  for (int i = 0; i < N+1; i++) {
    leaf[i] = (long long*) malloc((N+1) * sizeof(long long));
    binom[i] = (long long*) malloc((N+1) * sizeof(long long));
    trees[i] = -1;
    for (int j = 0; j < N+1; j++) {
    leaf[i][j] = -1;
    binom[i][j] = -1;
    }
  }
  countBinomials(N, K, binom);
  countTrees(N, K, trees, binom);
  countLeaves(N, K, leaf, trees, binom);
  return leaf[N][A];
}

int main() {
  int A, N;
  long long K;
  scanf("%d %d %lld", &A, &N, &K);
  long long result = getResult(N+1-A,N,K);
  printf("%lld\n", result);
  return 0;
}
