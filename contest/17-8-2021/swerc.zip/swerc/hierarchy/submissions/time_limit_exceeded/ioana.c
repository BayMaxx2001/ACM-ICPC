#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#define MAXN 2021

long long bicoef[MAXN+1][MAXN+1];
long long treeCount[MAXN+1];
long long treeWLeafCount[MAXN+1][MAXN+1];
int N,A;
long long K;

void computebiCoefs()
{
    int i,j;
    for (i = 0; i<=N; ++i) 
        for (j = 0; j <= i; ++j)     
            if (j == 0 || j == i) 
                bicoef[i][j] = 1;
            else
                bicoef[i][j] = (bicoef[i-1][j] + bicoef[i-1][j-1]) % K;
}

void countTrees() 
{
    int i,j;
    long long crt;
    
    memset(treeCount, 0, (N+1)*sizeof(long long));
    
    treeCount[0] = treeCount[1] = 1;
    for (i = 2; i<=N; ++i) {
        for (j = 0; j <= i-2; ++j) {     
            crt = treeCount[j+1];
            crt = (crt * treeCount [i-2-j]) % K;
            crt = (crt*bicoef[i-2][j]) % K;
            treeCount [i] = (treeCount[i] + crt) % K;
        }
   }
}


void countTreesWLeaves() {
   int i, j, k;
   long long crt;
    for (i = 0; i<=N; ++i)
        for (j = 0; j<=i; ++j){         
            treeWLeafCount[i][j] = treeCount[i];
            for (k = 1; k <=j-1; k++) {
                crt = treeCount[k+1];
                crt = (crt * treeWLeafCount[i-k][j-k]) % K ;
                crt = (crt * bicoef[j-1][k]) % K;
                treeWLeafCount[i][j] = (treeWLeafCount[i][j] - crt + K) % K;
            }
        }
}

int main() 
{
  size_t ret;
  ret = scanf("%d %d %lld", &A, &N, &K);
  computebiCoefs();
  countTrees();
  countTreesWLeaves();
  
  printf("%lld\n", treeWLeafCount[N][A]);
  (void) ret;
  return 0;
}
