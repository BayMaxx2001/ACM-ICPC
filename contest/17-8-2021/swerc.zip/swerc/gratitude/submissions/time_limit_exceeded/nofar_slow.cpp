#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
using namespace std;


int main() {
    // input
    int N, K;
    scanf("%d %d\n", &N, &K);
    string s;
    vector <string> lines;
    map <string, int> count;
    for (int i = 0; i < 3 * N; i++) {
        getline(cin, s);
        lines.push_back(s);
        count[s]++;
    }
    // output
    set <string> printed;
    for (int i = 0; i < K; i++) {
        int best_count = 0;
        string best_string;
        for (int i = (int)lines.size() - 1; i >= 0; i--) {
            string candidate = lines[i];
            if (count[candidate] > best_count and printed.count(candidate) == 0) {
                best_string = candidate;
                best_count = count[candidate];
            }
        }
        if (best_count == 0) {
            break;
        }
        cout << best_string << endl;
        printed.insert(best_string);
    }
    return 0;
}
