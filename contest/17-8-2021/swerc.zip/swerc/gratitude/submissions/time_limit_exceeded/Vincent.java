import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Vincent {
	private static final Map<String, Integer> occurrences = new HashMap<>();
	private static int K;
	private static int N;
	private static String[] tab;

	private static void read() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line = br.readLine().split(" ");
		N = Integer.parseInt(line[0]);
		K = Integer.parseInt(line[1]);
		tab = new String[3 * N];
		for (int i = 0; i < 3 * N; i++) {
			String s = br.readLine();
			occurrences.merge(s, 1, (x, y) -> x + y);
			tab[i] = s;
		}
		br.close();
	}
	
	private static void findBest() {
		int best = -1;
		int max = 0;
		for (int i = 3 * N - 1; i >= 0; i--) {
			if (occurrences.get(tab[i]) > max) {
				max = occurrences.get(tab[i]);
				best = i;
			}
		}
		if (best != -1) {
			occurrences.put(tab[best],-1);
			System.out.println(tab[best]);
		}
	}

	private static void printSolution() {
		for (int i = 0; i < K; i++) {
			findBest();
		}
	}

	public static void main(String[] args) throws IOException {
		read();
		printSolution();
	}
}

