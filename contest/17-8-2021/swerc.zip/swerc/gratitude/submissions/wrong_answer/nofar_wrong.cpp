#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
using namespace std;

typedef pair<int, int> ii;
typedef map<string, int> msi;


int main() {
    // input
    int N, K;
    scanf("%d %d\n", &N, &K);
    string s;
    msi occurrences;
    msi first_occurrence;
    for (int i = 0; i < 3 * N; i++) {
        getline(cin, s);
        occurrences[s]++;
        if (first_occurrence.count(s) == 0) first_occurrence[s] = i;
    }
    // sort
    vector< pair<ii, string> > lines;
    for (auto p : occurrences) {
        string s = p.first;
        ii score = ii (-p.second, first_occurrence[s]);
        lines.emplace_back(score, s);
    }
    sort(lines.begin(), lines.end());
    // output
    for (int i = 0; i < min(K, (int)lines.size()); i++) {
        cout << lines[i].second << endl;
    }
    return 0;
}
