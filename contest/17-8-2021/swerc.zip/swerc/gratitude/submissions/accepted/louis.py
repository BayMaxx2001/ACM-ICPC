from collections import defaultdict

N,K = map(int,input().split())
cnt = defaultdict(int)
pos = {}
out = set()
for i in range(3*N):
    line = input()
    out.add(line)
    cnt[line] +=1
    pos[line] = i

for l in sorted(list(out),key=lambda x:(cnt[x],pos[x]),reverse=True)[:K]:
    print(l)
