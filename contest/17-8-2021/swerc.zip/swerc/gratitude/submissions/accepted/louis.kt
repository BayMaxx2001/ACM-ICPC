import java.util.Arrays
import kotlin.math.*

fun main () {
  val input = readLine()!!.split(" ");
  val n = input[0].toInt();
  val k = input[1].toInt();
  var lin : Array<String> = Array(n*3, { _ -> "" } );
  val position:HashMap<String,Int> = HashMap<String,Int>()
  val number:HashMap<String,Int> = HashMap<String,Int>()
  for(i in 0 .. n*3-1 ) {
    lin[i] = readLine()!! ;
    position.put(lin[i],i);
    number.put(lin[i],1+number.getOrDefault(lin[i],0));
  }
  for(l in number.keys.toList().
      sortedWith(compareBy({-(number.get(it)!!)},{-(position.get(it)!!)})).
      subList(0,min(k,number.keys.size))) {
    println(l);
  }
}

