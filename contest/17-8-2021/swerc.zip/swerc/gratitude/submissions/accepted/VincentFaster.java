import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.StringJoiner;

public class VincentFaster {
	private static final Map<String, Integer> occurrences = new HashMap<>();
	private static final Map<String, Integer> lastOccurrence = new HashMap<>();
	private static String[] tab;
	private static Stack<String>[] stacks;
	private static int N;
	private static int K;

	@SuppressWarnings("unchecked")
	private static void read() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line = br.readLine().split(" ");
		N = Integer.parseInt(line[0]);
		K = Integer.parseInt(line[1]);
		tab = new String[3 * N];
		stacks = (Stack<String>[]) new Stack[N + 1];
		for (int i = 0; i < 3 * N; i++) {
			String s = br.readLine();
			lastOccurrence.put(s, i);
			occurrences.merge(s, 1, (x, y) -> x + y);
			tab[i] = s;
		}
		br.close();
	}
	
	private static void sortSolution() {
		for (int i = 0; i < N + 1; i++) {
			stacks[i] = new Stack<>();
		}
		for (int i = 0; i < 3 * N; i++) {
			String s = tab[i];
			if (i == lastOccurrence.get(s)) {
				stacks[occurrences.get(s)].push(s);
			}
		}
	}

	private static void printSolution() {
		int counter = 0;
		StringJoiner sj = new StringJoiner("\n");
		for (int i = N; i > 0 && counter < K; i--) {
			for(;!stacks[i].isEmpty() && counter < K;counter++) {
				sj.add(stacks[i].pop());
			}
		}
		System.out.println(sj);
	}

	public static void main(String[] args) throws IOException {
		read();
		sortSolution();
		printSolution();
	}
}

