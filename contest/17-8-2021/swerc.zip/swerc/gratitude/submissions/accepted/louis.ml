let scan_line () =  Scanf.scanf "%[^\n]\n" (fun x -> x)
let n,k = Scanf.scanf "%d %d\n" (fun x y -> (x,ref y))
let h = Hashtbl.create 300000 
let to_print = Array.make 300000 []    

let _ =
  for i = 1 to 3*n
  do
    let s = scan_line () in
    let x = 1+match Hashtbl.find_opt h s with Some(x) -> x | None -> 0 in
    Hashtbl.replace h s (x) ;
    to_print.(x) <- s::to_print.(x) ;
  done ;
  for i = 3*n downto 0
  do
    let rec printer = function
      | [] -> ()
      | x::q ->
         if !k > 0
         then
           begin
             decr k ;
             print_string x ;
             print_newline() ;
             printer q
           end
    in
    to_print.(i) |>
      List.filter (fun s -> Hashtbl.find h s == i)  |>
      printer 
  done ;
