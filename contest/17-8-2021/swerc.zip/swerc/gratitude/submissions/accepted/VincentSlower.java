import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VincentSlower {
	private static final Map<String, Integer> occurrences = new HashMap<>();
	private static final Map<String, Integer> lastOccurrence = new HashMap<>();
	private static final List<String> list = new ArrayList<>();
	private static int K;

	private static void read() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line = br.readLine().split(" ");
		int N = Integer.parseInt(line[0]);
		K = Integer.parseInt(line[1]);
		for (int i = 0; i < 3 * N; i++) {
			String s = br.readLine();
			lastOccurrence.put(s, i);
			occurrences.merge(s, 1, (x, y) -> x + y);
		}
		br.close();
	}

	private static Comparator<String> comparator() {
		return new Comparator<String>() {

			@Override
			public int compare(String s1, String s2) {
				int o1 = occurrences.get(s1);
				int o2 = occurrences.get(s2);
				return o1 == o2 ? lastOccurrence.get(s2) - lastOccurrence.get(s1) : o2 - o1;
			}

		};
	}

	private static void printSolution() {
		list.addAll(occurrences.keySet());
		list.sort(comparator());
		int len = list.size();
		for (int i = 0; i < K && i < len; i++) {
			System.out.println(list.get(i));
		}
	}

	public static void main(String[] args) throws IOException {
		read();
		printSolution();
	}
}

