#! /usr/bin/python

def myint(s):
    assert s == "0" or not s.startswith("0"),\
            "leading 0 detected"
    return int(s)

try: input = raw_input  # Python 2 compatibility
except: pass

N, K = map(myint, input().split())

assert(1<=K<=3*N<=100000)

import sys
lines = sys.stdin.readlines()
assert(len(lines)==3*N)
i = 0
valid=set()
for c in range(1,128):
    valid.add(chr(c))

(a,b,c) = ("","","")
for v in lines:
    for ch in v:
        assert(ch in valid)
    assert(len(v)<=50)
    (a,b,c) = (b,c,v)
    i = i + 1
    if (i == 3):
        i = 0
        assert(a != b and b != c and c != a)
exit(42)        
