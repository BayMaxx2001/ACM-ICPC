#! /usr/bin/python3
#

import sys

def myint(s):
    assert s == "0" or not s.startswith("0"),\
            "leading 0 detected"
    return int(s)
    
try: input = raw_input  # Python 2 compatibility
except: pass

n,m = map(myint,input().split())

lines = sys.stdin.readlines()
assert(len(lines)==m)

assert(1<=n<=100000)
assert(1<=m<=100000)

mat = dict()

for line in lines:
    i,j = map(myint,line.split())
    assert(1<=i<=n)
    assert(1<=j<=n)
    assert(i!=j)
    if not (i in mat):
        mat[i]=[]
    if not (j in mat):
        mat[j]=[]
    assert(not (i in mat[j]))
    assert(not (j in mat[i])) 
    mat[i].append(j)
    mat[j].append(i)
exit(42)  

