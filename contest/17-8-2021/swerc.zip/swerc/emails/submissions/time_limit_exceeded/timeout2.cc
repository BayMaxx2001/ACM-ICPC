#include <cstdio>
#include <set>

#define MAXN 100000

using namespace std;
typedef set<long> AddressBook;

long N, M, days;
AddressBook* current;
AddressBook* updated;
set<long> notConverged;


int main () 
{
    size_t ret;
    ret = scanf("%ld %ld\n",&N,&M);
    current = new AddressBook[N];
    updated = new AddressBook[N];
 
    for (int i = 0; i < N; ++i) {
	    notConverged.insert(i);
	    current[i].insert(i);
    }
		
    for (int i = 0; i < M; ++i){
        long r1, r2;
        ret = scanf("%ld %ld\n",&r1,&r2);
        r1--;r2--;
        current[r1].insert(r2);
        current[r2].insert(r1);
    }
	
	(void)ret;
	
	days = 0;
    
    while (notConverged.size()) {
	    days++;
	   // printf("%ld\n",days);
	    set<long> newNotConverged;
		for (int i: notConverged) {
			for (int j:current[i]) {
			    AddressBook b = current[j];
			    for (int c: b)
			        updated[i].insert(c);
			}
			if (updated[i].size() != current[i].size())
			    newNotConverged.insert(i);
		}
		notConverged = newNotConverged;
		
		AddressBook* aux = current; current = updated; updated = aux;
    }
		
	if (current[0].size() < N)
		printf("-1\n");
	else 
		printf("%ld\n",days);
	 
	delete[] current;
	delete[] updated;    
    return 0;
}




