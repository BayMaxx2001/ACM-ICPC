// usage: ./a.out input_file correct_output output_dir < contestants_output
// See specification there:
// http://www.problemarchive.org/wiki/index.php/Output_validator

#include <iostream>
#include "validate.h"

int main(int argc, char **argv) { 
    long realdiam, canddiam;
    init_io(argc, argv);   
    judge_ans >> realdiam;
    if (!(author_out >> canddiam)) {
      wrong_answer("Unexpected token in output\n");
    }
    if ((realdiam == -1 && canddiam != -1) || 
        (realdiam != -1 && canddiam != realdiam && canddiam != realdiam + 1))
            wrong_answer("incorrect answer");
    accept();
}
