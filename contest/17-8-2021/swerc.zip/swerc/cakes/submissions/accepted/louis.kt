fun main() {
  val n = readLine()!!.toInt() ;
  var res = 10000;
  for(i in 1..n) {
    val r = readLine()!!.split(" ").map{ it.toInt()};
    val canDo = r[1]/r[0] ;
    if(res > canDo) {
      res = canDo;
    }
  }
  println(res);
}
