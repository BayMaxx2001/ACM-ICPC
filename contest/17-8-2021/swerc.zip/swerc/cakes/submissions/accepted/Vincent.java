import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Vincent {
	private static void read() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line = br.readLine().split(" ");
		int N = Integer.parseInt(line[0]);
		int max = Integer.MAX_VALUE;
		for (int i = 0; i < N; i++) {
			line = br.readLine().split(" ");
			int need = Integer.parseInt(line[0]);
			int have = Integer.parseInt(line[1]);
			max = Math.min(max, have / need);
		}
		br.close();
		System.out.println(max);
	}
	
	public static void main(String[] args) throws IOException {
		read();
	}
}

