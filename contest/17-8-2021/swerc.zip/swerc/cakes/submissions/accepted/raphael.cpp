#include <iostream>
#include <cassert>

int main() {
  int N;
  std::cin >> N;
  assert(N >= 1);
  assert(N <= 10);
  int res = 10'000;
  for (int i = 0; i < N; ++i) {
    int need, have;
    std::cin >> need >> have;
    assert(need > 0);
    assert(need <= 10'000);
    assert(have > 0);
    assert(have <= 10'000);
    res = std::min(res, have / need);
  }
  std::cout << res << std::endl;
}
