try: input=raw_input
except: pass

N = int(input())
result = 10000000

for k in range(N):
  a,b = map(int,input().split())
  b = int(b/a)
  if result > b:
    result = b

print(result)
