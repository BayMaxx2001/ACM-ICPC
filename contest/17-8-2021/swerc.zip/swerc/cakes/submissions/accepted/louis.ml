let scan_int () = Scanf.scanf " %d" (fun x -> x)

let rec getOut res i =
  if i = 0
  then res
  else
    let a = scan_int() in
    getOut ( min res (scan_int()/a)) (i-1)
;;
print_int (getOut 10000 (scan_int())) ;
print_newline ()
