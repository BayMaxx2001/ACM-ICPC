import random

r_min = 1000
r_max = 2000

have_max = 10000
have_min = 1000

N = 10
print(N)

for _ in range(N):
    have = random.randint(have_min, have_max)
    r = random.uniform(r_min, r_max)
    need = int(have / r)
    need = max(need, 1)
    assert(have >= 1 and have <= 10000)
    assert(need >= 1 and need <= 10000)
    print(need, have)
    
