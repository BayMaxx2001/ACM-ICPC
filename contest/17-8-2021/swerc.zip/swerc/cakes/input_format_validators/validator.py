#! /usr/bin/python3
#

import math

try: input = raw_input  # Python 2 compatibility
except: pass

def valid_int(s):
    assert len(s)>0
    assert s == '0' or s[0] != '0'  # Reject leading 0
    return int(s)

import sys
line = sys.stdin.readline()
N = valid_int(line)
assert(N >= 1)
assert(N <= 10)
for _ in range(N):
    line = sys.stdin.readline().split(' ')
    assert(len(line) == 2)
    need = valid_int(line[0])
    have = valid_int(line[1])
    assert(need >= 1 and need <= 10000)
    assert(have >= 1 and have <= 10000)

line = sys.stdin.readline()
assert not line, f'Found extra input: {line}'
sys.exit(42)
