#include<vector>
#include<cstdio>

using namespace std;

const int N = 1000000;
const long long INF = 1000000000000;

int jump[N];

enum { WHITE = 0, GREY, BLACK };
char colors[N];
int depth[N];

int iterated[N];
int iterated2[N];

long long iteratedsum[N];
long long iterated2sum[N];

int main() {
  int n, k;
  scanf("%d%d", &n, &k);
  for (int i = 1; i < n; i++) {
    jump[i] += i;
    for (int j = i; j < n; j += i)
       jump[j] ++;
  }
  for (int i = 0; i < n; i++) jump[i] %= n;

  for (int i = 0; i < n; i++) {
    vector<int> stk;
    int x = i, cnt = 0, d = 0;
    for(;;) {
      if (colors[x] == BLACK) {
        d = depth[x];
        break;
      }

      if (colors[x] == GREY) {
        d = cnt-depth[x];
        for(;;) {
          int y = stk.back();
          depth[y] = d;
          colors[y] = BLACK;
          stk.pop_back();
          if (y == x) break;
        }
        break;
      }

      colors[x] = GREY;
      stk.push_back(x);
      depth[x] = cnt;
      x = jump[x];
      cnt++;
    }

    while(stk.size() > 0) {
      d++;
      depth[stk.back()] = d;
      colors[stk.back()] = BLACK;
      stk.pop_back();
    }
  }

  for (int i = 0; i < n; i++) iterated[i] = i;
  for (int pow2 = (1 << 20); pow2 > 0; pow2 /= 2) {
    for (int i = 0; i < n; i++)
      if ((k-3) & pow2) {
        int a = jump[i];
        int b = iterated[a];

        iterated2[i] = iterated[b];
        iterated2sum[i] = a + iteratedsum[a] + iteratedsum[b];
      }
      else {
        int a = iterated[i];
        iterated2[i] = iterated[a];
        iterated2sum[i] = iteratedsum[i] + iteratedsum[a];
      }
    for (int i = 0; i < n; i++) {
      iterated[i] = iterated2[i];
      iteratedsum[i] = iterated2sum[i];
    }
  }

  long long minsum = INF;
  int mini = 0;
  for (int i = 0; i < n; i++) {
    if (depth[i] < k) continue;
    long long sum = i + iteratedsum[i];
    if (sum < minsum) {
      mini = i;
      minsum = sum;
    }
  }

  if (minsum == INF) {
    printf("-1\n");
  } else {
    int x = mini;
    for(int a = 0; a < k; a++) {
      printf("%d%c", x, a == k-1 ? '\n' : ' ');
      x = jump[x];
    }
  }
}
