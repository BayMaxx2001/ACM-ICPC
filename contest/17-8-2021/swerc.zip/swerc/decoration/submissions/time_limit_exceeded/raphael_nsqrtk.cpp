// Solution for decoration in O(N*log(log(N)) + N*sqrt(K)).
// This solution is suboptimal since one can do O(N*log(log(N)) + N*log(K)).

#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>

using namespace std;

int N, K;
int sqrt_K;

// Partial prime decomposition of a number N:
// N = A * p^val_B
// p is a prime power.
// gcd(A, p) = 1.
// (If N is a prime power, then A=1, val_B=1)
// val_B is the valuation of B (mod N).
struct Decomposition {
  int A, val_B;
};

// For each integer [0, N), returns the sum of its divisors mod N.
std::vector<int> sieve() {
  std::vector<int> res(N);
  // Filled (for non-prime numbers) by A, s.t. N=A*p^k and gcd(A, p^k) =
  // 1. If N is a prime power, then A=1.
  std::vector<Decomposition> decomp(N);
  res[1] = 1 % N;
  std::vector<int> visited(N);
  for (int i = 2; i < N; ++i) {
    if (visited[i]) {
      res[i] = (res[decomp[i].A] * static_cast<int64_t>(decomp[i].val_B)) % N;
      continue;
    }
    // "i" is prime.
    visited[i] = true;
    res[i] = 2 % N; // Divisors: i and 1.
    for (int j = i * 2; j < N; j += i) {
      if (visited[j])
        continue;
      visited[j] = true;
      int n_divisors_power_i = 1;
      int divided_j = j;
      for (; divided_j % i == 0; divided_j /= i, n_divisors_power_i++) {
      }
      assert(divided_j % i != 0);
      decomp[j] = {divided_j, n_divisors_power_i};
    }
  }
  for (int i = 1; i < N; ++i)
    res[i] = (res[i] + i) % N;
  return res;
}

struct ElmtInfo {
  int cur;
  int next;

  bool in_cycle;
  int cycle_size; // size of the current cycle, or of the cycle we'll reach.
  int distance_to_cycle; // 0 if we are already on a cycle.

  // f^k(cur). k is not specified here but likely aroud sqrt(k).
  // TODO(raphael): Could be made faster by storing multiple "fast
  // forward links" for powers of 2, so that we reach O(N*log(N))
  // complexity.
  int next_fast_forward;
  int fast_forward_steps;
  int sum_fast_forward;

  int visitor_starting_point = -1;
  int first_visit_pos = -1;
};

struct Ret {
  int distance_to_cycle;
  int cycle_size;
  int cycle_detection_pos;

  int next_fast_forward;
  int fast_forward_steps;
  int sum_fast_forward;
};

Ret iter(int x, int starting_point, int pos, const vector<int> &jump,
         vector<ElmtInfo> &elements) {
  //  cout << "x " << x << " starting_pos " << starting_point << " pos " << pos
  //  << endl;
  ElmtInfo &e = elements[x];
  if (e.visitor_starting_point >= 0) {
    // Already visited.
    if (e.visitor_starting_point == starting_point) {
      // Newly discovered cycle.
      e.in_cycle = true;
      e.cycle_size = pos - e.first_visit_pos;
      //      cout << "new cycle sz " << e.cycle_size << endl;
      return {0, e.cycle_size, pos, x, 0, 0};
    } else {
      //      cout << "Hit already visited: distance to cycle: " <<
      //      e.distance_to_cycle
      //	   << " cycle sz: " << e.cycle_size << endl;
      // Already visited element (might be in cycle or not).
      // The caller won't be in a cycle, make sure cycle_detection_pos
      // is very high so that the caller computes in_cycle=false.
      return {e.distance_to_cycle, e.cycle_size, 1'000'000'000, x, 0, 0};
    }
  }
  // Not visited.
  e.cur = x;
  e.next = jump[x];
  e.first_visit_pos = pos;
  e.visitor_starting_point = starting_point;
  e.in_cycle = false; // For now.

  const auto ret = iter(e.next, starting_point, pos + 1, jump, elements);

  e.in_cycle = ret.cycle_detection_pos - pos <= ret.cycle_size;
  e.cycle_size = ret.cycle_size;
  if (e.in_cycle) {
    e.distance_to_cycle = 0;
  } else {
    e.distance_to_cycle = ret.distance_to_cycle + 1;
  }
  e.next_fast_forward = ret.next_fast_forward;
  e.fast_forward_steps = ret.fast_forward_steps + 1;
  e.sum_fast_forward = ret.sum_fast_forward + x;
  bool reset_ff = e.fast_forward_steps >= sqrt_K;
  return {e.distance_to_cycle,
          ret.cycle_size,
          ret.cycle_detection_pos,
          reset_ff ? x : e.next_fast_forward,
          reset_ff ? 0 : e.fast_forward_steps,
          reset_ff ? 0 : e.sum_fast_forward};
}

void solve(const vector<int> &jump) {
  vector<ElmtInfo> elements(N);
  for (int start = 0; start < N; ++start) {
    iter(start, start, 0, jump, elements);
  }
  // for (auto e : elements) {
  //   cout << "x " << e.cur << " next " << e.next
  // 	 << " cycle sz " << e.cycle_size << " d to cycle " <<
  // e.distance_to_cycle
  // 	 << " next ff " << e.next_fast_forward
  // 	 << " ff steps " << e.fast_forward_steps
  // 	 << " ff sum " << e.sum_fast_forward
  // 	 << endl;
  // }

  int64_t best = (1LL) << 62;
  int best_start = -1;
  for (int x = 0; x < N; ++x) {
    ElmtInfo &e = elements[x];
    // Maximum number of unique values seen when iterating starting from x.
    int num_different = e.distance_to_cycle + e.cycle_size;
    if (num_different < K) {
      continue;
    }
    int64_t sum = 0;
    int remaining = K;
    int cur = x;
    while (elements[cur].fast_forward_steps < remaining) {
      sum += elements[cur].sum_fast_forward;
      remaining -= elements[cur].fast_forward_steps;
      cur = elements[cur].next_fast_forward;
    }
    while (remaining) {
      sum += cur;
      remaining--;
      cur = elements[cur].next;
    }
    if (sum < best) {
      best = sum;
      best_start = x;
    }
    //    cout << "candidate start: " << x << " sum: " << sum << endl;
  }
  if (best_start < 0) {
    cout << -1 << endl;
  } else {
    for (int x = best_start, i = 0; i < K; ++i) {
      cout << x;
      if (i + 1 < K)
        cout << " ";
      x = jump[x];
    }
    cout << endl;
  }
}

int main() {
  cin >> N >> K;
  sqrt_K = max(10, static_cast<int>(sqrt(K)));
  vector<int> jump = sieve();
  //  for (int i = 0; i < N; ++i) {
  //    cout << i << ": " << jump[i] << endl;
  //  }
  solve(jump);
}
