N,K=map(int, input().split())
sums = [i for i in range(N)]
depthOf = [None for _ in range(N) ]

for i in range(1,N):
    for j in range(i,N,i):
        sums[j] = (sums[j] + 1) % N

def combine(v,w):
    r = []
    for (el,s) in v:
        (el2,s2) = w[el]
        r.append((el2,s2+s))
    return r

def exp(k,v):
    if k == 1:
        return v
    if k%2:
        return combine(v,exp(k-1,v))
    return exp(k/2,combine(v,v))

def dfs(node,cur):
    global depthOf
    if depthOf[node] == None:
        depthOf[node] = -cur
        (depth,loop) = dfs(sums[node],cur+1)
        depthOf[node] = depth
        if loop>0:
            return (depth,loop-1)
        depthOf[node]+=1
    if depthOf[node] < 0:
        return (cur+depthOf[node],cur+depthOf[node])
    return (depthOf[node],0)

f = exp(K,[ (sums[i],i) for i in range(N)])
best = 10**9
el = -1
for i in range(N):
    (d,l) = dfs(i,1)
    (e,v) = f[i]
    if d>= K and v < best:
        best = v
        el = i

res = []
if el < 0:
    res = [-1]
else:
    for i in range(K):
        res.append(el)
        el=sums[el]
print(" ".join(map(str,res)))
