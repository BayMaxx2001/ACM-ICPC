import java.util.Arrays

fun main () {
  val input = readLine()!!.split(" ");
  val n = input[0].toInt();
  val k = input[1].toInt();

  var nbDiv = IntArray(n,{i->i}) ;
  for(i in 1..n-1) {
    for(j in i..n-1 step i) {
      nbDiv[j] += 1 ;
    }
    nbDiv[i] %= n ;
  }

  var ck = 1 ;
  var curExp = IntArray(n,{i->nbDiv[i]});
  var curExpSum = LongArray(n,{i->i.toLong()}) ;
  var funcSum = LongArray(n,{i->0L}) ;
  var func = IntArray(n,{i->i}) ;
  var tmp = IntArray(n,{i->i}) ;
  var tmpSum = LongArray(n,{i->0L}) ;
  while(ck <= k) {
    if( (ck and k) != 0 ) {
      for(i in 0..n-1) {
        funcSum[i] += curExpSum[func[i]] ;
        func[i] = curExp[func[i]] ;
      }
    }
    for(i in 0..n-1) {
      tmp[i] = curExp[i];
      tmpSum[i] = curExpSum[i];
    }
    for(i in 0..n-1) {
      curExp[i] = tmp[tmp[i]] ;
      curExpSum[i] +=  tmpSum[tmp[i]];
    }
    ck *= 2 ;
  }
  
  var depthOf = Array(n,{_->-2});
  var best = -1 ;
  val stack = Array(n+1,{0});
  for(node in 0..n-1) {
    var cur = node
    var stackS = 0;
    while(depthOf[cur] == -2) {
      stack[stackS] = cur;
      stackS++;
      depthOf[cur] = -1;
      cur = nbDiv[cur];
    }
    stack[stackS]=cur;
    if(depthOf[cur] < 0) {
      var len = 1 ;
      while(stack[stackS-len] != cur) {
        len += 1;
      }
      for(i in stackS-len..stackS-1) {
        depthOf[stack[i]] = len ;
      }
    }
    while(stackS > 0) {
      stackS -- ;
      if(depthOf[stack[stackS]] < 0) {
        depthOf[stack[stackS]] = depthOf[stack[stackS+1]]+1;
      }
    }
    if(depthOf[node]>=k && (best == -1 || funcSum[best] >= funcSum[node])) {
      best = node
    }
  }
  
  if(best == -1) {
    println(-1);
  } else {
    for(i in 2..k) {
      print(best);
      best = nbDiv[best] ;
      print(" ")
    }
    println(best);
  }
}

