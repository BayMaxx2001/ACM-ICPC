let inf = 1000000000000

let (n, k) = Scanf.scanf "%d %d\n" (fun n k -> (n, k))

(* Compute [jump] *)
let jump = Array.init n (fun i -> i)
let () =
  for i = 1 to n-1 do
    let rec loop j =
      if j < n then begin jump.(j) <- jump.(j) + 1; loop (i+j) end else ()
    in
    loop i
  done;
  for i = 1 to n-1 do
    jump.(i) <- jump.(i) mod n
  done

(* DFS *)
type col = White | Grey | Black
let colors = Array.make n White
let depth = Array.make n 0

type ret = Cycle of int * int | Arm of int

let rec dfs x cnt =
  match colors.(x) with
  | Black -> Arm(depth.(x))
  | Grey -> Cycle(cnt-depth.(x), x)
  | White ->
     colors.(x) <- Grey;
     depth.(x) <- cnt;
     match dfs jump.(x) (cnt+1) with
     | Arm(d) ->
        depth.(x) <- d+1;
        colors.(x) <- Black;
        Arm(d+1)
     | Cycle(d, x0) ->
        depth.(x) <- d;
        colors.(x) <- Black;
        if x0 = x then Arm(d) else Cycle(d, x0)

let () =
  for i = 0 to n-1 do ignore (dfs i 0) done

(* Fast exp *)
let rec fastexp = function
  | 0 -> (Array.init n (fun i -> i), Array.make n 0,
          Array.make n 0, Array.make n 0)
  | e ->
     let (iterated, iteratedsum, iteratedr, iteratedsumr) = fastexp (e/2) in
     if e mod 2 == 0 then
       for i = 0 to n-1 do
         let a = iterated.(i) in
         iteratedr.(i) <- iterated.(a);
         iteratedsumr.(i) <- iteratedsum.(i) + iteratedsum.(a)
       done
     else
       for i = 0 to n-1 do
         let a = jump.(i) in
         let b = iterated.(a) in
         iteratedr.(i) <- iterated.(b);
         iteratedsumr.(i) <- a + iteratedsum.(a) + iteratedsum.(b)
       done;
     (iteratedr, iteratedsumr, iterated, iteratedsum)
let (_, iteratedsum, _, _) = fastexp (k-1)

(* Conclusion *)
let rec loop acc i =
  if i >= n then acc
  else if depth.(i) < k then loop acc (i+1)
  else let acc = min (i + iteratedsum.(i), i) acc in
       loop acc (i+1)
let (minsum, mini) = loop (inf, 0) 0
let () =
  if minsum = inf then Printf.printf "-1\n"
  else
    let rec print x = function
      | 1 -> Printf.printf "%d\n" x
      | k -> Printf.printf "%d " x; print jump.(x) (k-1)
    in
    print mini k
