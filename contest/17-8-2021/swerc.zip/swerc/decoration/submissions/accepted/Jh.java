import java.util.Scanner;
import java.util.Stack;

public class Jh
{
    static final long INF = 1000000000000L;
    static final int WHITE = 0;
    static final int GREY = 1;
    static final int BLACK = 2;

    public static void main(String[] args)
    {
        Scanner input = new Scanner( System.in );
        int N = input.nextInt();
        int K = input.nextInt();
        int[] jump = new int[N];
        for (int i = 1; i < N; i++) {
            jump[i] += i;
            for (int j = i; j < N; j+=i)
                jump[j]++;
        }
        for (int i = 0; i < N; i++) jump[i] %= N;

        int[] colors = new int[N], depth = new int[N];
        Stack<Integer> stk = new Stack<Integer>();
        for (int i = 0; i < N; i++) {
            int x = i, cnt = 0, d = 0;
            while (true) {
                if (colors[x] == BLACK) {
                    d = depth[x];
                    break;
                }
                if (colors[x] == GREY) {
                    d = cnt-depth[x];
                    while (true) {
                        int y = stk.pop();
                        depth[y] = d;
                        colors[y] = BLACK;
                        if (y == x) break;
                    }
                    break;
                }

                colors[x] = GREY;
                stk.push(x);
                depth[x] = cnt;
                x = jump[x];
                cnt++;
            }

            while (!stk.empty()) {
                d++;
                int y = stk.pop();
                depth[y] = d;
                colors[y] = BLACK;
            }
        }

        int[] iterated = new int[N];
        long[] iteratedsum = new long[N];
        int[] iteratedr = new int[N];
        long[] iteratedsumr = new long[N];
        for (int i = 0; i < N; i++) iterated[i] = i;
        for (int pow2 = (1 << 20); pow2 > 0; pow2 /= 2) {
            for (int i = 0; i < N; i++) {
                if (((K-1) & pow2) == 0) {
                    int a = iterated[i];
                    iteratedr[i] = iterated[a];
                    iteratedsumr[i] = iteratedsum[i] + iteratedsum[a];
                } else {
                    int a = jump[i];
                    int b = iterated[a];

                    iteratedr[i] = iterated[b];
                    iteratedsumr[i] = a + iteratedsum[a] + iteratedsum[b];
                }
            }
            int[] tmp  = iterated;    iterated    = iteratedr;    iteratedr = tmp;
            long[]tmps = iteratedsum; iteratedsum = iteratedsumr; iteratedsumr = tmps;
        }

        long minsum = INF;
        int mini = 0;
        for (int i = 0; i < N; i++) {
            if (depth[i] < K) continue;
            long sum = i + iteratedsum[i];
            if (sum < minsum) {
                mini = i;
                minsum = sum;
            }
        }

        if (minsum == INF) {
            System.out.println("-1\n");
        } else {
            int x = mini;
            for (int a = 0; a < K; a++) {
                System.out.print(x);
                if (a < K-1) System.out.print(' ');
                x = jump[x];
            }
            System.out.println();
        }
    }
}
