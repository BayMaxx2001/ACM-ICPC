def combine(v,w):
    return [ (w[el][0],w[el][1]+s) for (el,s) in v]

def exp(k,v):
    if k == 1:
        return v
    if k%2:
        return combine(v,exp(k-1,v))
    return exp(k/2,combine(v,v))

N,K=map(int, input().split())
nbDiv = [i for i in range(N)]
depthOf = [None for _ in range(N) ]
for i in range(1,N):
    for j in range(i,N,i):
        nbDiv[j] += 1
    nbDiv[i] %= N
f = exp(K,[ (nbDiv[i],i) for i in range(N)])
best = (10**20,-1)
for node in range(N):
    cur = node
    stack = []
    while depthOf[cur] == None:
        stack.append(cur)
        depthOf[cur] = -1
        cur = nbDiv[cur]
    if depthOf[cur] < 0:
        pos = stack.index(cur)
        for p in range(pos,len(stack)):
            depthOf[stack[p]] = len(stack) - pos
    while len(stack):
        el = stack.pop()
        if depthOf[el] < 0:
            depthOf[el] = depthOf[nbDiv[el]]+1
    if depthOf[node]>= K:
        best = min(best,(f[node][1],node))
res = [best[1]]
if res[-1] >= 0:
    for i in range(1,K):
        res.append(nbDiv[res[-1]])
print(" ".join(map(str,res)))
