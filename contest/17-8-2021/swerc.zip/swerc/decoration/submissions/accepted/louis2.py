def combine(v,w):
    return [ (w[el][0],w[el][1]+s) for (el,s) in v]

N,K=map(int, input().split())

# Compute nb divisors
nbDiv = [i for i in range(N)]
for i in range(1,N):
    for j in range(i,N,i):
        nbDiv[j] += 1
    nbDiv[i] %= N

# Compute exponentiation
f = [ (i,0) for i in range(N)]
power = [ (nbDiv[i],i) for i in range(N)]
k=K
while k > 0:
    if k%2:
        f = combine(f,power)
    power = combine(power,power)
    k = k//2

# Compute depth and find best
depthOf = [None for _ in range(N) ]
for node in range(N):
    cur = node
    stack = []
    while depthOf[cur] == None:
        stack.append(cur)
        depthOf[cur] = -1
        cur = nbDiv[cur]
    if depthOf[cur] < 0:
        pos = stack.index(cur)
        for p in range(pos,len(stack)):
            depthOf[stack[p]] = len(stack) - pos
    while len(stack):
        el = stack.pop()
        if depthOf[el] < 0:
            depthOf[el] = depthOf[nbDiv[el]]+1

try:
    res = [min([(f[node][1],node) for node in range(N) if depthOf[node]>=K])[1]]
    for i in range(1,K):
        res.append(nbDiv[res[-1]])
        print(" ".join(map(str,res)))
except:
    print("-1")
