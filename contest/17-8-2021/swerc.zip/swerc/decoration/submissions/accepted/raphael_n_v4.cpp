// Solution for decoration in O(N*log(log(N))) (the part after the sum
// of divisor computation being O(N)).
// In practice it's often slower than NlogN solutions, maybe because of
// the use of the slow std::list. Instead we could use a "circular
// vector" that would speed up things greatly.

#include <cassert>
#include <cmath>
#include <iostream>
#include <list>
#include <vector>

using namespace std;

int N, K;

const bool DEBUG = false;
const bool EXPENSIVE_ASSERTS = false;

vector<int> jump;
int64_t MAX = 1LL << 62;

struct SecondPass {
  // This is sum(x, ..., f^{k-1}(x)).
  int64_t sum;
};
vector<SecondPass> second_pass;

struct Cycle {
  // Order: u0, f(u0), f^2(u0), etc...
  list<int> x;
  vector<list<int>::iterator> index;
  // partial_sums[i] contains the sum of range [0, i). This contains
  // index.size() + 1 elements.
  std::vector<int64_t> partial_sums;
};

vector<Cycle> cycles;

struct ElmtInfo {
  int cur;
  int next;
  vector<int> prev;
  bool in_cycle;
  int cycle_size; // size of the current cycle, or of the cycle we'll reach.
  int distance_to_cycle; // 0 if we are already on a cycle.
  // Index into cycles. Only makes sense when in_cycle is true.
  int cycle_index = 1;
  // Index into cycle[cycle_index].index.
  int index_in_cycle;

  int visitor_starting_point = -1;
  int first_visit_pos = -1;
};

struct Ret {
  int distance_to_cycle;
  int cycle_size;
  int cycle_detection_pos;
};

struct CircularView {
  CircularView(list<int> &l, list<int>::iterator begin, list<int>::iterator end,
               int range_size)
      : l(l), begin(begin), end(end), range_size(range_size) {
    fix_end();
    assert(range_size > 0);
  }

  void Print() {
    for (auto it = begin; it != end;) {
      cout << *it << " ";
      ++it;
      if (it == end)
        break;
      if (it == l.end())
        it = l.begin();
    }
  }

  // Only for debugging.
  int64_t Sum() {
    int64_t s = 0;
    for (auto it = begin; it != end;) {
      s += *it;
      ++it;
      if (it == end)
        break;
      if (it == l.end())
        it = l.begin();
    }
    return s;
  }

  int size() { return range_size; }
  void fix_end() {
    if (end == l.begin()) {
      end = l.end();
    }
  }
  int back() {
    assert(end != l.begin());
    assert(range_size > 0);
    return *std::prev(end);
  }
  void pop_back() {
    // For now we don't support poping from lists of size 1.
    assert(range_size > 1);
    assert(end != l.begin());
    end = std::prev(end);
    assert(end != begin);
    fix_end();
    range_size--;
  }
  void push_back(int e) {
    if (end == l.end()) {
      assert(*l.begin() == e);
      end = std::next(l.begin());
    } else {
      assert(*end == e);
      ++end;
    }
    range_size++;
  }
  void push_front(int e) {
    assert(range_size > 0);
    bool was_equal = end == begin;
    if (was_equal)
      assert(range_size == l.size());
    begin = l.insert(begin, e);
    if (was_equal)
      end = begin;
    range_size++;
  }
  void pop_front() {
    assert(range_size > 0);
    bool was_equal = end == begin;
    if (was_equal)
      assert(range_size == l.size());
    // TODO: could check that we never erase elements from the original cycle.
    begin = l.erase(begin);
    if (was_equal)
      end = begin;
    range_size--;
  }

  list<int> &l;
  list<int>::iterator begin;
  list<int>::iterator end;
  int range_size;
};

// "range_size" is the distance between predecessors_end and
// predecessors_begin.
// Returns (lowest_sum, starting_point_lowest_sum).
pair<int64_t, int> dfs_second_pass_it2(int x, CircularView &circular,
                                       int64_t &sum, int K,
                                       vector<ElmtInfo> &elements) {
  if (DEBUG) {
    cout << "dfs_second_pass_it " << x << " pred ";
    circular.Print();
    //  cout << " begin: " << *predecessors_begin;
    //  cout << " prev(end): " << *std::prev(predecessors_end);
    cout << " range_size: " << circular.size();
    cout << " sum: " << sum << endl;
  }

  int predecessor_back_save = -1;
  pair<int64_t, int> ret(MAX, -1);
  if (circular.size() == K) {
    second_pass[x].sum = sum;
    if (sum < ret.first) {
      ret = make_pair(sum, x);
    }
    if (DEBUG) {
      cout << "second pass in " << x << " assigning sum: " << sum << endl;
    }
    predecessor_back_save = circular.back();
    sum -= circular.back();
    circular.pop_back();
  }

  for (int pred : elements[x].prev) {
    if (elements[pred].in_cycle) {
      continue;
    }
    circular.push_front(pred);
    sum += pred;
    auto rec = dfs_second_pass_it2(pred, circular, sum, K, elements);
    if (rec < ret)
      ret = rec;
    sum -= pred;
    circular.pop_front();
  }
  if (predecessor_back_save >= 0) {
    sum += predecessor_back_save;
    circular.push_back(predecessor_back_save);
  }
  if (DEBUG) {
    cout << "return dfs_second_pass_it " << x << " pred ";
    circular.Print();
    cout << endl;
  }
  return ret;
}

// Partial prime decomposition of a number N:
// N = A * p^val_B
// p is a prime power.
// gcd(A, p) = 1.
// (If N is a prime power, then A=1, val_B=1)
// val_B is the valuation of B (mod N).
struct Decomposition {
  int A, val_B;
};

// For each integer [0, N), returns the sum of its divisors mod N.
std::vector<int> sieve() {
  std::vector<int> res(N);
  // Filled (for non-prime numbers) by A, s.t. N=A*p^k and gcd(A, p^k) =
  // 1. If N is a prime power, then A=1.
  std::vector<Decomposition> decomp(N);
  res[1] = 1 % N;
  std::vector<int> visited(N);
  for (int i = 2; i < N; ++i) {
    if (visited[i]) {
      res[i] = (res[decomp[i].A] * static_cast<int64_t>(decomp[i].val_B)) % N;
      continue;
    }
    // "i" is prime.
    visited[i] = true;
    res[i] = 2 % N; // Divisors: i and 1.
    for (int j = i * 2; j < N; j += i) {
      if (visited[j])
        continue;
      visited[j] = true;
      int n_divisors_power_i = 1;
      int divided_j = j;
      for (; divided_j % i == 0; divided_j /= i, n_divisors_power_i++) {
      }
      assert(divided_j % i != 0);
      decomp[j] = {divided_j, n_divisors_power_i};
    }
  }
  for (int i = 1; i < N; ++i)
    res[i] = (res[i] + i) % N;
  return res;
}

Ret iter(int x, int prev, int starting_point, int pos, const vector<int> &jump,
         vector<ElmtInfo> &elements, list<int> &cycle, int cycle_index) {
  ElmtInfo &e = elements[x];
  if (prev >= 0) {
    e.prev.push_back(prev);
  }
  if (e.visitor_starting_point >= 0) {
    // Already visited.
    if (e.visitor_starting_point == starting_point) {
      // Newly discovered cycle.
      e.in_cycle = true;
      e.cycle_size = pos - e.first_visit_pos;
      return {0, e.cycle_size, pos};
    } else {
      // Already visited element (might be in cycle or not).
      // The caller won't be in a cycle, make sure cycle_detection_pos
      // is very high so that the caller computes in_cycle=false.
      return {e.distance_to_cycle, e.cycle_size, 1'000'000'000};
    }
  }
  // Not visited.
  e.cur = x;
  e.next = jump[x];
  e.first_visit_pos = pos;
  e.visitor_starting_point = starting_point;
  e.in_cycle = false; // For now.

  const auto ret = iter(e.next, x, starting_point, pos + 1, jump, elements,
                        cycle, cycle_index);

  e.in_cycle = ret.cycle_detection_pos - pos <= ret.cycle_size;
  e.cycle_size = ret.cycle_size;
  if (e.in_cycle) {
    e.distance_to_cycle = 0;
    e.cycle_index = cycle_index;

    cycle.push_front(x);
    e.index_in_cycle = ret.cycle_size - cycle.size();
  } else {
    e.distance_to_cycle = ret.distance_to_cycle + 1;
  }
  return {e.distance_to_cycle, ret.cycle_size, ret.cycle_detection_pos};
}

void ProcessCycle(Cycle &cycle) {
  auto it = cycle.x.begin();
  int64_t s = 0;
  for (int i = 0; i < cycle.x.size(); ++i) {
    cycle.index.push_back(it);
    cycle.partial_sums.push_back(s);
    s += *it;
    ++it;
  }
  cycle.partial_sums.push_back(s);
}

void CheckCycleIterators(Cycle &cycle) {
  auto it = cycle.x.begin();
  for (int i = 0; i < cycle.x.size(); ++i) {
    assert(it == cycle.index[i]);
    ++it;
  }
}

pair<int64_t, int> solve(const vector<int> &jump) {
  vector<ElmtInfo> elements(N);
  for (int start = 0; start < N; ++start) {
    Cycle cycle;
    iter(start, -1, start, 0, jump, elements, cycle.x, cycles.size());
    if (!cycle.x.empty()) {
      ProcessCycle(cycle);
      // Make sure the iterators to the list are not invalidated.
      cycles.emplace_back(std::move(cycle));
    }
  }

  if (DEBUG) {
    for (auto e : elements) {
      cout << "x " << e.cur << " next " << e.next << " cycle sz "
           << e.cycle_size << " d to cycle " << e.distance_to_cycle
           << " cycle index: " << (e.in_cycle ? e.cycle_index : -1) << endl;
    }
    for (int c = 0; c < cycles.size(); ++c) {
      cout << "cycle " << c << ": ";
      for (auto x : cycles[c].x)
        cout << x << " ";
      cout << endl;
    }
  }

  pair<int64_t, int> best(MAX, -1);
  second_pass.resize(N);
  for (int x = 0; x < N; ++x) {
    auto &e = elements[x];
    if (!e.in_cycle) {
      continue;
    }
    if (DEBUG) {
      cout << "Considering starting second pass from " << x << endl;
    }
    assert(e.cycle_index >= 0);
    Cycle &cycle = cycles[e.cycle_index];
    int64_t sum = 0;

    // Poor-man's version with a copy in O(K).
    /*
    std::list<int> predecessors;//
    // TODO: this is now in the wrong direction.
    for (int i = e.index_in_cycle ; i >= 0 && predecessors.size() < K; --i) {
      predecessors.push_back(*cycle.index[i]);
      sum += predecessors.back();
    }
    for (int i = cycle.index.size() - 1; i > e.index_in_cycle &&
    predecessors.size() < K; --i) { predecessors.push_back(*cycle.index[i]); sum
    += predecessors.back();
    }
    if (predecessors.size() == K && sum < best.first) {
      best = make_pair(sum, *cycle.index[e.index_in_cycle]);
    }
    */
    /*
      cout << "At " << x << " got predecessors: ";
      for (auto p : predecessors) cout << p << " ";
      cout << endl;
    */

    int range_size = min<int>(K, cycle.index.size());
    if (e.index_in_cycle + range_size >= cycle.index.size()) {
      sum = cycle.partial_sums.back() - cycle.partial_sums[e.index_in_cycle] +
            cycle.partial_sums[(e.index_in_cycle + range_size) %
                               cycle.index.size()];
    } else {
      sum = cycle.partial_sums[e.index_in_cycle + range_size] -
            cycle.partial_sums[e.index_in_cycle];
    }
    Cycle cycle_copy;
    if (EXPENSIVE_ASSERTS) {
      cycle_copy = cycle;
    }
    CircularView circular(
        cycle.x, cycle.index[e.index_in_cycle],
        cycle.index[(e.index_in_cycle + range_size) % cycle.index.size()],
        range_size);
    if (circular.size() == K && sum < best.first) {
      best = make_pair(sum, *cycle.index[e.index_in_cycle]);
    }

    if (EXPENSIVE_ASSERTS) {
      assert(sum == circular.Sum());
    }

    if (DEBUG) {
      cout << "Considering second pass starting at " << x << " predecessors: ";
      circular.Print();
      cout << " sum: " << sum << endl;
    }

    if (e.prev.size() >= 2) {
      if (DEBUG) {
        cout << x << " is in a cycle and has >= 2 precessors: ";
        for (int p : e.prev)
          cout << p << " ";
        cout << "Starting second pass of DFS" << endl;
        circular.Print();
        cout << " sum: " << sum << endl;
      }
      auto ret = dfs_second_pass_it2(x, circular, sum, K, elements);
      if (ret < best)
        best = ret;
    }
    if (EXPENSIVE_ASSERTS) {
      assert(cycle_copy.x == cycle.x);
      CheckCycleIterators(cycle);
    }
  }
  return best;
}

int main() {
  cin >> N >> K;
  jump = sieve();

  pair<int64_t, int> best;
  if (K == 1) {
    cout << 0 << endl;
    return 0;
  } else {
    best = solve(jump);
  }
  if (best.first == MAX) {
    cout << -1 << endl;
  } else {
    int x = best.second;
    for (int i = 0; i < K; ++i) {
      cout << x;
      if (i + 1 < K)
        cout << " ";
      x = jump[x];
    }
    cout << endl;
  }
}

// TODO: corner cases to test in test cases:
// best sequence is entirely in a cycle (e.g 10 2) (and also entirely in a cycle
// and ends at a branching point). best sequence is entirely outside a cycle.
// K=1
// K = size of some cycle (preferably of a cycle that is strictly optimal).
