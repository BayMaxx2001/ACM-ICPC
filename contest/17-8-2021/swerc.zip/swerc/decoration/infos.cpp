#include<vector>
#include<cstdio>

using namespace std;

const int N = 1000000;
const long long INF = 1000000000000;

int jump[N];

enum { WHITE = 0, GREY, BLACK };
char colors[N];
int depth[N];

bool cycle[N];
bool haspred[N];

int iterated[N];
int iterated2[N];

long long iteratedsum[N];
long long iterated2sum[N];

int main() {
  int n, k;
  scanf("%d%d", &n, &k);
  for (int i = 1; i < n; i++) {
    jump[i] += i;
    for (int j = i; j < n; j += i)
       jump[j] ++;
  }
  for (int i = 0; i < n; i++) jump[i] %= n;

  for (int i = 0; i < n; i++) {
    vector<int> stk;
    int x = i, cnt = 0, d = 0;
    for(;;) {
      if (colors[x] == BLACK) {
        d = depth[x];
        break;
      }

      if (colors[x] == GREY) {
        d = cnt-depth[x];
        for(;;) {
          int y = stk.back();
          depth[y] = d;
          colors[y] = BLACK;
          stk.pop_back();
          cycle[y] = true;
          if (y == x) {
            if(stk.size() > 0)
              haspred[x] = true;
            break;
          }
        }
        break;
      }

      if (colors[jump[x]] == BLACK && cycle[jump[x]])
        haspred[jump[x]] = true;
      colors[x] = GREY;
      stk.push_back(x);
      depth[x] = cnt;
      x = jump[x];
      cnt++;
    }

    while(stk.size() > 0) {
      d++;
      depth[stk.back()] = d;
      colors[stk.back()] = BLACK;
      stk.pop_back();
    }
  }

  for (int i = 0; i < n; i++) iterated[i] = i;
  for (int pow2 = (1 << 20); pow2 > 0; pow2 /= 2) {
    for (int i = 0; i < n; i++)
      if ((k-1) & pow2) {
        int a = jump[i];
        int b = iterated[a];

        iterated2[i] = iterated[b];
        iterated2sum[i] = a + iteratedsum[a] + iteratedsum[b];
      }
      else {
        int a = iterated[i];
        iterated2[i] = iterated[a];
        iterated2sum[i] = iteratedsum[i] + iteratedsum[a];
      }
    for (int i = 0; i < n; i++) {
      iterated[i] = iterated2[i];
      iteratedsum[i] = iterated2sum[i];
    }
  }

  long long minsum = INF;
  int mini = 0;
  bool dbl = false;
  for (int i = 0; i < n; i++) {
    if (depth[i] < k) continue;
    long long sum = i + iteratedsum[i];
    if (sum < minsum) {
      mini = i;
      minsum = sum;
      dbl = false;
    } else if (sum == minsum)
      dbl = true;
  }

  if (minsum == INF) {
    printf("Impossible\n");
  } else {
    if (!dbl)
      printf("Unique solution.\n");
    else
      printf("Several solutions.\n");
    if (cycle[mini]) {
      printf("Fully in cycle.\n");
      if (jump[iterated[mini]] == mini)
        printf("Entire cycle.\n");
      if (haspred[mini])
        printf("Start has a predecessor.\n");
      if (haspred[iterated[mini]])
        printf("End has a predecessor.\n");
    }
    if (!cycle[iterated[mini]])
      printf("Fully outside of cycles.\n");
  }
}
