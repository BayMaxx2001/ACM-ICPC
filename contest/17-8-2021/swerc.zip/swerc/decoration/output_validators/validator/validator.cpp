// usage: ./a.out input_file correct_output output_dir < contestants_output
// See specification there:
// http://www.problemarchive.org/wiki/index.php/Output_validator

#include <iostream>
#include <unordered_set>
#include <vector>
#include "validate.h"

int n, k;

std::vector<int> jump;

int check_ans(std::istream& input) {
  int s_last = 0;
  std::unordered_set<int> set;
  long long sum = 0;

  for(int i = 0; i < k; i++) {
    int s;
    if (!(input >> s)) wrong_answer("Invalid input\n");
    if (i == 0 && s == -1) return -1;
    if (!(0 <= s && s < n)) wrong_answer("Invalid range for space\n");
    if (!set.insert(s).second) wrong_answer("Not heterogeneous\n");
    if (i > 0 && jump[s_last] % n != s)
      wrong_answer("Not serene\n");
    s_last = s;
    sum += s;
  }

  char c;
  while (input >> c)
    if (c != ' ' && c != '\n')
      wrong_answer("Invalid input\n");

  return sum;
}

int main(int argc, char **argv) {
  init_io(argc, argv);

  judge_in >> n >> k;
  jump.resize(n);
  for (int i = 1; i < n; i++) {
    jump[i] += i;
    for (int j = i; j < n; j += i)
       jump[j]++;
  }

  if (check_ans(judge_ans) != check_ans(author_out))
    wrong_answer("Not optimal\n");

  accept();
}
