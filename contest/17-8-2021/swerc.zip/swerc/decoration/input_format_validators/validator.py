#! /usr/bin/python3
#

import sys

def myint(s):
    assert s == "0" or not s.startswith("0"),\
            "leading 0 detected"
    return int(s)

try: input = raw_input  # Python 2 compatibility
except: pass

n,k = map(myint,input().split())

assert(1<=n<=1000000)
assert(1<=k<=1000000)

assert(len(sys.stdin.readlines()) == 0)

exit(42)
