#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <string>
#include <map>
using namespace std;

typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<vii> vvii;
typedef vector<int> vi;
typedef set<ii> sii;

const int INF = 1e15;


bool bellmanFord(const vvii& g, int s, vi& d) {
    d.assign(g.size(), INF);
    d[s] = 0;
    bool changed = false;
    // V times
    for (int i = 0; i < g.size(); ++i) {
        changed = false;
        // go over all edges u->v with weight w
        for (int u = 0; u < g.size(); ++u) for (ii e : g[u]) {
            int v = e.first;
            int w = e.second;
            // relax the edge
            if (d[u] < INF && d[u]+w < d[v]) {
                d[v] = d[u]+w;
                changed = true;
            }
        }
    }
    // there is a negative cycle if there were changes in the last iteration
    return changed;
}

int main(){
    // input
    int n, m, junk, U;
    cin >> n >> m >> junk >> U;
    vvii g (n, vii());
    while (m--) {
        int i, j, l;
        cin >> i >> j >> l;
        g[i].emplace_back(j, l);
        g[j].emplace_back(i, l);
    }
    // find distances from home
    vi dist;
    bellmanFord(g, 0, dist);
    // find reachable edges: touching nodes of distance at most (U-1)/2
    sii reachable_streets;
    for (int u = 0; u < n; u++) {
        if (dist[u] <= (U - 1) / 2) {
            for (ii street : g[u]) {
                int v = street.first;
                reachable_streets.emplace(min(u, v), max(u, v));
            }
        }
    }
    // output
    cout << reachable_streets.size() << endl;
    /*for (int i=0; i<n; i++) {
        cout << i << " " << dist[i] << endl;
    }*/
    return 0;
}
