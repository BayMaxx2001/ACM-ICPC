I,S,L,U = map(int,input().split())
streets = [tuple(map(int,input().split())) for _ in range(S)]
nxt = [[] for _ in range(I)]
for (i,j,l) in streets:
    nxt[i].append( (j,l) )
    nxt[j].append( (i,l) )
    
todo = [ [] for _ in range(U+1000) ]
seen = [False] * I
todo[0].append(0)

for dist in range((U+1)//2):
    for el in todo[dist]:
        if not seen[el]:
            seen[el] = True
            for (v,l) in nxt[el]:
                todo[dist+l].append(v)

c=sum([1 for (i,j,l) in streets if seen[i]])+sum([1 for (i,j,l) in streets if seen[j]])
print((c+1)//2)
