(* author: Jean-Christophe *)

open Format
open Scanf

let nI,nS,dL,dU = scanf "%d %d %d %d\n" (fun i s l u -> i,s,l,u)

let g = Array.make nI []

let () =
  for v = 0 to nS - 1 do
    let i,j,l = scanf "%d %d %d\n" (fun i j l -> i,j,l) in
    g.(i) <- (j,l) :: g.(i);
    g.(j) <- (i,l) :: g.(j)
  done

module PQ = struct
  include Set.Make(struct
              type t = int * int (* vertex * dist *)
              let compare (v1,d1) (v2,d2) =
                let c = compare d1 d2 in
                if c <> 0 then c else compare v1 v2
            end)
  let create () = ref empty
  let is_empty s = is_empty !s
  let add s x = s := add x !s
  let remove_min s = let m = min_elt !s in s := remove m !s; m
end

let () =
  let seeni = Array.make nI false in
  let seens = Hashtbl.create 16 in
  let add i j = Hashtbl.replace seens (min i j, max i j) () in
  let pq = PQ.create () in
  PQ.add pq (0, 0);
  while not (PQ.is_empty pq) do
    let i, d = PQ.remove_min pq in
    if not seeni.(i) then (
      seeni.(i) <- true;
      List.iter
        (fun (j, l) ->
          if 2 * d < dU then add i j;
          if 2 * (d + l) < dU then PQ.add pq (j, d + l)
        )
        g.(i)
    )
  done;
  printf "%d@." (Hashtbl.length seens)
