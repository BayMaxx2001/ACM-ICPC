import java.io.*;
import java.util.*;

// author: Jean-Christophe

public class Jogging {

  static ArrayList<ArrayList<Pair>> g;

  public static void main(String[] args) throws IOException {
    BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
    String[] line = r.readLine().split(" ");
    int I = Integer.parseInt(line[0]), S = Integer.parseInt(line[1]),
      U = Integer.parseInt(line[3]);
    g = new ArrayList<>(I);
    for (int i = 0; i < I; i++)
      g.add(new ArrayList<Pair>());
    for (int s = 0; s < S; s++) {
      line = r.readLine().split(" ");
      int i = Integer.parseInt(line[0]), j = Integer.parseInt(line[1]),
        l = Integer.parseInt(line[2]);
      g.get(i).add(new Pair(j, l));
      g.get(j).add(new Pair(i, l));
    }

    boolean[] seeni = new boolean[I];
    HashSet<Pair> seens = new HashSet<>();
    PriorityQueue<Pair> pq = new PriorityQueue<>();
    pq.add(new Pair(0, 0));
    while (!pq.isEmpty()) {
      Pair p = pq.remove();
      int i = p.fst, d = p.snd;
      if (seeni[i]) continue;
      seeni[i] = true;
      for (Pair s: g.get(i)) {
        int j = s.fst, l = s.snd;
        if (2 * d < U) seens.add(new Pair(Math.min(i, j), Math.max(i, j)));
        if (2 * (d + l) < U) pq.add(new Pair(j, d + l));
      }
    }
    System.out.println(seens.size());
  }

}

class Pair implements Comparable<Pair> {
  int fst, snd;
  Pair(int fst, int snd) { this.fst = fst; this.snd = snd; }
  @Override
  public int compareTo(Pair that) {
    int c = this.snd - that.snd;
    return c != 0 ? c : this.fst - that.fst;
  }
  @Override
  public boolean equals(Object o) {
    Pair that = (Pair)o;
    return this.fst == that.fst && this.snd == that.snd;
  }
  @Override
  public int hashCode() {
    return 5003 * this.fst + this.snd;
  }
}
