#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <string>
#include <map>
using namespace std;

typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<vii> vvii;
typedef vector<int> vi;
typedef set<ii> sii;

const int INF = 1e9;


void dijkstra(const vvii& g, int s, vi& dist) {
    dist = vi(g.size(), INF);
    dist[s] = 0;
    priority_queue<ii, vii, greater<ii>> q;
    q.emplace(0, s);
    while (!q.empty()) {
        ii front = q.top();
        q.pop();
        int d = front.first, u = front.second;
        if (d > dist[u]) continue;
        for (ii next : g[u]) {
            int v = next.first, w = next.second;
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                q.emplace(dist[v], v);
            }
        }
    }
}

int main(){
    // input
    int n, m, junk, U;
    cin >> n >> m >> junk >> U;
    vvii g (n, vii());
    while (m--) {
        int i, j, l;
        cin >> i >> j >> l;
        g[i].emplace_back(j, l);
        g[j].emplace_back(i, l);
    }
    // find distances from home
    vi dist;
    dijkstra(g, 0, dist);
    // find reachable edges: touching nodes of distance at most (U-1)/2
    sii reachable_streets;
    for (int u = 0; u < n; u++) {
        if (dist[u] <= (U - 1) / 2) {
            for (ii street : g[u]) {
                int v = street.first;
                reachable_streets.emplace(min(u, v), max(u, v));
            }
        }
    }
    // output
    cout << reachable_streets.size() << endl;
    return 0;
}
